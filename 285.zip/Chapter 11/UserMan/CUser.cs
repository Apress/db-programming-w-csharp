using System;
using System.Data;
using System.Data.SqlClient;

namespace UserMan {
   // Declare delegate for hooking up error notifications
   public delegate void ErrorEventHandler(object sender, CErrorEventArgs e);

   /// <summary>
	/// Summary description for CUser.
       /// </summary>
   public class CUser {
      // Listing 11-1
      // Database constants
      private const string PR_STR_CONNECTION = "Data Source=USERMANPC;" +
         "User ID=UserMan;Password=userman;Initial Catalog=UserMan";
      private const string PR_STR_SQL_TABLE_NAME = "tblUser";

      private const string PR_STR_SQL_FIELD_ID_NAME = "Id";
      private const string PR_STR_SQL_FIELD_FIRST_NAME = "FirstName";
      private const string PR_STR_SQL_FIELD_LAST_NAME = "LastName";
      private const string PR_STR_SQL_FIELD_LOGIN_NAME = "LoginName";
      private const string PR_STR_SQL_FIELD_PASSWORD_NAME = "Password";
      private const string PR_STR_SQL_FIELD_ADSID_NAME = "ADSID";
      private const string PR_STR_SQL_FIELD_ADNAME_NAME = "ADName";

      private const string PR_STR_SQL_USER_SELECT = "SELECT * FROM " + PR_STR_SQL_TABLE_NAME;
      private const string PR_STR_SQL_USER_DELETE = "DELETE FROM " + PR_STR_SQL_TABLE_NAME +
         " WHERE " + PR_STR_SQL_FIELD_ID_NAME + "=@" + PR_STR_SQL_FIELD_ID_NAME;
      private const string PR_STR_SQL_USER_INSERT = "INSERT INTO " + PR_STR_SQL_TABLE_NAME +
         "(" + PR_STR_SQL_FIELD_FIRST_NAME + ", " + PR_STR_SQL_FIELD_LAST_NAME + ", " +
         PR_STR_SQL_FIELD_LOGIN_NAME + ", " + PR_STR_SQL_FIELD_PASSWORD_NAME + ") VALUES(@" + 
         PR_STR_SQL_FIELD_FIRST_NAME + ", @" + PR_STR_SQL_FIELD_LAST_NAME + ", @" + 
         PR_STR_SQL_FIELD_LOGIN_NAME + ", @" + PR_STR_SQL_FIELD_PASSWORD_NAME + ")";
      private const string PR_STR_SQL_USER_UPDATE = "UPDATE " + PR_STR_SQL_TABLE_NAME + 
         " SET " + PR_STR_SQL_FIELD_FIRST_NAME + "=@" + PR_STR_SQL_FIELD_FIRST_NAME + ", " +
         PR_STR_SQL_FIELD_LAST_NAME + "=@" + PR_STR_SQL_FIELD_LAST_NAME + ", " +
         PR_STR_SQL_FIELD_LOGIN_NAME + "=@" + PR_STR_SQL_FIELD_LOGIN_NAME + ", " +
         PR_STR_SQL_FIELD_PASSWORD_NAME + "=@" + PR_STR_SQL_FIELD_PASSWORD_NAME + " WHERE " + 
         PR_STR_SQL_FIELD_ID_NAME + "=@" + PR_STR_SQL_FIELD_ID_NAME;

      // Database variables
      private static SqlConnection prshcnnUserMan;
      private SqlDataAdapter prdadUserMan;
      private DataSet prdstUserMan;

      // For direct user table manipulation
      private SqlCommand prcmmUser;
      // The command objects for the dataset manipulation
      private SqlCommand prcmmUserSelect, prcmmUserDelete, prcmmUserInsert, 
         prcmmUserUpdate;

      // Parameter objects for the data set manipulation
      private SqlParameter prprmSQLDelete, prprmSQLUpdate, prprmSQLInsert;

      // User table column values
      private long prlngId = 0;
      private string prstrADName;
      private string prstrADSID;
      private string prstrFirstName;
      private string prstrLastName;
      private string prstrLoginName;
      private string prstrPassword;

      // User table column max lengths
      private int printFirstNameMaxLen;
      private int printLastNameMaxLen;
      private int printLoginNameMaxLen;
      private int printPasswordMaxLen;

      // For logging user activity
      private CLog probjLog = new CLog();
      // For Accessing Active Directory
      private CActiveDirectory probjActiveDirectory;
 
      // Listing 11-4
      //      public CUser() {
      //         prOpenDatabaseConnection();
      //      }

      public CUser() {
         prOpenDatabaseConnection();
         prInstantiateCommands();
         prInstantiateDataSet();
         prInstantiateAndInitializeDataAdapter();
         prAddCommandObjectParameters();
         prPopulateDataSet();
         prSetColumnMaxLength();
      }
      
      // Listing 11-6
      ~CUser() {
         prCloseDatabaseConnection();
      }

      public event ErrorEventHandler Error;

      protected virtual void OnError(CErrorEventArgs e) {
         // Check if the event has been delegated
         if (Error != null) {
            // Invoke the delegate
            Error(this, e);
         }
      }

      // Listing 11-2
      private void prSetColumnMaxLength() {
         const string STR_COLUMN_SIZE = "ColumnSize";

         SqlDataReader drdSchema;
         DataTable dtbSchema;
         SqlCommand cmmUserSchema = new SqlCommand();

         cmmUserSchema.CommandType = CommandType.Text;
         cmmUserSchema.Connection = prshcnnUserMan;
         cmmUserSchema.CommandText = "SELECT * FROM " + PR_STR_SQL_TABLE_NAME;

         // Return data reader
         drdSchema = cmmUserSchema.ExecuteReader();

         // Read schema from source table
         dtbSchema = drdSchema.GetSchemaTable();

         // Save the maxlength values
         printFirstNameMaxLen = (int) dtbSchema.Rows[3][STR_COLUMN_SIZE];
         printLastNameMaxLen = (int) dtbSchema.Rows[4][STR_COLUMN_SIZE];
         printLoginNameMaxLen = (int) dtbSchema.Rows[5][STR_COLUMN_SIZE];
         printPasswordMaxLen = (int) dtbSchema.Rows[6][STR_COLUMN_SIZE];

         // Close datareader
         drdSchema.Close();
      }
      
      // Listing 11-3
      private void prOpenDatabaseConnection() {
         try {
            // Check if the connection has already been instantiated
            if (prshcnnUserMan == null) {
               // Instantiate the connection
               prshcnnUserMan = new SqlConnection(PR_STR_CONNECTION);
               // Check if the connection is closed
               if ((bool) (prshcnnUserMan.State == ConnectionState.Closed)) {
                  // Open the connection
                  prshcnnUserMan.Open();
                  // Log activity if the user has already been logged on
                  if (prlngId > 0) {
                     probjLog.Logged = DateTime.Now;
                     probjLog.Description = "Database connection opened.";
                     probjLog.UserId = prlngId;
                     probjLog.AddLogEntry();
                  }
               }
            }
         }
         catch (SqlException objSqlException) {
            // A Connection low-level exception was thrown. Add a description and re-throw
            // the exception to the caller of this class
            throw new Exception("The connection to the UserMan database could not be " +
               "established, due to a connection low-level error", objSqlException);
         }
         catch (Exception objE) {
            // Any other exception thrown is handled here
            throw new Exception("The connection to the UserMan database could not be " +
               "established.", objE);
         }
      }
            
      // Listing 11-5
      private void prCloseDatabaseConnection() {
         try {
            // Close the connection
            prshcnnUserMan.Close();
            // Log activity if the user has already been logged on
            if (prlngId > 0) {
               probjLog.Logged = DateTime.Now;
               probjLog.Description = "Database connection closed.";
               probjLog.UserId = prlngId;
               probjLog.AddLogEntry();
            }
         }
         catch (Exception objE) {
            throw new Exception("The connection to the UserMan database could " +
               "not be closed properly.", objE);
         }
      }
            
      // Listing 11-7
      private void prInstantiateCommands() {
         // Instantiate the data set command objects
         prcmmUserSelect = new SqlCommand(PR_STR_SQL_USER_SELECT, prshcnnUserMan);
         prcmmUserDelete = new SqlCommand(PR_STR_SQL_USER_DELETE, prshcnnUserMan);
         prcmmUserInsert = new SqlCommand(PR_STR_SQL_USER_INSERT, prshcnnUserMan);
         prcmmUserUpdate = new SqlCommand(PR_STR_SQL_USER_UPDATE, prshcnnUserMan);
         // Instantiate and initialize generic command object
         prcmmUser = new SqlCommand();
         prcmmUser.Connection = prshcnnUserMan;
      }

      // Listing 11-8
      private void prInstantiateDataSet() {
         prdstUserMan = new DataSet();
      }

      // Listing 11-9
      private void prInstantiateAndInitializeDataAdapter() {
         prdadUserMan = new SqlDataAdapter();
         prdadUserMan.SelectCommand = prcmmUserSelect;
         prdadUserMan.InsertCommand = prcmmUserInsert;
         prdadUserMan.DeleteCommand = prcmmUserDelete;
         prdadUserMan.UpdateCommand = prcmmUserUpdate;
      }

      // Listing 11-10
      private void prAddCommandObjectParameters() {
         // Add delete command parameters
         prprmSQLDelete = prdadUserMan.DeleteCommand.Parameters.Add("@" + 
            PR_STR_SQL_FIELD_ID_NAME, SqlDbType.Int, 0, PR_STR_SQL_FIELD_ID_NAME);
         prprmSQLDelete.Direction = ParameterDirection.Input;
         prprmSQLDelete.SourceVersion = DataRowVersion.Original;

         // Add update command parameters
         prcmmUserUpdate.Parameters.Add("@" + PR_STR_SQL_FIELD_FIRST_NAME, 
            SqlDbType.VarChar, 50, PR_STR_SQL_FIELD_FIRST_NAME);
         prcmmUserUpdate.Parameters.Add("@" + PR_STR_SQL_FIELD_LAST_NAME, 
            SqlDbType.VarChar, 50, PR_STR_SQL_FIELD_LAST_NAME);
         prcmmUserUpdate.Parameters.Add("@" + PR_STR_SQL_FIELD_LOGIN_NAME, 
            SqlDbType.VarChar, 50, PR_STR_SQL_FIELD_LOGIN_NAME);
         prcmmUserUpdate.Parameters.Add("@" + PR_STR_SQL_FIELD_PASSWORD_NAME, 
            SqlDbType.VarChar, 50, PR_STR_SQL_FIELD_PASSWORD_NAME);
         prprmSQLUpdate = prdadUserMan.UpdateCommand.Parameters.Add("@" +
            PR_STR_SQL_FIELD_ID_NAME, SqlDbType.Int, 0, PR_STR_SQL_FIELD_ID_NAME);
         prprmSQLUpdate.Direction = ParameterDirection.Input;
         prprmSQLUpdate.SourceVersion = DataRowVersion.Original;

         // Add insert command parameters
         prcmmUserInsert.Parameters.Add(PR_STR_SQL_FIELD_FIRST_NAME, 
            SqlDbType.VarChar, 50, PR_STR_SQL_FIELD_FIRST_NAME);
         prcmmUserInsert.Parameters.Add("@" + PR_STR_SQL_FIELD_LAST_NAME, 
            SqlDbType.VarChar, 50, PR_STR_SQL_FIELD_LAST_NAME);
         prcmmUserInsert.Parameters.Add("@" + PR_STR_SQL_FIELD_LOGIN_NAME, 
            SqlDbType.VarChar, 50, PR_STR_SQL_FIELD_LOGIN_NAME);
         prcmmUserInsert.Parameters.Add("@" + PR_STR_SQL_FIELD_PASSWORD_NAME, 
            SqlDbType.VarChar, 50, PR_STR_SQL_FIELD_PASSWORD_NAME);
      }

      // Listing 11-11
      private void prPopulateDataSet() {
         try {
            prdadUserMan.Fill(prdstUserMan, PR_STR_SQL_TABLE_NAME);
         }
         catch (SystemException objSystemException) {
            throw new Exception("The dataset could not be populated, " +
               "because the source table was invalid.", objSystemException);
         }
         catch (Exception objE) {
            throw new Exception("The dataset could not be populated.", objE);
         }
      }

      // Listing 11-12
      private void prSaveDataSetValues() {
         // Save user id
         prlngId = (long) 
            prdstUserMan.Tables[PR_STR_SQL_TABLE_NAME].Rows[0]
            [PR_STR_SQL_FIELD_ID_NAME];
         // Check if ADName is Null
         if (prdstUserMan.Tables[PR_STR_SQL_TABLE_NAME].Rows[0].
            IsNull(PR_STR_SQL_FIELD_ADNAME_NAME)) {
            prstrADName = "";
         }
         else {
            prstrADName = prdstUserMan.Tables[PR_STR_SQL_TABLE_NAME].Rows[0]
               [PR_STR_SQL_FIELD_ADNAME_NAME].ToString();
         }
         // Check if ADSID is Null
         if (prdstUserMan.Tables[PR_STR_SQL_TABLE_NAME].Rows[0].
            IsNull(PR_STR_SQL_FIELD_ADSID_NAME)) {
            prstrADSID = "";
         }
         else {
            prstrADSID = prdstUserMan.Tables[PR_STR_SQL_TABLE_NAME].Rows[0]
               [PR_STR_SQL_FIELD_ADSID_NAME].ToString();
         }
         // Check if first name is Null
         if (prdstUserMan.Tables[PR_STR_SQL_TABLE_NAME].Rows[0].
            IsNull(PR_STR_SQL_FIELD_FIRST_NAME)) {
            prstrFirstName = "";
         }
         else {
            prstrFirstName = prdstUserMan.Tables[PR_STR_SQL_TABLE_NAME].Rows[0]
               [PR_STR_SQL_FIELD_FIRST_NAME].ToString();
         }
         // Check if last name is Null
         if (prdstUserMan.Tables[PR_STR_SQL_TABLE_NAME].Rows[0].
            IsNull(PR_STR_SQL_FIELD_LAST_NAME)) {
            prstrLastName = "";
         }
         else {
            prstrLastName = prdstUserMan.Tables[PR_STR_SQL_TABLE_NAME].Rows[0]
               [PR_STR_SQL_FIELD_LAST_NAME].ToString();
         }
         // Check if login name is Null
         if (prdstUserMan.Tables[PR_STR_SQL_TABLE_NAME].Rows[0].
            IsNull(PR_STR_SQL_FIELD_LOGIN_NAME)) {
            prstrLoginName = "";
            
         }
         else {
            prstrLoginName = prdstUserMan.Tables[PR_STR_SQL_TABLE_NAME].Rows[0]
               [PR_STR_SQL_FIELD_LOGIN_NAME].ToString();
         }
         // Check if password is Null
         if (prdstUserMan.Tables[PR_STR_SQL_TABLE_NAME].Rows[0].
            IsNull(PR_STR_SQL_FIELD_PASSWORD_NAME)) {
            prstrPassword = "";
         }
         else {
            prstrPassword = prdstUserMan.Tables[PR_STR_SQL_TABLE_NAME].Rows[0]
               [PR_STR_SQL_FIELD_PASSWORD_NAME].ToString();
         }
      }

      public long Id {
         get {
            return prlngId;
         }
      }
      
      public string ADName {
         get {
            return prstrADName;
         }
         set {
            prstrADName = value;
         }
      }

      public string ADSID {
         get {
            return prstrADSID;
         }
         set {
            prstrADSID = value;
         }
      }

      public string FirstName {
         get {
            return prstrFirstName;
         }
         set {
            if (value.Length <= printFirstNameMaxLen) {
               prstrFirstName = value;
            }
            else {
               prstrFirstName = value.Substring(0, printFirstNameMaxLen);
            }
         }
      }

      public string LastName {
         get {
            return prstrLastName;
         }
         set {
            if (value.Length <= printLastNameMaxLen) {
               prstrLastName = value;
            }
            else {
               prstrLastName = value.Substring(0, printLastNameMaxLen);
            }
         }
      }

      public string LoginName {
         get {
            return prstrLoginName;
         }
         set {
            // Check if the string contains any spaces
            if ((value.IndexOf(" ") == -1)) {
               if (value.Length <= printLoginNameMaxLen) {
                  prstrLoginName = value;
               }
               else {
                  prstrLoginName = value.Substring(0, printLoginNameMaxLen);
               }
            }
               // Listing 9-19
            else {
               // Instantiates the event source
               CErrorEventArgs objErrorEvent = new 
                  CErrorEventArgs(CErrorEventArgs.ErrorStatusEnum.InvalidLoginName);
               // Triggers the error event
               OnError(objErrorEvent);
            }
         }
      }

      public string Password {
         get {
            return prstrPassword;
         }
         set {
            if (value.Length <= printPasswordMaxLen) {
               prstrPassword = value;
            }
            else {
               prstrPassword = value.Substring(0, printPasswordMaxLen);
            }
         }
      }

      public void SetUserProperties(object strADName, object strADSID, long lngId, 
         string strLoginName, object strFirstName, object strLastName, string strPassword) {

         if (strADName == null) {
            prstrADName = "";
         }
         else {
            prstrADName = strADName.ToString();
         }

         if (strADName == null) {
            prstrADSID = "";
         }
         else {
            prstrADSID = strADSID.ToString();
         }

         prlngId = lngId;

         if (strADName == null) {
            prstrFirstName = "";
         }
         else {
            prstrFirstName = strFirstName.ToString();
         }

         if (strADName == null) {
            prstrLastName = "";
         }
         else {
            prstrLastName = strLastName.ToString();
         }

         prstrLoginName = strLoginName;
         prstrPassword = strPassword;
      }

      public void UpdateDataSource() {
         try {
            prdstUserMan.Tables[PR_STR_SQL_TABLE_NAME].Rows[0]
               [PR_STR_SQL_FIELD_ADNAME_NAME] = prstrADName;
            prdstUserMan.Tables[PR_STR_SQL_TABLE_NAME].Rows[0]
               [PR_STR_SQL_FIELD_ADSID_NAME] = prstrADSID;
            prdstUserMan.Tables[PR_STR_SQL_TABLE_NAME].Rows[0]
               [PR_STR_SQL_FIELD_FIRST_NAME] = prstrFirstName;
            prdstUserMan.Tables[PR_STR_SQL_TABLE_NAME].Rows[0]
               [PR_STR_SQL_FIELD_LAST_NAME] = prstrLastName;
            prdstUserMan.Tables[PR_STR_SQL_TABLE_NAME].Rows[0]
               [PR_STR_SQL_FIELD_LOGIN_NAME] = prstrLoginName;
            prdstUserMan.Tables[PR_STR_SQL_TABLE_NAME].Rows[0]
               [PR_STR_SQL_FIELD_PASSWORD_NAME] = prstrPassword;
            prdadUserMan.Update(prdstUserMan, PR_STR_SQL_TABLE_NAME);
         }
         catch (Exception objE) {
            // An exception has been thrown, so re-throw with original exception
            throw new Exception("The UserMan database could not be updated.", objE);
         }
      }

      // Listing 11-4
      public void GetADUserInfo() {
         probjActiveDirectory = new CActiveDirectory(prstrLoginName);
         prstrADName = probjActiveDirectory.ADName;
         prstrADSID = probjActiveDirectory.ADSID;
      }
   }
}