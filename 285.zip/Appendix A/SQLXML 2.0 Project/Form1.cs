using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Xml;

namespace SQLXML_2._0_Project
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
      private System.Windows.Forms.Button btnInstantiateAdapter;
      private System.Windows.Forms.Button btnPopulateDataSet;
      private System.Windows.Forms.Button btnUpdateDataSource;
      private System.Windows.Forms.Button btnInstantiateCommand;
      private System.Windows.Forms.Button btnPopulateXmlReader;
      private System.Windows.Forms.Button btnSaveCommandResultToStream;
      private System.Windows.Forms.Button btnAppendResultSetToStream;
      private System.Windows.Forms.Button btnExecuteNamedParameterCommand;
      private System.Windows.Forms.Button btnExecutePositionalParameterCommand;
      private System.Windows.Forms.Button btnExecuteXPathQuery;
      private System.Windows.Forms.Button btnExecuteNonQuery;
      private System.Windows.Forms.Button btnExecuteDiffGram;
      private System.Windows.Forms.Button btnExecuteUpdateGram;

      private CGeneral objGeneral = new CGeneral();

      public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         this.btnAppendResultSetToStream = new System.Windows.Forms.Button();
         this.btnInstantiateAdapter = new System.Windows.Forms.Button();
         this.btnSaveCommandResultToStream = new System.Windows.Forms.Button();
         this.btnPopulateXmlReader = new System.Windows.Forms.Button();
         this.btnPopulateDataSet = new System.Windows.Forms.Button();
         this.btnExecutePositionalParameterCommand = new System.Windows.Forms.Button();
         this.btnExecuteNonQuery = new System.Windows.Forms.Button();
         this.btnUpdateDataSource = new System.Windows.Forms.Button();
         this.btnExecuteNamedParameterCommand = new System.Windows.Forms.Button();
         this.btnInstantiateCommand = new System.Windows.Forms.Button();
         this.btnExecuteXPathQuery = new System.Windows.Forms.Button();
         this.btnExecuteDiffGram = new System.Windows.Forms.Button();
         this.btnExecuteUpdateGram = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // btnAppendResultSetToStream
         // 
         this.btnAppendResultSetToStream.Location = new System.Drawing.Point(144, 90);
         this.btnAppendResultSetToStream.Name = "btnAppendResultSetToStream";
         this.btnAppendResultSetToStream.Size = new System.Drawing.Size(218, 23);
         this.btnAppendResultSetToStream.TabIndex = 0;
         this.btnAppendResultSetToStream.Text = "Append Result Set to Stream";
         this.btnAppendResultSetToStream.Click += new System.EventHandler(this.btnAppendResultSetToStream_Click);
         // 
         // btnInstantiateAdapter
         // 
         this.btnInstantiateAdapter.Location = new System.Drawing.Point(6, 6);
         this.btnInstantiateAdapter.Name = "btnInstantiateAdapter";
         this.btnInstantiateAdapter.Size = new System.Drawing.Size(128, 23);
         this.btnInstantiateAdapter.TabIndex = 0;
         this.btnInstantiateAdapter.Text = "Instantiate Adapter";
         this.btnInstantiateAdapter.Click += new System.EventHandler(this.btnInstantiateAdapter_Click);
         // 
         // btnSaveCommandResultToStream
         // 
         this.btnSaveCommandResultToStream.Location = new System.Drawing.Point(144, 62);
         this.btnSaveCommandResultToStream.Name = "btnSaveCommandResultToStream";
         this.btnSaveCommandResultToStream.Size = new System.Drawing.Size(218, 23);
         this.btnSaveCommandResultToStream.TabIndex = 0;
         this.btnSaveCommandResultToStream.Text = "Save Result Set to Stream";
         this.btnSaveCommandResultToStream.Click += new System.EventHandler(this.btnSaveCommandResultToStream_Click);
         // 
         // btnPopulateXmlReader
         // 
         this.btnPopulateXmlReader.Location = new System.Drawing.Point(144, 34);
         this.btnPopulateXmlReader.Name = "btnPopulateXmlReader";
         this.btnPopulateXmlReader.Size = new System.Drawing.Size(218, 23);
         this.btnPopulateXmlReader.TabIndex = 0;
         this.btnPopulateXmlReader.Text = "Populate XmlReader";
         this.btnPopulateXmlReader.Click += new System.EventHandler(this.btnPopulateXmlReader_Click);
         // 
         // btnPopulateDataSet
         // 
         this.btnPopulateDataSet.Location = new System.Drawing.Point(6, 34);
         this.btnPopulateDataSet.Name = "btnPopulateDataSet";
         this.btnPopulateDataSet.Size = new System.Drawing.Size(128, 23);
         this.btnPopulateDataSet.TabIndex = 0;
         this.btnPopulateDataSet.Text = "Populate DataSet";
         this.btnPopulateDataSet.Click += new System.EventHandler(this.btnPopulateDataSet_Click);
         // 
         // btnExecutePositionalParameterCommand
         // 
         this.btnExecutePositionalParameterCommand.Location = new System.Drawing.Point(144, 146);
         this.btnExecutePositionalParameterCommand.Name = "btnExecutePositionalParameterCommand";
         this.btnExecutePositionalParameterCommand.Size = new System.Drawing.Size(218, 23);
         this.btnExecutePositionalParameterCommand.TabIndex = 0;
         this.btnExecutePositionalParameterCommand.Text = "Execute Positional Parameter Command";
         this.btnExecutePositionalParameterCommand.Click += new System.EventHandler(this.btnExecutePositionalParameterCommand_Click);
         // 
         // btnExecuteNonQuery
         // 
         this.btnExecuteNonQuery.Location = new System.Drawing.Point(144, 202);
         this.btnExecuteNonQuery.Name = "btnExecuteNonQuery";
         this.btnExecuteNonQuery.Size = new System.Drawing.Size(218, 23);
         this.btnExecuteNonQuery.TabIndex = 0;
         this.btnExecuteNonQuery.Text = "Execute Non-Query";
         this.btnExecuteNonQuery.Click += new System.EventHandler(this.btnExecuteNonQuery_Click);
         // 
         // btnUpdateDataSource
         // 
         this.btnUpdateDataSource.Location = new System.Drawing.Point(6, 62);
         this.btnUpdateDataSource.Name = "btnUpdateDataSource";
         this.btnUpdateDataSource.Size = new System.Drawing.Size(128, 23);
         this.btnUpdateDataSource.TabIndex = 0;
         this.btnUpdateDataSource.Text = "Update Data Source";
         this.btnUpdateDataSource.Click += new System.EventHandler(this.btnUpdateDataSource_Click);
         // 
         // btnExecuteNamedParameterCommand
         // 
         this.btnExecuteNamedParameterCommand.Location = new System.Drawing.Point(144, 118);
         this.btnExecuteNamedParameterCommand.Name = "btnExecuteNamedParameterCommand";
         this.btnExecuteNamedParameterCommand.Size = new System.Drawing.Size(218, 23);
         this.btnExecuteNamedParameterCommand.TabIndex = 0;
         this.btnExecuteNamedParameterCommand.Text = "Execute Named Parameter Command";
         this.btnExecuteNamedParameterCommand.Click += new System.EventHandler(this.btnExecuteNamedParameterCommand_Click);
         // 
         // btnInstantiateCommand
         // 
         this.btnInstantiateCommand.Location = new System.Drawing.Point(144, 6);
         this.btnInstantiateCommand.Name = "btnInstantiateCommand";
         this.btnInstantiateCommand.Size = new System.Drawing.Size(218, 23);
         this.btnInstantiateCommand.TabIndex = 0;
         this.btnInstantiateCommand.Text = "Instantiate Command";
         this.btnInstantiateCommand.Click += new System.EventHandler(this.btnInstantiateCommand_Click);
         // 
         // btnExecuteXPathQuery
         // 
         this.btnExecuteXPathQuery.Location = new System.Drawing.Point(144, 174);
         this.btnExecuteXPathQuery.Name = "btnExecuteXPathQuery";
         this.btnExecuteXPathQuery.Size = new System.Drawing.Size(218, 23);
         this.btnExecuteXPathQuery.TabIndex = 0;
         this.btnExecuteXPathQuery.Text = "Execute XPath Query";
         this.btnExecuteXPathQuery.Click += new System.EventHandler(this.btnExecuteXPathQuery_Click);
         // 
         // btnExecuteDiffGram
         // 
         this.btnExecuteDiffGram.Location = new System.Drawing.Point(144, 230);
         this.btnExecuteDiffGram.Name = "btnExecuteDiffGram";
         this.btnExecuteDiffGram.Size = new System.Drawing.Size(218, 23);
         this.btnExecuteDiffGram.TabIndex = 0;
         this.btnExecuteDiffGram.Text = "Execute DiffGram";
         this.btnExecuteDiffGram.Click += new System.EventHandler(this.btnExecuteDiffGram_Click);
         // 
         // btnExecuteUpdateGram
         // 
         this.btnExecuteUpdateGram.Location = new System.Drawing.Point(144, 258);
         this.btnExecuteUpdateGram.Name = "btnExecuteUpdateGram";
         this.btnExecuteUpdateGram.Size = new System.Drawing.Size(218, 23);
         this.btnExecuteUpdateGram.TabIndex = 0;
         this.btnExecuteUpdateGram.Text = "Execute UpdateGram";
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(369, 285);
         this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                      this.btnExecuteUpdateGram,
                                                                      this.btnExecuteDiffGram,
                                                                      this.btnExecuteNonQuery,
                                                                      this.btnExecuteXPathQuery,
                                                                      this.btnExecutePositionalParameterCommand,
                                                                      this.btnExecuteNamedParameterCommand,
                                                                      this.btnAppendResultSetToStream,
                                                                      this.btnSaveCommandResultToStream,
                                                                      this.btnPopulateXmlReader,
                                                                      this.btnInstantiateCommand,
                                                                      this.btnUpdateDataSource,
                                                                      this.btnPopulateDataSet,
                                                                      this.btnInstantiateAdapter});
         this.Name = "Form1";
         this.Text = "SQLXML 2.0 Project";
         this.ResumeLayout(false);

      }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

      private void btnInstantiateAdapter_Click(object sender, System.EventArgs e)
      {
         objGeneral.InstantiateSqlXmlAdapter();
      }

      private void btnPopulateDataSet_Click(object sender, System.EventArgs e) {
         //objGeneral.PopulateDataSetUsingSql();
         //objGeneral.PopulateDataSetUsingSql2();
         //objGeneral.PopulateDataSetUsingStringTemplate();
         objGeneral.PopulateDataSetUsingTemplateFile();
      }

      private void btnUpdateDataSource_Click(object sender, System.EventArgs e) {
         objGeneral.UpdateDataSourceFromDataSet();
      }

      private void btnInstantiateCommand_Click(object sender, System.EventArgs e) {
         objGeneral.InstantiateSqlXmlCommand();
      }

      private void btnPopulateXmlReader_Click(object sender, System.EventArgs e) {
         objGeneral.PopulateXmlReader();
      }

      private void btnSaveCommandResultToStream_Click(object sender, System.EventArgs e) {
         objGeneral.SaveCommandResultToStream();
      }

      private void btnAppendResultSetToStream_Click(object sender, System.EventArgs e) {
         objGeneral.AppendCommandResultToStream();
      }

      private void btnExecuteNamedParameterCommand_Click(object sender, System.EventArgs e) {
         objGeneral.ExecuteNamedParameterCommand();
      }

      private void btnExecutePositionalParameterCommand_Click(object sender, System.EventArgs e) {
         objGeneral.ExecutePositionalParameterCommand();
      }

      private void btnExecuteXPathQuery_Click(object sender, System.EventArgs e) {
         //objGeneral.ExecuteXPathQuery();
         objGeneral.ExecuteXPathQueryUsingMappingSchema();
      }

      private void btnExecuteNonQuery_Click(object sender, System.EventArgs e) {
         //objGeneral.ExecuteNonQuery();
         //objGeneral.ExecuteNonQueryStringTemplate();
         objGeneral.ExecuteNonQueryTemplate();
      }

      private void btnExecuteDiffGram_Click(object sender, System.EventArgs e) {
         objGeneral.ExecuteDiffGram();
      }
	}
}
