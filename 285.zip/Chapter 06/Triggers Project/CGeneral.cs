#define ORACLE
//#define SQLSERVER 
// Comment out the line above for the DBMS you want to run the example code against

using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Windows.Forms;

/// <summary>
/// Summary description for CGeneral.
/// </summary>
public class CGeneral {
	public CGeneral() {
		//
		// TODO: Add constructor logic here
		//
	}

#if SQLSERVER
   // This connection string os for connecting to SQL Server
   private const string STR_CONNECTION_STRING = "Data Source=USERMANPC;" +
      "User ID=UserMan;Password=userman;Initial Catalog=UserMan";
#elif ORACLE
   // This connection string os for connecting to Oracle
   // You must change the Data Source value
   public const string STR_CONNECTION_STRING = 
      "Provider=MSDAORA;Password=userman;User ID=USERMAN;Data Source=USERMAN";
#endif         

	// Listing 6-14
	public void TestUpdateTrigger() {
#if SQLSERVER
      const string STR_SQL_USER_SELECT = "SELECT * FROM tblUser";
		const string STR_SQL_USER_DELETE = "DELETE FROM tblUser WHERE Id=@Id";
		const string STR_SQL_USER_INSERT = "INSERT INTO tblUser(FirstName, LastName, LoginName) VALUES(@FirstName, @LastName, @LoginName)";
		const string STR_SQL_USER_UPDATE = "UPDATE tblUser SET FirstName=@FirstName, LastName=@LastName, LoginName=@LoginName WHERE Id=@Id";

		SqlConnection cnnUserMan;
		SqlCommand cmmUser;
		SqlDataAdapter dadUser;
		DataSet dstUser;

		SqlCommand cmmUserSelect;
		SqlCommand cmmUserDelete;
		SqlCommand cmmUserInsert;
		SqlCommand cmmUserUpdate;

		SqlParameter prmSQLDelete, prmSQLUpdate;

		// Instantiate and open the connection
		cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();

		// Instantiate and initialize command
		cmmUser = new SqlCommand("SELECT * FROM tblUser", cnnUserMan);
		// Instantiate the commands
		cmmUserSelect = new SqlCommand(STR_SQL_USER_SELECT, cnnUserMan);
		cmmUserDelete = new SqlCommand(STR_SQL_USER_DELETE, cnnUserMan);
		cmmUserInsert = new SqlCommand(STR_SQL_USER_INSERT, cnnUserMan);
		cmmUserUpdate = new SqlCommand(STR_SQL_USER_UPDATE, cnnUserMan);
		// Instantiate command and data set
		cmmUser = new SqlCommand(STR_SQL_USER_SELECT, cnnUserMan);
		dstUser = new DataSet();

		dadUser = new SqlDataAdapter();
		dadUser.SelectCommand = cmmUserSelect;
		dadUser.InsertCommand = cmmUserInsert;
		dadUser.DeleteCommand = cmmUserDelete;
		dadUser.UpdateCommand = cmmUserUpdate;

		// Add parameters
		prmSQLDelete = dadUser.DeleteCommand.Parameters.Add("@Id", SqlDbType.Int, 0, "Id");
		prmSQLDelete.Direction = ParameterDirection.Input;
		prmSQLDelete.SourceVersion = DataRowVersion.Original;

		cmmUserUpdate.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, "FirstName");
		cmmUserUpdate.Parameters.Add("@LastName", SqlDbType.VarChar, 50, "LastName");
		cmmUserUpdate.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, "LoginName");
		prmSQLUpdate = dadUser.UpdateCommand.Parameters.Add("@Id", SqlDbType.Int, 0, "Id");
		prmSQLUpdate.Direction = ParameterDirection.Input;
		prmSQLUpdate.SourceVersion = DataRowVersion.Original;

		cmmUserInsert.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, "FirstName");
		cmmUserInsert.Parameters.Add("@LastName", SqlDbType.VarChar, 50, "LastName");
		cmmUserInsert.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, "LoginName");
#elif ORACLE
      const string STR_SQL_USER_SELECT = "SELECT * FROM tblUser";
      const string STR_SQL_USER_DELETE = "DELETE FROM tblUser WHERE Id=?";
      const string STR_SQL_USER_INSERT = "INSERT INTO tblUser(Id, FirstName, LastName, LoginName) VALUES(?, ?, ?)";
      const string STR_SQL_USER_UPDATE = "UPDATE tblUser SET FirstName=?, LastName=?, LoginName=? WHERE Id=?";

      OleDbConnection cnnUserMan;
      OleDbCommand cmmUser;
      OleDbDataAdapter dadUser;
      DataSet dstUser;

      OleDbCommand cmmUserSelect;
      OleDbCommand cmmUserDelete;
      OleDbCommand cmmUserInsert;
      OleDbCommand cmmUserUpdate;

      OleDbParameter prmSQLDelete, prmSQLUpdate;

      // Instantiate and open the connection
      cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();

      // Instantiate and initialize command
      cmmUser = new OleDbCommand("SELECT * FROM tblUser", cnnUserMan);
      // Instantiate the commands
      cmmUserSelect = new OleDbCommand(STR_SQL_USER_SELECT, cnnUserMan);
      cmmUserDelete = new OleDbCommand(STR_SQL_USER_DELETE, cnnUserMan);
      cmmUserInsert = new OleDbCommand(STR_SQL_USER_INSERT, cnnUserMan);
      cmmUserUpdate = new OleDbCommand(STR_SQL_USER_UPDATE, cnnUserMan);
      // Instantiate command and data set
      cmmUser = new OleDbCommand(STR_SQL_USER_SELECT, cnnUserMan);
      dstUser = new DataSet();

      dadUser = new OleDbDataAdapter();
      dadUser.SelectCommand = cmmUserSelect;
      dadUser.InsertCommand = cmmUserInsert;
      dadUser.DeleteCommand = cmmUserDelete;
      dadUser.UpdateCommand = cmmUserUpdate;

      // Add parameters
      prmSQLDelete = dadUser.DeleteCommand.Parameters.Add("@Id", OleDbType.Integer, 0, "Id");
      prmSQLDelete.Direction = ParameterDirection.Input;
      prmSQLDelete.SourceVersion = DataRowVersion.Original;

      cmmUserUpdate.Parameters.Add("@FirstName", OleDbType.VarChar, 50, "FirstName");
      cmmUserUpdate.Parameters.Add("@LastName", OleDbType.VarChar, 50, "LastName");
      cmmUserUpdate.Parameters.Add("@LoginName", OleDbType.VarChar, 50, "LoginName");
      prmSQLUpdate = dadUser.UpdateCommand.Parameters.Add("@Id", OleDbType.Integer, 0, "Id");
      prmSQLUpdate.Direction = ParameterDirection.Input;
      prmSQLUpdate.SourceVersion = DataRowVersion.Original;

      cmmUserInsert.Parameters.Add("@FirstName", OleDbType.VarChar, 50, "FirstName");
      cmmUserInsert.Parameters.Add("@LastName", OleDbType.VarChar, 50, "LastName");
      cmmUserInsert.Parameters.Add("@LoginName", OleDbType.VarChar, 50, "LoginName");
#endif         
      // Populate the data set from the view
		dadUser.Fill(dstUser, "tblUser");

		// Change the name of user in the second row
		dstUser.Tables["tblUser"].Rows[1]["LastName"] = "Thomsen";
		dstUser.Tables["tblUser"].Rows[1]["FirstName"] = null;

		try {
			// Propagate changes back to the data source
			dadUser.Update(dstUser, "tblUser");
		}
		catch (Exception objE) {
			MessageBox.Show(objE.Message);
		}
	}
}