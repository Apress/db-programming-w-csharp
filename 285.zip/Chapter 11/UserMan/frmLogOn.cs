using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace UserMan {
	/// <summary>
	/// Summary description for frmLogon.
	/// </summary>
	public class frmLogOn : System.Windows.Forms.Form {
      internal System.Windows.Forms.Button btnCancel;
      internal System.Windows.Forms.Button btnOK;
      internal System.Windows.Forms.TextBox txtPassword;
      internal System.Windows.Forms.Label lblUserId;
      internal System.Windows.Forms.Label lblPassword;
      internal System.Windows.Forms.TextBox txtLoginName;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmLogOn() {
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing ) {
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         this.btnCancel = new System.Windows.Forms.Button();
         this.btnOK = new System.Windows.Forms.Button();
         this.txtPassword = new System.Windows.Forms.TextBox();
         this.lblUserId = new System.Windows.Forms.Label();
         this.lblPassword = new System.Windows.Forms.Label();
         this.txtLoginName = new System.Windows.Forms.TextBox();
         this.SuspendLayout();
         // 
         // btnCancel
         // 
         this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
         this.btnCancel.Location = new System.Drawing.Point(128, 76);
         this.btnCancel.Name = "btnCancel";
         this.btnCancel.TabIndex = 11;
         this.btnCancel.Text = "Cancel";
         this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
         // 
         // btnOK
         // 
         this.btnOK.BackColor = System.Drawing.SystemColors.Control;
         this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
         this.btnOK.Location = new System.Drawing.Point(42, 76);
         this.btnOK.Name = "btnOK";
         this.btnOK.TabIndex = 10;
         this.btnOK.Text = "OK";
         this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
         // 
         // txtPassword
         // 
         this.txtPassword.Location = new System.Drawing.Point(70, 38);
         this.txtPassword.MaxLength = 50;
         this.txtPassword.Name = "txtPassword";
         this.txtPassword.PasswordChar = '*';
         this.txtPassword.Size = new System.Drawing.Size(165, 20);
         this.txtPassword.TabIndex = 9;
         this.txtPassword.Text = "";
         // 
         // lblUserId
         // 
         this.lblUserId.AutoSize = true;
         this.lblUserId.Location = new System.Drawing.Point(10, 20);
         this.lblUserId.Name = "lblUserId";
         this.lblUserId.Size = new System.Drawing.Size(44, 13);
         this.lblUserId.TabIndex = 6;
         this.lblUserId.Text = "&User Id:";
         // 
         // lblPassword
         // 
         this.lblPassword.AutoSize = true;
         this.lblPassword.Location = new System.Drawing.Point(10, 40);
         this.lblPassword.Name = "lblPassword";
         this.lblPassword.Size = new System.Drawing.Size(57, 13);
         this.lblPassword.TabIndex = 8;
         this.lblPassword.Text = "&Password:";
         // 
         // txtLoginName
         // 
         this.txtLoginName.Location = new System.Drawing.Point(70, 16);
         this.txtLoginName.Name = "txtLoginName";
         this.txtLoginName.Size = new System.Drawing.Size(165, 20);
         this.txtLoginName.TabIndex = 7;
         this.txtLoginName.Text = "";
         // 
         // frmLogOn
         // 
         this.AcceptButton = this.btnOK;
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.CancelButton = this.btnCancel;
         this.ClientSize = new System.Drawing.Size(244, 114);
         this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                      this.btnCancel,
                                                                      this.btnOK,
                                                                      this.txtPassword,
                                                                      this.lblUserId,
                                                                      this.lblPassword,
                                                                      this.txtLoginName});
         this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "frmLogOn";
         this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
         this.Text = "UserMan Logon";
         this.ResumeLayout(false);

      }
		#endregion

      private void btnOK_Click(object sender, System.EventArgs e) {
		   SqlConnection cnnUserMan = new SqlConnection();
		   SqlCommand cmmUser = new SqlCommand();
		   SqlDataReader drdUser;

		   // Check if the Login Name is empty
		   if (txtLoginName.Text == "") {
   			// The password and/or loginname was incorrect
	   		MessageBox.Show("You must type in the User Id!");
		   	// Set focus to the Login name text box
			   ActiveControl = txtLoginName;

            return;
         }

		   // Iniatialize and open the connection
		   cnnUserMan.ConnectionString = "Data Source=USERMANPC;" +
		      "User ID=UserMan;Password=userman;Initial Catalog=UserMan";
		   cnnUserMan.Open();

		   // Initialize the command
		   cmmUser.Connection = cnnUserMan;
		   cmmUser.CommandType = CommandType.Text;
		   cmmUser.CommandText = "SELECT * FROM tblUser WHERE LoginName='" + txtLoginName.Text +
		      "' AND Password='" + txtPassword.Text + "'";
		   // Execute the command
		   drdUser = cmmUser.ExecuteReader();

		   // Check if a user was returned
         if (drdUser.Read()) {
            // The user can now be logged on, so fill the admin user object with returned values
            CGeneral.objAdminUser.SetUserProperties(drdUser["ADName"], drdUser["ADSID"], 
               drdUser.GetInt32(0), drdUser["LoginName"].ToString(), drdUser["FirstName"].ToString(), 
               drdUser["LastName"].ToString(), drdUser["Password"].ToString());
            // Get 
            CGeneral.objAdminUser.GetADUserInfo();
            CGeneral.LoggedOn = true;
            // Close the dialog
            this.Close();
         }
		   else {
			   // The password and/or loginname was incorrect
			   MessageBox.Show("The User Id and/or Password supplied does not match a user in the system!");
               ActiveControl = txtLoginName;
         }
      }

      private void btnCancel_Click(object sender, System.EventArgs e) {
		   // Exit application
         Application.Exit();
      }
   }
}