using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace WebFormDataBoundControls
{
	/// <summary>
	/// Summary description for frmUser.
	/// </summary>
	public class frmUser : System.Web.UI.Page
	{
      protected System.Data.OleDb.OleDbCommand oleDbSelectCommand1;
      protected System.Data.OleDb.OleDbCommand oleDbInsertCommand1;
      protected System.Data.OleDb.OleDbCommand oleDbUpdateCommand1;
      protected System.Data.OleDb.OleDbCommand oleDbDeleteCommand1;
      protected WebFormDataBoundControls.dstUser objdstUser;
      protected System.Data.OleDb.OleDbConnection oleDbConnection1;
      protected System.Data.OleDb.OleDbDataAdapter oleDbDataAdapter1;
      protected System.Web.UI.WebControls.DataGrid masterDataGrid;
   
      // Listing 10-7
		private void Page_Load(object sender, System.EventArgs e) {
         try {
            LoadDataSet();
            // Check if the page is being refreshed
            if (!IsPostBack) {
               masterDataGrid.SelectedIndex = -1;
               masterDataGrid.DataBind();
            }
         }
         catch (System.Exception eLoad) {
            Response.Write(eLoad.Message);
         }
      }

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
         this.oleDbSelectCommand1 = new System.Data.OleDb.OleDbCommand();
         this.oleDbConnection1 = new System.Data.OleDb.OleDbConnection();
         this.oleDbInsertCommand1 = new System.Data.OleDb.OleDbCommand();
         this.oleDbUpdateCommand1 = new System.Data.OleDb.OleDbCommand();
         this.oleDbDeleteCommand1 = new System.Data.OleDb.OleDbCommand();
         this.objdstUser = new WebFormDataBoundControls.dstUser();
         this.oleDbDataAdapter1 = new System.Data.OleDb.OleDbDataAdapter();
         ((System.ComponentModel.ISupportInitialize)(this.objdstUser)).BeginInit();
         this.masterDataGrid.CancelCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.masterDataGrid_CancelCommand);
         this.masterDataGrid.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.masterDataGrid_EditCommand);
         this.masterDataGrid.UpdateCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.masterDataGrid_UpdateCommand);
         // 
         // oleDbSelectCommand1
         // 
         this.oleDbSelectCommand1.CommandText = "SELECT Id, ADName, ADSID, FirstName, LastName, LoginName, Password FROM tblUser";
         this.oleDbSelectCommand1.Connection = this.oleDbConnection1;
         // 
         // oleDbConnection1
         // 
         this.oleDbConnection1.ConnectionString = "Provider=SQLOLEDB;Password=userman;User ID=UserMan;Initial Catalog=UserMan;Data S" +
            "ource=USERMANPC;";
         // 
         // oleDbInsertCommand1
         // 
         this.oleDbInsertCommand1.CommandText = "INSERT INTO tblUser(ADName, ADSID, FirstName, LastName, LoginName, Password) VALU" +
            "ES (?, ?, ?, ?, ?, ?); SELECT Id, ADName, ADSID, FirstName, LastName, LoginName," +
            " Password FROM tblUser WHERE (Id = @@IDENTITY)";
         this.oleDbInsertCommand1.Connection = this.oleDbConnection1;
         this.oleDbInsertCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("ADName", System.Data.OleDb.OleDbType.VarChar, 100, "ADName"));
         this.oleDbInsertCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("ADSID", System.Data.OleDb.OleDbType.VarChar, 50, "ADSID"));
         this.oleDbInsertCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("FirstName", System.Data.OleDb.OleDbType.VarChar, 50, "FirstName"));
         this.oleDbInsertCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("LastName", System.Data.OleDb.OleDbType.VarChar, 50, "LastName"));
         this.oleDbInsertCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("LoginName", System.Data.OleDb.OleDbType.VarChar, 50, "LoginName"));
         this.oleDbInsertCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Password", System.Data.OleDb.OleDbType.VarChar, 50, "Password"));
         // 
         // oleDbUpdateCommand1
         // 
         this.oleDbUpdateCommand1.CommandText = @"UPDATE tblUser SET ADName = ?, ADSID = ?, FirstName = ?, LastName = ?, LoginName = ?, Password = ? WHERE (Id = ?) AND (ADName = ? OR ? IS NULL AND ADName IS NULL) AND (ADSID = ? OR ? IS NULL AND ADSID IS NULL) AND (FirstName = ? OR ? IS NULL AND FirstName IS NULL) AND (LastName = ? OR ? IS NULL AND LastName IS NULL) AND (LoginName = ?) AND (Password = ?); SELECT Id, ADName, ADSID, FirstName, LastName, LoginName, Password FROM tblUser WHERE (Id = ?)";
         this.oleDbUpdateCommand1.Connection = this.oleDbConnection1;
         this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("ADName", System.Data.OleDb.OleDbType.VarChar, 100, "ADName"));
         this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("ADSID", System.Data.OleDb.OleDbType.VarChar, 50, "ADSID"));
         this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("FirstName", System.Data.OleDb.OleDbType.VarChar, 50, "FirstName"));
         this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("LastName", System.Data.OleDb.OleDbType.VarChar, 50, "LastName"));
         this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("LoginName", System.Data.OleDb.OleDbType.VarChar, 50, "LoginName"));
         this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Password", System.Data.OleDb.OleDbType.VarChar, 50, "Password"));
         this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Id", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Id", System.Data.DataRowVersion.Original, null));
         this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_ADName", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ADName", System.Data.DataRowVersion.Original, null));
         this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_ADName1", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ADName", System.Data.DataRowVersion.Original, null));
         this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_ADSID", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ADSID", System.Data.DataRowVersion.Original, null));
         this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_ADSID1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ADSID", System.Data.DataRowVersion.Original, null));
         this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_FirstName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "FirstName", System.Data.DataRowVersion.Original, null));
         this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_FirstName1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "FirstName", System.Data.DataRowVersion.Original, null));
         this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_LastName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "LastName", System.Data.DataRowVersion.Original, null));
         this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_LastName1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "LastName", System.Data.DataRowVersion.Original, null));
         this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_LoginName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "LoginName", System.Data.DataRowVersion.Original, null));
         this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Password", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Password", System.Data.DataRowVersion.Original, null));
         this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Select_Id", System.Data.OleDb.OleDbType.Integer, 4, "Id"));
         // 
         // oleDbDeleteCommand1
         // 
         this.oleDbDeleteCommand1.CommandText = @"DELETE FROM tblUser WHERE (Id = ?) AND (ADName = ? OR ? IS NULL AND ADName IS NULL) AND (ADSID = ? OR ? IS NULL AND ADSID IS NULL) AND (FirstName = ? OR ? IS NULL AND FirstName IS NULL) AND (LastName = ? OR ? IS NULL AND LastName IS NULL) AND (LoginName = ?) AND (Password = ?)";
         this.oleDbDeleteCommand1.Connection = this.oleDbConnection1;
         this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Id", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Id", System.Data.DataRowVersion.Original, null));
         this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_ADName", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ADName", System.Data.DataRowVersion.Original, null));
         this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_ADName1", System.Data.OleDb.OleDbType.VarChar, 100, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ADName", System.Data.DataRowVersion.Original, null));
         this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_ADSID", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ADSID", System.Data.DataRowVersion.Original, null));
         this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_ADSID1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ADSID", System.Data.DataRowVersion.Original, null));
         this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_FirstName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "FirstName", System.Data.DataRowVersion.Original, null));
         this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_FirstName1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "FirstName", System.Data.DataRowVersion.Original, null));
         this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_LastName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "LastName", System.Data.DataRowVersion.Original, null));
         this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_LastName1", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "LastName", System.Data.DataRowVersion.Original, null));
         this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_LoginName", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "LoginName", System.Data.DataRowVersion.Original, null));
         this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Password", System.Data.OleDb.OleDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Password", System.Data.DataRowVersion.Original, null));
         // 
         // objdstUser
         // 
         this.objdstUser.DataSetName = "dstUser";
         this.objdstUser.Locale = new System.Globalization.CultureInfo("da-DK");
         this.objdstUser.Namespace = "http://www.tempuri.org/dstUser.xsd";
         // 
         // oleDbDataAdapter1
         // 
         this.oleDbDataAdapter1.DeleteCommand = this.oleDbDeleteCommand1;
         this.oleDbDataAdapter1.InsertCommand = this.oleDbInsertCommand1;
         this.oleDbDataAdapter1.SelectCommand = this.oleDbSelectCommand1;
         this.oleDbDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
                                                                                                    new System.Data.Common.DataTableMapping("Table", "tblUser", new System.Data.Common.DataColumnMapping[] {
                                                                                                                                                                                                              new System.Data.Common.DataColumnMapping("Id", "Id"),
                                                                                                                                                                                                              new System.Data.Common.DataColumnMapping("ADName", "ADName"),
                                                                                                                                                                                                              new System.Data.Common.DataColumnMapping("ADSID", "ADSID"),
                                                                                                                                                                                                              new System.Data.Common.DataColumnMapping("FirstName", "FirstName"),
                                                                                                                                                                                                              new System.Data.Common.DataColumnMapping("LastName", "LastName"),
                                                                                                                                                                                                              new System.Data.Common.DataColumnMapping("LoginName", "LoginName"),
                                                                                                                                                                                                              new System.Data.Common.DataColumnMapping("Password", "Password")})});
         this.oleDbDataAdapter1.UpdateCommand = this.oleDbUpdateCommand1;
         this.Load += new System.EventHandler(this.Page_Load);
         ((System.ComponentModel.ISupportInitialize)(this.objdstUser)).EndInit();

      }
		#endregion

      public void FillDataSet(WebFormDataBoundControls.dstUser dataSet) {
         // Turn off constraint checking before the dataset is filled.
         // This allows the adapters to fill the dataset without concern
         // for dependencies between the tables.
         dataSet.EnforceConstraints = false;
         try {
            // Open the connection.
            this.oleDbConnection1.Open();
            // Attempt to fill the dataset through the OleDbDataAdapter1.
            this.oleDbDataAdapter1.Fill(dataSet);
         }
         catch (System.Exception fillException) {
            // Add your error handling code here.
            throw fillException;
         }
         finally {
            // Turn constraint checking back on.
            dataSet.EnforceConstraints = true;
            // Close the connection whether or not the exception was thrown.
            this.oleDbConnection1.Close();
         }
      }

      public void LoadDataSet() {
         // Create a new dataset to hold the records returned from the call to FillDataSet.
         // A temporary dataset is used because filling the existing dataset would
         // require the databindings to be rebound.
         WebFormDataBoundControls.dstUser objDataSetTemp;
         objDataSetTemp = new WebFormDataBoundControls.dstUser();
         try {
            // Attempt to fill the temporary dataset.
            this.FillDataSet(objDataSetTemp);
         }
         catch (System.Exception eFillDataSet) {
            // Add your error handling code here.
            throw eFillDataSet;
         }
         try {
            // Empty the old records from the dataset.
            objdstUser.Clear();
            // Merge the records into the main dataset.
            objdstUser.Merge(objDataSetTemp);
         }
         catch (System.Exception eLoadMerge) {
            // Add your error handling code here.
            throw eLoadMerge;
         }
      }

      // Listing 10-4
      private void masterDataGrid_EditCommand(object source, 
         System.Web.UI.WebControls.DataGridCommandEventArgs e) {
         masterDataGrid.EditItemIndex = e.Item.ItemIndex;
         masterDataGrid.DataBind();      
      }

      // Listing 10-5
      private void masterDataGrid_CancelCommand(object source, 
         System.Web.UI.WebControls.DataGridCommandEventArgs e) {
         masterDataGrid.EditItemIndex = -1;
         masterDataGrid.DataBind(); 
		}

      // Listing 10-6
      private void masterDataGrid_UpdateCommand(object source, 
         System.Web.UI.WebControls.DataGridCommandEventArgs e) {
         dstUser.tblUserRow drwUser;
         TextBox txtEdit;
         int intKey;

         // Save the key field of edited row
         intKey = int.Parse(masterDataGrid.DataKeys[e.Item.ItemIndex].ToString());

         // Locate the row in the the dataset that has been edited
         // by using the saved key as an argument for the FindById
         // procedure
         drwUser = objdstUser.tblUser.FindById(intKey);

         // Update the DataSet with the changed values, through
         // the located data row
         txtEdit = (TextBox) (e.Item.Cells[1].Controls[0]);
         drwUser.ADName = txtEdit.Text;
         txtEdit = (TextBox) (e.Item.Cells[2].Controls[0]);
         drwUser.ADSID = txtEdit.Text;
         txtEdit = (TextBox) (e.Item.Cells[3].Controls[0]);
         drwUser.FirstName = txtEdit.Text;
         txtEdit = (TextBox) (e.Item.Cells[4].Controls[0]);
         drwUser.LastName = txtEdit.Text;
         txtEdit = (TextBox) (e.Item.Cells[5].Controls[0]);
         drwUser.LoginName = txtEdit.Text;
         txtEdit = (TextBox) (e.Item.Cells[6].Controls[0]);
         drwUser.Password = txtEdit.Text;

         // Update the data source
         oleDbDataAdapter1.Update(objdstUser);

         // Take the DataGrid out of editing mode and rebind
         masterDataGrid.EditItemIndex = -1;
         masterDataGrid.DataBind();
      }
	}
}