using System;
using ADODB;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;
using System.Web.Mail;

/// <summary>
/// Summary description for CGeneral.
/// </summary>
public class CGeneral
{
	public CGeneral()
	{
		//
		// TODO: Add constructor logic here
		//
	}

   // Listing 7-10
   public void SendMessageUsingCDOSYS() {
      MailMessage msgMail = new MailMessage();

      // Prepare message
      msgMail.From = "UserMan <userman@userman.dk>";
      msgMail.To = "Carsten Thomsen <carstent@userman.dk>";
      msgMail.Body = "This is the e-mail body";
      msgMail.Subject = "This is the e-mail subject";
      
      // Set the SMTP server (you can use an IP address,
      // NETBIOS name or a FQDN)
      SmtpMail.SmtpServer = "10.8.1.16";
      SmtpMail.SmtpServer = "EXCHANGESERVER";
      SmtpMail.SmtpServer = "exchangeserver.userman.dk";
 
      // Send the prepared message using the 
      // specified SMTP server
      SmtpMail.Send(msgMail);
   }

   // Listing 7-11
   // This procedure must run on the machine that hosts Exchange Server
   public void RetrieveContactsUsingExOLEDB() {
      ADODB.Connection cnnExchange = new ADODB.Connection();
      ADODB.RecordsetClass rstExchange = new ADODB.RecordsetClass();
      string strFile = "file://./backofficestorage/userman.dk/mbx/userman";

      cnnExchange.Provider = "ExOLEDB.DataSource";

      try {
         // Open the connection, keeping in mind that
         // the ExOLEDB provider doesn't authenticate
         // the passed user id and password arguments
         cnnExchange.Open(strFile, null, null, -1);
         // Open the recordset
         rstExchange.Open("SELECT \"DAV:displayname\" AS Name " +
            "FROM SCOPE('shallow traversal of \"Contacts\"')", cnnExchange,
            CursorTypeEnum.adOpenForwardOnly, LockTypeEnum.adLockReadOnly, 0);
         // Loop through all the returned rows (contacts)
         while (! rstExchange.EOF) {
            // Display Contact name
            MessageBox.Show(rstExchange.Fields["Name"].Value.ToString());
            // Move to the next row
            rstExchange.MoveNext();
         }
      }
      catch (Exception objE) {
         MessageBox.Show(objE.Message);
      }
   }

   // Listing 7-12
   public void MSDAIPPShowFolderProperties() {
		OleDbConnection cnnExchange = new OleDbConnection();
		OleDbCommand cmmExchange = new OleDbCommand();
 		OleDbDataReader drdExchange;

		string strFolder;

		// Setup connection string to bind to the userman folder
		cnnExchange.ConnectionString = "Provider=MSDAIPP.dso;Data Source=" +
         "http://exchangeserver/exchange/userman;User ID='Administrator';Password=AdminPwd;";

		// Open the connection
		cnnExchange.Open();
		// Initialize the command
		cmmExchange.Connection = cnnExchange;
		cmmExchange.CommandType = CommandType.TableDirect;
		// Return all rows
		drdExchange = cmmExchange.ExecuteReader();

		// Loop through all the returned rows (folders)
		while (drdExchange.Read()) {
			// Initialize folder string
			strFolder = "";
			// Loop through all the columns (properties)
			for (int intColumn = 0; intColumn < drdExchange.FieldCount -1; intColumn++) {
				// Read folder property name and value
				strFolder += drdExchange.GetName(intColumn).ToString()  + "=" +
					drdExchange[intColumn].ToString() + "\n";
			}
			// Display folder properties
			MessageBox.Show(strFolder);
		}
	}
}