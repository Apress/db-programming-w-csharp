using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Exchange_Server_Project
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
      private System.Windows.Forms.Button btnRetrieveUserManContactsExOleDb;
      private System.Windows.Forms.Button btnSendMessageCDOSYS;
      private System.Windows.Forms.Button btnShowFolderPropertiesMSDAIPP;

		private CGeneral objGeneral = new CGeneral();

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         this.btnSendMessageCDOSYS = new System.Windows.Forms.Button();
         this.btnRetrieveUserManContactsExOleDb = new System.Windows.Forms.Button();
         this.btnShowFolderPropertiesMSDAIPP = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // btnSendMessageCDOSYS
         // 
         this.btnSendMessageCDOSYS.Location = new System.Drawing.Point(40, 87);
         this.btnSendMessageCDOSYS.Name = "btnSendMessageCDOSYS";
         this.btnSendMessageCDOSYS.Size = new System.Drawing.Size(213, 23);
         this.btnSendMessageCDOSYS.TabIndex = 0;
         this.btnSendMessageCDOSYS.Text = "Send Message (CDOSYS)";
         this.btnSendMessageCDOSYS.Click += new System.EventHandler(this.btnSendMessageCDOSYS_Click);
         // 
         // btnRetrieveUserManContactsExOleDb
         // 
         this.btnRetrieveUserManContactsExOleDb.Location = new System.Drawing.Point(40, 51);
         this.btnRetrieveUserManContactsExOleDb.Name = "btnRetrieveUserManContactsExOleDb";
         this.btnRetrieveUserManContactsExOleDb.Size = new System.Drawing.Size(213, 23);
         this.btnRetrieveUserManContactsExOleDb.TabIndex = 1;
         this.btnRetrieveUserManContactsExOleDb.Text = "Retrieve UserMan Contacts (ExOleDb)";
         this.btnRetrieveUserManContactsExOleDb.Click += new System.EventHandler(this.btnRetrieveUserManContactsExOleDb_Click);
         // 
         // btnShowFolderPropertiesMSDAIPP
         // 
         this.btnShowFolderPropertiesMSDAIPP.Location = new System.Drawing.Point(40, 125);
         this.btnShowFolderPropertiesMSDAIPP.Name = "btnShowFolderPropertiesMSDAIPP";
         this.btnShowFolderPropertiesMSDAIPP.Size = new System.Drawing.Size(213, 23);
         this.btnShowFolderPropertiesMSDAIPP.TabIndex = 2;
         this.btnShowFolderPropertiesMSDAIPP.Text = "Show Folder Properties (MSDAIPP)";
         this.btnShowFolderPropertiesMSDAIPP.Click += new System.EventHandler(this.btnShowFolderPropertiesMSDAIPP_Click);
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(292, 181);
         this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                      this.btnShowFolderPropertiesMSDAIPP,
                                                                      this.btnRetrieveUserManContactsExOleDb,
                                                                      this.btnSendMessageCDOSYS});
         this.Name = "Form1";
         this.Text = "Exchange Server Project";
         this.ResumeLayout(false);

      }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void btnSendMessageCDOSYS_Click(object sender, System.EventArgs e) {
			//objGeneral.MSDAIPPEditFolderProperties();
         objGeneral.SendMessageUsingCDOSYS();
		}

      private void btnRetrieveUserManContactsExOleDb_Click(object sender, System.EventArgs e) {
         objGeneral.RetrieveContactsUsingExOLEDB();
      }

      private void btnShowFolderPropertiesMSDAIPP_Click(object sender, System.EventArgs e) {
         objGeneral.MSDAIPPShowFolderProperties();
      }
	}
}