using System;

namespace UserMan {
   // Listing 9-15
   // Declare delegate for hooking up error notifications
   public delegate void ErrorEventHandler(object sender, CErrorEventArgs e);

   /// <summary>
	/// Summary description for CUser.
	/// </summary>
   public class CUser {
      // Listing 9-6
      // User table column values
      private long prlngId;
      private string prstrADName;
      private string prstrADSID;
      private string prstrFirstName;
      private string prstrLastName;
      private string prstrLoginName;
      private string prstrPassword;

      // Listing 9-9
      // User table column max lengths
      private int printADNameMaxLen;
      private int printADSIDMaxLen;
      private int printFirstNameMaxLen;
      private int printLastNameMaxLen;
      private int printLoginNameMaxLen;
      private int printPasswordMaxLen;

      // Listing 9-12
      public CUser() {
         //
         // TODO: Add constructor logic here
         //
      }

      // Listing 9-13
      ~CUser() {
      }

      // Listin 9-16-1
      public event ErrorEventHandler Error;

      // Listin 9-16-2
      protected virtual void OnError(CErrorEventArgs e) {
         // Check if the event has been delegated
         if (Error != null) {
            // Invoke the delegate
            Error(this, e);
         }
      }

      // Listing 9-7
      public long Id {
         get {
            return prlngId;
         }
      }

      // Listing 9-8 
//      public string ADName {
//         get {
//            return prstrADName;
//         }
//         set {
//            prstrADName = value;
//         }
//      }

      // Listing 9-10
      public string ADName {
         get {
            return prstrADName;
         }
         set {
            if (value.Length <= printADNameMaxLen) {
               prstrADName = value;
            }
            else {
               prstrADName = value.Substring(0, printADNameMaxLen);
            }
         }
      }

      public string ADSID {
         get {
            return prstrADSID;
         }
         set {
            if (value.Length <= printADSIDMaxLen) {
               prstrADSID = value;
            }
            else {
               prstrADSID = value.Substring(0, printADSIDMaxLen);
            }

         }
      }

      public string FirstName {
         get {
            return prstrFirstName;
         }
         set {
            if (value.Length <= printFirstNameMaxLen) {
               prstrFirstName = value;
            }
            else {
               prstrFirstName = value.Substring(0, printFirstNameMaxLen);
            }
         }
      }

      public string LastName {
         get {
            return prstrLastName;
         }
         set {
            if (value.Length <= printLastNameMaxLen) {
               prstrLastName = value;
            }
            else {
               prstrLastName = value.Substring(0, printLastNameMaxLen);
            }
         }
      }

      // Listing 9-11
      public string LoginName {
         get {
            return prstrLoginName;
         }
         set {
            // Check if the string contains any spaces
            if ((value.IndexOf(" ") == -1)) {
               if (value.Length <= printLoginNameMaxLen) {
                  prstrLoginName = value;
               }
               else {
                  prstrLoginName = value.Substring(0, printLoginNameMaxLen);
               }
            }
            // Listing 9-19
            else {
               // Instantiates the event source
               CErrorEventArgs objErrorEvent = new 
                  CErrorEventArgs(CErrorEventArgs.ErrorStatusEnum.InvalidLoginName);
               // Triggers the error event
               OnError(objErrorEvent);
            }
         }
      }

      public string Password {
         get {
            return prstrPassword;
         }
         set {
            if (value.Length <= printPasswordMaxLen) {
               prstrPassword = value;
            }
            else {
               prstrPassword = value.Substring(0, printPasswordMaxLen);
            }
         }
      }
   }
}