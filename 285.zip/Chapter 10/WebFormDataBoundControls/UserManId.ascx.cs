namespace WebFormDataBoundControls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		Summary description for UserManId.
	/// </summary>
	public abstract class UserManId : System.Web.UI.UserControl
	{
      protected System.Data.SqlClient.SqlCommand sqlSelectCommand1;
      protected System.Data.SqlClient.SqlCommand sqlInsertCommand1;
      protected System.Data.SqlClient.SqlCommand sqlUpdateCommand1;
      protected System.Data.SqlClient.SqlCommand sqlDeleteCommand1;
      protected System.Data.SqlClient.SqlConnection sqlConnection1;
      protected System.Data.SqlClient.SqlDataAdapter sqlDataAdapter1;
      protected System.Web.UI.WebControls.TextBox txtUserId;
      protected WebFormDataBoundControls.User user1;

		private void Page_Load(object sender, System.EventArgs e)
		{
         // Listing 10-8
			// Open connection
         sqlConnection1.Open();
         // Fill data set
         sqlDataAdapter1.Fill(user1, "tblUser");
         txtUserId.DataBind();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
         this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
         this.sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
         this.sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
         this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
         this.sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
         this.user1 = new WebFormDataBoundControls.User();
         ((System.ComponentModel.ISupportInitialize)(this.user1)).BeginInit();
         // 
         // sqlSelectCommand1
         // 
         this.sqlSelectCommand1.CommandText = "SELECT Id, ADName, ADSID, FirstName, LastName, LoginName, Password FROM tblUser";
         this.sqlSelectCommand1.Connection = this.sqlConnection1;
         // 
         // sqlInsertCommand1
         // 
         this.sqlInsertCommand1.CommandText = "INSERT INTO tblUser(ADName, ADSID, FirstName, LastName, LoginName, Password) VALU" +
            "ES (@ADName, @ADSID, @FirstName, @LastName, @LoginName, @Password); SELECT Id, A" +
            "DName, ADSID, FirstName, LastName, LoginName, Password FROM tblUser WHERE (Id = " +
            "@@IDENTITY)";
         this.sqlInsertCommand1.Connection = this.sqlConnection1;
         this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ADName", System.Data.SqlDbType.VarChar, 100, "ADName"));
         this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ADSID", System.Data.SqlDbType.VarChar, 50, "ADSID"));
         this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@FirstName", System.Data.SqlDbType.VarChar, 50, "FirstName"));
         this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@LastName", System.Data.SqlDbType.VarChar, 50, "LastName"));
         this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@LoginName", System.Data.SqlDbType.VarChar, 50, "LoginName"));
         this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Password", System.Data.SqlDbType.VarChar, 50, "Password"));
         // 
         // sqlUpdateCommand1
         // 
         this.sqlUpdateCommand1.CommandText = @"UPDATE tblUser SET ADName = @ADName, ADSID = @ADSID, FirstName = @FirstName, LastName = @LastName, LoginName = @LoginName, Password = @Password WHERE (Id = @Original_Id) AND (ADName = @Original_ADName OR @Original_ADName IS NULL AND ADName IS NULL) AND (ADSID = @Original_ADSID OR @Original_ADSID IS NULL AND ADSID IS NULL) AND (FirstName = @Original_FirstName OR @Original_FirstName IS NULL AND FirstName IS NULL) AND (LastName = @Original_LastName OR @Original_LastName IS NULL AND LastName IS NULL) AND (LoginName = @Original_LoginName) AND (Password = @Original_Password); SELECT Id, ADName, ADSID, FirstName, LastName, LoginName, Password FROM tblUser WHERE (Id = @Id)";
         this.sqlUpdateCommand1.Connection = this.sqlConnection1;
         this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ADName", System.Data.SqlDbType.VarChar, 100, "ADName"));
         this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ADSID", System.Data.SqlDbType.VarChar, 50, "ADSID"));
         this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@FirstName", System.Data.SqlDbType.VarChar, 50, "FirstName"));
         this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@LastName", System.Data.SqlDbType.VarChar, 50, "LastName"));
         this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@LoginName", System.Data.SqlDbType.VarChar, 50, "LoginName"));
         this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Password", System.Data.SqlDbType.VarChar, 50, "Password"));
         this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Id", System.Data.DataRowVersion.Original, null));
         this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ADName", System.Data.SqlDbType.VarChar, 100, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ADName", System.Data.DataRowVersion.Original, null));
         this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ADSID", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ADSID", System.Data.DataRowVersion.Original, null));
         this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_FirstName", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "FirstName", System.Data.DataRowVersion.Original, null));
         this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_LastName", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "LastName", System.Data.DataRowVersion.Original, null));
         this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_LoginName", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "LoginName", System.Data.DataRowVersion.Original, null));
         this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Password", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Password", System.Data.DataRowVersion.Original, null));
         this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Id", System.Data.SqlDbType.Int, 4, "Id"));
         // 
         // sqlDeleteCommand1
         // 
         this.sqlDeleteCommand1.CommandText = @"DELETE FROM tblUser WHERE (Id = @Original_Id) AND (ADName = @Original_ADName OR @Original_ADName IS NULL AND ADName IS NULL) AND (ADSID = @Original_ADSID OR @Original_ADSID IS NULL AND ADSID IS NULL) AND (FirstName = @Original_FirstName OR @Original_FirstName IS NULL AND FirstName IS NULL) AND (LastName = @Original_LastName OR @Original_LastName IS NULL AND LastName IS NULL) AND (LoginName = @Original_LoginName) AND (Password = @Original_Password)";
         this.sqlDeleteCommand1.Connection = this.sqlConnection1;
         this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Id", System.Data.DataRowVersion.Original, null));
         this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ADName", System.Data.SqlDbType.VarChar, 100, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ADName", System.Data.DataRowVersion.Original, null));
         this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ADSID", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ADSID", System.Data.DataRowVersion.Original, null));
         this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_FirstName", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "FirstName", System.Data.DataRowVersion.Original, null));
         this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_LastName", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "LastName", System.Data.DataRowVersion.Original, null));
         this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_LoginName", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "LoginName", System.Data.DataRowVersion.Original, null));
         this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Password", System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Password", System.Data.DataRowVersion.Original, null));
         // 
         // sqlConnection1
         // 
         this.sqlConnection1.ConnectionString = "data source=USERMANPC;initial catalog=UserMan;password=userman;user id=UserM" +
            "an;";
         // 
         // sqlDataAdapter1
         // 
         this.sqlDataAdapter1.DeleteCommand = this.sqlDeleteCommand1;
         this.sqlDataAdapter1.InsertCommand = this.sqlInsertCommand1;
         this.sqlDataAdapter1.SelectCommand = this.sqlSelectCommand1;
         this.sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
                                                                                                  new System.Data.Common.DataTableMapping("Table", "tblUser", new System.Data.Common.DataColumnMapping[] {
                                                                                                                                                                                                            new System.Data.Common.DataColumnMapping("Id", "Id"),
                                                                                                                                                                                                            new System.Data.Common.DataColumnMapping("ADName", "ADName"),
                                                                                                                                                                                                            new System.Data.Common.DataColumnMapping("ADSID", "ADSID"),
                                                                                                                                                                                                            new System.Data.Common.DataColumnMapping("FirstName", "FirstName"),
                                                                                                                                                                                                            new System.Data.Common.DataColumnMapping("LastName", "LastName"),
                                                                                                                                                                                                            new System.Data.Common.DataColumnMapping("LoginName", "LoginName"),
                                                                                                                                                                                                            new System.Data.Common.DataColumnMapping("Password", "Password")})});
         this.sqlDataAdapter1.UpdateCommand = this.sqlUpdateCommand1;
         // 
         // user1
         // 
         this.user1.DataSetName = "User";
         this.user1.Locale = new System.Globalization.CultureInfo("da-DK");
         this.user1.Namespace = "http://www.tempuri.org/User.xsd";
         this.Load += new System.EventHandler(this.Page_Load);
         ((System.ComponentModel.ISupportInitialize)(this.user1)).EndInit();

      }
		#endregion
	}
}
