using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Xml;
using System.IO;
using System.Windows.Forms;
using System.Globalization;

public class CGeneral {
   public const string STR_CONNECTION_STRING = 
      "Data Source=USERMANPC;User Id=UserMan;Password=userman;Initial Catalog=UserMan";

   // Listing 3A-1
   public void OpenConnection(string strConnectionString) {
      // Declare connection object
      SqlConnection cnnUserMan;

      // Instantiate the connection object
      cnnUserMan = new SqlConnection();
      // Set up connection string
      cnnUserMan.ConnectionString = strConnectionString;

      // Open the connection
      cnnUserMan.Open();
   }

   // Listing 3A-2-1 & Listing 3-6-1
   // Declare and instantiate connection
   private SqlConnection prcnnUserMan = new SqlConnection(STR_CONNECTION_STRING);

   // Listing 3A-2-2
//   public CGeneral() {
//      // Set up event handler
//      prcnnUserMan.StateChange  += new StateChangeEventHandler(OnStateChange);
//   }

   // Listing 3A-2-3
   protected static void OnStateChange(object sender, StateChangeEventArgs args) {
      // Display the original and the current state
      MessageBox.Show("The original connection state was: " + args.OriginalState.ToString() +
         "\nThe current connection state is: " + args.CurrentState.ToString());
   }

   // Listing 3A-2-3
   public void TriggerStateChangeEvent() {
      // Open the connection
      prcnnUserMan.Open();
      // Close the connection
      prcnnUserMan.Close();
   }

   // Listing 3A-3
   public void CheckConnectionStringWhiteSpace() {
      SqlConnection cnnUserMan1 = new SqlConnection();
      SqlConnection cnnUserMan2 = new SqlConnection();

      // Set the connection string for the connections
      cnnUserMan1.ConnectionString = "User Id=UserMan;Password=userman;" +
         "Data Source='USERMANPC';Initial Catalog='UserMan';Max Pool Size=1;Connection Timeout=5";
      cnnUserMan2.ConnectionString = "User Id=UserMan;Password=userman; " + 
         "Data Source='USERMANPC';Initial Catalog='UserMan';Max Pool Size=1;Connection Timeout=5";

      // cnnUserMan1 and cnnUserMan2 will NOT be added to the same connection pool
      // because cnnUserMan2 contains an extra space char right after
      // Password=userman;
      try {
         // Open the cnnUserMan1 connection
         cnnUserMan1.Open();
         // Open the cnnUserMan2 connection
         cnnUserMan2.Open();
      }
      catch (Exception objE) {
         // This message will be displayed if the two connection strings are equal,
         // because then the connection pool will have reached it's max size (1)
         // If you don't see the message, the connections are drawn from 
         // different pools
         MessageBox.Show(objE.Message);
      }
   }

   public void CheckConnectionPooling() {
      SqlConnection cnnUserMan1;
      SqlConnection cnnUserMan2;

      // Instantiate and open the first SQL connection
      cnnUserMan1 = new SqlConnection(STR_CONNECTION_STRING + ";Max Pool Size=1;Connection Timeout=5");
      cnnUserMan1.Open();

      try  {
         // Instantiate and open the second SQL connection
         cnnUserMan2 = new SqlConnection(STR_CONNECTION_STRING + ";Max Pool Size=1;Connection Timeout=5");
         cnnUserMan2.Open();
      }
      catch (Exception objE ) {
         MessageBox.Show(objE.Message);
      }
   }

   // Listing 3A-6-2
//   public CGeneral() {
//      // Set up event handler
//      prcnnUserMan.InfoMessage  += new SqlInfoMessageEventHandler(OnInfoMessage);
//   }

   // Listing 3A-6-3
   protected static void OnInfoMessage(object sender, SqlInfoMessageEventArgs args) {
      // Loop through all the error messages 
      foreach (SqlError objError in args.Errors) {
         // Display the error properties
         MessageBox.Show("The " + objError.Source + " has raised a warning on the " +
            objError.Server + " server. These are the properties :\n\n"  +
            "Severity: " + objError.Class + "\nNumber: " +
            objError.Number + "\nState: " + objError.State +
            "\nLine: " + objError.LineNumber + "\n" +
            "Procedure: " + objError.Procedure + "\nMessage: " + 
            objError.Message);
      }

      // Display the message and the source
      MessageBox.Show("Info Message: " + args.Message +
         "\nInfo Source: " + args.Source);
   }

   // Listing 3A-6-4
   public void TriggerInfoMessageEvent() {
      SqlCommand cmmUserMan = 
         new SqlCommand("RAISERROR('This is an info message event.', 10, 1)", prcnnUserMan);
      // Open the connection
      prcnnUserMan.Open();
      // Execute the T-SQL command
      cmmUserMan.ExecuteNonQuery(); 
   }

   // Listing 3A-8
   public void BeginNonDefaultIsolationLevelTransaction() {
      SqlConnection cnnUserMan;
      SqlTransaction traUserMan;

      // Instantiate the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Open the connection
      cnnUserMan.Open();
      // Begin transaction
      traUserMan = cnnUserMan.BeginTransaction(IsolationLevel.ReadCommitted);
   }

   // Listing 3A-9
   public void BeginNamedTransaction() {
      const string STR_MAIN_TRANSACTION_NAME = "MainTransaction";

      SqlConnection cnnUserMan;
      SqlTransaction traUserMan;

      // Instantiate the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Open the connection
      cnnUserMan.Open();
      // Begin transaction
      traUserMan = cnnUserMan.BeginTransaction(STR_MAIN_TRANSACTION_NAME);
   }

   // Listing 3A-10
   public void BeginNamedNonDefaultIsolationLevelTransaction() {
      const string STR_MAIN_TRANSACTION_NAME = "MainTransaction";
	
      SqlConnection cnnUserMan;
      SqlTransaction traUserMan;

      // Instantiate the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Open the connection
      cnnUserMan.Open();
      // Begin transaction
      traUserMan = cnnUserMan.BeginTransaction(IsolationLevel.ReadCommitted, 
         STR_MAIN_TRANSACTION_NAME);
   }

   // Listing 3A-11
   public void UseTransactionSavePoints() {
      const string STR_MAIN_TRANSACTION_NAME = "MainTransaction";
      const string STR_FAMILY_TRANSACTION_NAME = "FamilyUpdates";
      const string STR_ADDRESS_TRANSACTION_NAME = "AddressUpdates";

      SqlConnection cnnUserMan;
      SqlTransaction traUserMan;

      // Instantiate the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Open the connection
      cnnUserMan.Open();

      // Start named transaction
      traUserMan = cnnUserMan.BeginTransaction(STR_MAIN_TRANSACTION_NAME);
      // Update family tables
      // ...

      // Save transaction reference point
      traUserMan.Save(STR_FAMILY_TRANSACTION_NAME);
      // Update address tables
      // ...
      // Save transaction reference point
      traUserMan.Save(STR_ADDRESS_TRANSACTION_NAME);
      // Roll back changes made after the family save point
      traUserMan.Rollback(STR_FAMILY_TRANSACTION_NAME);
   }

   // Listing 3A-13
   public void DetermineTransactionIsolationLevel() {
      SqlConnection cnnUserMan;
      SqlTransaction traUserMan;
	
      // Instantiate the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Open the connection
      cnnUserMan.Open();

      // Start transaction with non-default isolation level
      traUserMan = cnnUserMan.BeginTransaction(IsolationLevel.ReadCommitted);

      // Return the isolation level as text
      MessageBox.Show(traUserMan.IsolationLevel.ToString());
   }

   // Listing 3A-14
   public void CheckBeginTransactionMethodException() {
      SqlConnection cnnUserMan;
      SqlTransaction traUserMan;

      // Instantiate the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Open the connection
      // If the following line is commented out, the BeginTransaction exception will be thrown.
      //cnnUserMan.Open();

      try {
         // Start transaction with non-default isolation level
         traUserMan = cnnUserMan.BeginTransaction(IsolationLevel.ReadCommitted);
      }
      catch (Exception objException) {
         // Check if a BeginTransaction method threw the exception
         if (objException.TargetSite.Name.ToString() == "BeginTransaction") {
            MessageBox.Show("The BeginTransaction method threw the exception!");
         }
      }
   }

   // Listing 3A-15
   public void CheckConnectionStringPropertyException() {
      SqlConnection cnnUserMan;

      // Instantiate the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Open the connection
      cnnUserMan.Open();

      try {
         // Set the connection string
         cnnUserMan.ConnectionString = STR_CONNECTION_STRING;
      }
      catch (Exception objException) {
         // Check if setting the ConnectionString threw the exception
         if (objException.TargetSite.Name == "set_ConnectionString") {
            MessageBox.Show(
               "The ConnectionString property threw the exception!");
         }
      }
   }

   // Listing 3A-16
   public void CheckConnectionTimeoutPropertyException() {
      SqlConnection cnnUserMan;

      try {
         // Instantiate the connection
         cnnUserMan = new SqlConnection(STR_CONNECTION_STRING + ";Connection Timeout=-1");
         // Open the connection
         cnnUserMan.Open();
      }
      catch (Exception objException) { 
         // Check if setting the Connection Timeout to an invalid value threw the exception
         if (objException.TargetSite.Name == "SetConnectTimeout") {
            MessageBox.Show("The Connection Timeout value threw the exception!");
         }
      }
   }
			
   // Listing 3A-17
   public void CheckChangeDatabaseMethodException() {
      SqlConnection cnnUserMan;

      try {
         // Instantiate the connection
         cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
         // Open the connection
         // If the following line is commented out, the ChangeDatabase exception will be thrown
         //cnnUserMan.Open();
         // Change database
         cnnUserMan.ChangeDatabase("master"); 
      }
      catch (Exception objException) {
         // Check if we tried to change database on an invalid connection
         if (objException.TargetSite.Name == "ChangeDatabase") {
            MessageBox.Show("The ChangeDatabase method threw the exception!");
         }
      }
   }

   // Listing 3A-18
   public void CheckOpenMethodException() {
      SqlConnection cnnUserMan;

      try {
         // Instantiate the connection
         cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
         // Open the connection
         cnnUserMan.Open();
         // Open the connection
         cnnUserMan.Open(); 
      }
      catch (Exception objException) {
         // Check if we tried to open an already open connection
         if (objException.TargetSite.Name == "Open") {
            MessageBox.Show("The Open method threw the exception!");
         }
      }
   }

   // Listing 3A-19
   public void TraversingAllSqlErrors() {
      SqlConnection cnnUserMan;

      try {
         // Instantiate the connection
         cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
         // Open the connection
         cnnUserMan.Open();
         // Do your stuff...
         // ... 
      }
      catch (SqlException objException) {
         // This catch block will handle all exceptions that 
         // the SqlAdapter cannot handle
         foreach (SqlError objError in objException.Errors) {
            MessageBox.Show(objError.Message);
         }
      }
      catch (Exception objException) {
         // This catch block will catch all exceptions that
         //	the SqlAdapter can handle
         MessageBox.Show(objException.Message);
      }
   }

   // Listing 3A-21
   public void InstantiateCommandObject() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUserMan;
      string strSQL;

      // Instantiate the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Open the connection
      cnnUserMan.Open();
      // Build query string
      strSQL = "SELECT * FROM tblUser";
      // Instantiate the command
      cmmUserMan = new SqlCommand(strSQL, cnnUserMan);
   }

   // Listing 3A-22
   public void ExecuteNonQueryCommand() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUserMan;
      string strSQL;

      // Instantiate the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Open the connection
      cnnUserMan.Open();
      // Build delete query string
      strSQL = "DELETE FROM tblUser WHERE LoginName='User99'";
      // Instantiate and execute the delete command
      cmmUserMan = new SqlCommand(strSQL, cnnUserMan);
      cmmUserMan.ExecuteNonQuery();
      // Build insert query string
      strSQL = "INSERT INTO tblUser (LoginName) VALUES('User99')";
      // Instantiate and execute the insert command
      cmmUserMan = new SqlCommand(strSQL, cnnUserMan);
      cmmUserMan.ExecuteNonQuery();
   }

   // Listing 3A-23
   public void ExecuteReaderCommand() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUserMan;
      SqlDataReader drdTest;
      string strSQL;

      // Instantiate the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Open the connection
      cnnUserMan.Open();
      // Build query string
      strSQL = "SELECT * FROM tblUser";
      // Instantiate and execute the command
      cmmUserMan = new SqlCommand(strSQL, cnnUserMan);
      drdTest = cmmUserMan.ExecuteReader();
   }

   // Listing 3A-24
   public void ExecuteScalarCommand() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUserMan;
      int intNumRows;
      string strSQL;

      // Instantiate the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Open the connection
      cnnUserMan.Open();
      // Build query string
      strSQL = "SELECT Id FROM tblUser";
      // Instantiate the command
      cmmUserMan = new SqlCommand(strSQL, cnnUserMan);
      // Save the number of rows in the table
      intNumRows = (int) cmmUserMan.ExecuteScalar();
   }

   // Listing 3A-25
   public void ExecuteXmlReaderCommand() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUserMan;
      XmlReader drdTest;
      string strSQL;

      // Instantiate the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Open the connection
      cnnUserMan.Open();
      // Build query string to return result set as XML
      strSQL = "SELECT * FROM tblUser FOR XML AUTO";
      // Instantiate the command
      cmmUserMan = new SqlCommand(strSQL, cnnUserMan);
      // Retrieve the rows as XML
      drdTest = cmmUserMan.ExecuteXmlReader();
   }
	
   // Listing 3A-26
   public void CheckCommandTimeoutPropertyException() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUserMan;
      string strSQL;

      try {
         // Instantiate the connection
         cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
         // Open the connection
         cnnUserMan.Open();
         // Build query string
         strSQL = "SELECT * FROM tblUser";
         // Instantiate the command
         cmmUserMan = new SqlCommand(strSQL, cnnUserMan);
         // Change command timeout
         cmmUserMan.CommandTimeout = -1;
      }
      catch (ArgumentException objException) {
         // Check if we tried to set command timeout to an invalid value
         if (objException.TargetSite.Name == "set_CommandTimeout") {
            MessageBox.Show("The CommandTimeout property threw the exception.");
         }
      }
   }

   // Listing 3A-27
   public void CheckCommandTypePropertyException() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUserMan;
      string strSQL;

      try {
         // Instantiate the connection
         cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
         // Open the connection
         cnnUserMan.Open();
         // Build query string
         strSQL = "SELECT * FROM tblUser";
         // Instantiate the command
         cmmUserMan = new SqlCommand(strSQL, cnnUserMan);
         // Change command type
         cmmUserMan.CommandType = CommandType.TableDirect;
      }
      catch (ArgumentException objException) {
         // Check if we tried to set command type to an invalid value
         if (objException.TargetSite.Name == "set_CommandType") {
            MessageBox.Show("The CommandType property threw the exception.");
         }
      }
   }

   // Listing 3A-28
   public void CheckPrepareMethodException() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUserMan;
      string strSQL;

      try {
         // Instantiate the connection
         cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
         // Open the connection
         // If the following line is commented out, the ValidateCommand exception will be thrown
         //cnnUserMan.Open()
         // Build query string
         strSQL = "SELECT * FROM tblUser";
         // Instantiate the command
         cmmUserMan = new SqlCommand(strSQL, cnnUserMan);
         // Prepare command
         cmmUserMan.Prepare();
      }
      catch (InvalidOperationException objException) {
         // Check if we tried to prepare the command on an invalid connection
         if (objException.TargetSite.Name == "ValidateCommand") {
            MessageBox.Show("The Prepare method threw the exception.");
         }
      }
   }

   // Listing 3A-29
   public void CheckUpdateRowSourcePropertyException() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUserMan;
      string strSQL;

      try {
         // Instantiate the connection
         cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
         // Open the connection
         cnnUserMan.Open();
         // Build query string
         strSQL = "SELECT * FROM tblUser";
         // Instantiate the command
         cmmUserMan = new SqlCommand(strSQL, cnnUserMan);
         // Change Row source Update
         cmmUserMan.UpdatedRowSource = UpdateRowSource.OutputParameters+3;
      }
      catch (ArgumentException objException) {
         // Check if we tried to set the row source update to an invalid value
         if (objException.TargetSite.Name == "set_UpdatedRowSource") {
            MessageBox.Show("The UpdatedRowSource property threw the exception.");
         }
      }
   }

   // Listing 3A-30
   public void InstantiateDataReader() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUserMan;
      SqlDataReader drdUserMan;
      string strSQL;

      // Instantiate the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Open the connection
      cnnUserMan.Open();
      // Build query string
      strSQL = "SELECT * FROM tblUser";
      // Instantiate the command
      cmmUserMan = new SqlCommand(strSQL, cnnUserMan);
      // Instantiate data reader using the ExecuteReader method 
      // of the command class
      drdUserMan = cmmUserMan.ExecuteReader();
   }

   // Listing 3A-31
   public void ReadRowsFromDataReader() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUserMan;
      SqlDataReader drdUser;
      string strSQL;
      long lngCounter = 0;

      // Instantiate the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Open the connection
      cnnUserMan.Open();
      // Build query string
      strSQL = "SELECT * FROM tblUser";
      // Instantiate the command
      cmmUserMan = new SqlCommand(strSQL, cnnUserMan);
      // Excute command and return rows in data reader
      drdUser = cmmUserMan.ExecuteReader();
      // Loop through all the returned rows
      while (drdUser.Read()) {
         ++lngCounter;
      }

      // Display the number of rows returned
      MessageBox.Show(lngCounter.ToString());
   }

   // Listing 3A-32
   public void CheckForNullValueInColumn(int intColumn) {
      SqlConnection cnnUserMan;
      SqlCommand cmmUserMan;
      SqlDataReader drdUser;
      string strSQL;

      // Instantiate the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Open the connection
      cnnUserMan.Open();
      // Build query string
      strSQL = "SELECT * FROM tblUser";
      // Instantiate the command
      cmmUserMan = new SqlCommand(strSQL, cnnUserMan);
      // Excute command and return rows in data reader
      drdUser = cmmUserMan.ExecuteReader();
      // Advance reader to first row
      drdUser.Read();
      // Check if the column contains a NULL value
      if (drdUser.IsDBNull(intColumn)) {
         MessageBox.Show("Column " + intColumn.ToString() + " contains a NULL value!");
      }
      else {
         MessageBox.Show("Column " + intColumn.ToString() + " does not contain a NULL value!");
      }
   }

   // Listing 3A-33
   public void InstantiateXmlReader() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUserMan;
      XmlReader xrdUserMan;
      string strSQL;

      // Instantiate the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Open the connection
      cnnUserMan.Open();
      // Build query string
      strSQL = "SELECT * FROM tblUser FOR XML AUTO";
      // Instantiate the command
      cmmUserMan = new SqlCommand(strSQL, cnnUserMan);
      // Instantiate data reader using the ExecuteXmlReader method 
      // of the command class
      xrdUserMan = cmmUserMan.ExecuteXmlReader();
   }

   // Listing 3A-34
   public void ReadRowsFromXmlReader() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUserMan;
      XmlReader xrdUserMan;
      string strSQL;
      long lngCounter = 0;

      // Instantiate the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Open the connection
      cnnUserMan.Open();
      // Build query string
      strSQL = "SELECT * FROM tblUser FOR XML AUTO";
      // Instantiate the command
      cmmUserMan = new SqlCommand(strSQL, cnnUserMan);
      // Excute command and return rows in data reader
      xrdUserMan = cmmUserMan.ExecuteXmlReader();
      // Loop through all the returned rows
      while (xrdUserMan.Read()) {
         ++lngCounter;
      }

      // Display the number of rows returned
      MessageBox.Show(lngCounter.ToString());
   }

   // Listing 3A-35
   public void InstantiateAndInitializeDataAdapter() {
      const string STR_SQL_USER = "SELECT * FROM tblUser";

      SqlConnection cnnUserMan;
      SqlCommand cmmUser;
      SqlDataAdapter dadDefaultConstructor;
      SqlDataAdapter dadSqlCommandArgument;
      SqlDataAdapter dadSqlConnectionArgument;
      SqlDataAdapter dadStringArguments;

      // Instantiate and open the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();
      // Instantiate the command
      cmmUser = new SqlCommand(STR_SQL_USER);

      // Instantiate data adapters
      dadDefaultConstructor = new SqlDataAdapter();
      dadSqlCommandArgument = new SqlDataAdapter(cmmUser);
      dadSqlConnectionArgument = new SqlDataAdapter(STR_SQL_USER, cnnUserMan);
      dadStringArguments = new SqlDataAdapter(STR_SQL_USER, STR_CONNECTION_STRING);
      // Initialize data adapters
      dadDefaultConstructor.SelectCommand = cmmUser;
      dadDefaultConstructor.SelectCommand.Connection = cnnUserMan;
   }

   // Listing 3A-38
   public void SetDataAdapterCommandProperties() {
      const string STR_SQL_USER_SELECT = "SELECT * FROM tblUser";
      const string STR_SQL_USER_DELETE  = "DELETE FROM tblUser WHERE Id=@Id";
      const string STR_SQL_USER_INSERT = "INSERT INTO tblUser(FirstName, " +
               "LastName, LoginName, Password) VALUES(@FirstName, @LastName, @LoginName, @Password)";
      const string STR_SQL_USER_UPDATE = "UPDATE tblUser SET FirstName=" +
               "@FirstName, LastName=@LastName, LoginName=@LoginName, Password=@Password WHERE Id=@Id";

      SqlConnection cnnUserMan;
      SqlCommand cmmUserSelect;
      SqlCommand cmmUserDelete;
      SqlCommand cmmUserInsert;
      SqlCommand cmmUserUpdate;
      SqlDataAdapter dadUserMan;
      SqlParameter prmSQLDelete, prmSQLUpdate;

      // Instantiate and open the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();
      // Instantiate the commands
      cmmUserSelect = new SqlCommand(STR_SQL_USER_SELECT, cnnUserMan);
      cmmUserDelete = new SqlCommand(STR_SQL_USER_DELETE, cnnUserMan);
      cmmUserInsert = new SqlCommand(STR_SQL_USER_INSERT, cnnUserMan);
      cmmUserUpdate = new SqlCommand(STR_SQL_USER_UPDATE, cnnUserMan);

      // Instantiate data adapter
      dadUserMan = new SqlDataAdapter(STR_SQL_USER_SELECT, cnnUserMan);
      // Set data adapter command properties
      dadUserMan.SelectCommand = cmmUserSelect;
      dadUserMan.InsertCommand = cmmUserInsert;
      dadUserMan.DeleteCommand = cmmUserDelete;
      dadUserMan.UpdateCommand = cmmUserUpdate;

      // Add Delete command parameters
      prmSQLDelete = dadUserMan.DeleteCommand.Parameters.Add("@Id", SqlDbType.Int, 4, "Id");
      prmSQLDelete.Direction = ParameterDirection.Input;
      prmSQLDelete.SourceVersion = DataRowVersion.Original;

      // Add Update command parameters
      cmmUserUpdate.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, "FirstName");
      cmmUserUpdate.Parameters.Add("@LastName", SqlDbType.VarChar, 50, "LastName");
      cmmUserUpdate.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, "LoginName");
      cmmUserUpdate.Parameters.Add("@Password", SqlDbType.VarChar, 50, "Password");

      prmSQLUpdate = dadUserMan.UpdateCommand.Parameters.Add("@Id", SqlDbType.Int, 4, "Id");
      prmSQLUpdate.Direction = ParameterDirection.Input;
      prmSQLUpdate.SourceVersion = DataRowVersion.Original;

      // Add insert command parameters
      cmmUserInsert.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, "FirstName");
      cmmUserInsert.Parameters.Add("@LastName", SqlDbType.VarChar, 50, "LastName");
      cmmUserInsert.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, "LoginName");
      cmmUserInsert.Parameters.Add("@Password", SqlDbType.VarChar, 50, "Password");
   }


   // Listing 3A-41-1
   protected static void OnFillError(object sender, FillErrorEventArgs args) {
      // Display a message indicating what table an error occurred in and
      // let the user decided whether to continue populating the dataset
      args.Continue = (MessageBox.Show("There were errors filling the Data Table: " + args.DataTable + 
         ". Do you want to continue?", "Continue Updating", MessageBoxButtons.YesNo, 
         MessageBoxIcon.Question) == DialogResult.Yes);
   }

   // Listing 3A-41-2
   public void TriggerFillErrorEvent() {
      DataSet dstUser = new DataSet("Users");
      // Declare and instantiate connection
      SqlConnection cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Declare and instantiate data adapter
      SqlDataAdapter prdadUserMan = new SqlDataAdapter("SELECT * FROM tblUser", 
         cnnUserMan);
      // Set up event handler
      prdadUserMan.FillError  += new FillErrorEventHandler(OnFillError);

      // Open the connection
      cnnUserMan.Open();
      // Populate the dataset
      prdadUserMan.Fill(dstUser, "tblUser"); 
   }

   // Listing 3A-42-1
   protected static void OnRowUpdating(object sender, SqlRowUpdatingEventArgs e) {
      // Display a message showing all the Command properties
      // if a command exists
      if (! (e.Command == null)) {
         MessageBox.Show("Command Properties:\n\n" + 
            "CommandText: " + e.Command.CommandText + "\n" + 
            "CommandTimeout: " + e.Command.CommandTimeout.ToString() + "\n"  + 
            "CommandType: " + e.Command.CommandType.ToString(),
            "RowUpdating", MessageBoxButtons.OK, 
            MessageBoxIcon.Information);
      }
      // Display a message showing all the Errors properties, 
      // if an error exists
      if (! (e.Errors == null)) {
         MessageBox.Show("Errors Properties:\n\n" + 
            "HelpLink: " + e.Errors.HelpLink + "\n"  + 
            "Message: " + e.Errors.Message + "\n"  + 
            "Source: " + e.Errors.Source + "\n" +
            "StackTrace: " + e.Errors.StackTrace  + "\n" +
            "TargetSite: " + e.Errors.TargetSite  + "\n",
            "RowUpdating", MessageBoxButtons.OK, 
            MessageBoxIcon.Information);
      }
      // Display a message showing other misc. properties
      MessageBox.Show("Misc. Properties:\n\n" + 
         "StatementType: " + e.StatementType.ToString() + "\n"  + 
         "Status: " + e.Status.ToString(),
         "RowUpdating", MessageBoxButtons.OK, 
         MessageBoxIcon.Information);
   }

   // Listing 3A-42-2
   protected static void OnRowUpdated(object sender, SqlRowUpdatedEventArgs e) {
      // Display a message showing all the Command properties
      // if a command exists
      if (! (e.Command == null)) {
         MessageBox.Show("Command Properties:\n\n" + 
            "CommandText: " + e.Command.CommandText + "\n" + 
            "CommandTimeout: " + e.Command.CommandTimeout.ToString() + "\n"  + 
            "CommandType: " + e.Command.CommandType.ToString(),
            "RowUpdated", MessageBoxButtons.OK, 
            MessageBoxIcon.Information);
      }
      // Display a message showing all the Errors properties, 
      // if an error exists
      if (! (e.Errors == null)) {
         MessageBox.Show("Errors Properties:\n\n" + 
            "HelpLink: " + e.Errors.HelpLink + "\n"  + 
            "Message: " + e.Errors.Message + "\n"  + 
            "Source: " + e.Errors.Source + "\n" +
            "StackTrace: " + e.Errors.StackTrace  + "\n" +
            "TargetSite: " + e.Errors.TargetSite  + "\n",
            "RowUpdated", MessageBoxButtons.OK, 
            MessageBoxIcon.Information);
      }
      // Display a message showing other misc. properties
      MessageBox.Show("Misc. Properties:\n\n" + 
         "StatementType: " + e.StatementType.ToString() + "\n"  + 
         "Status: " + e.Status.ToString(),
         "RowUpdated", MessageBoxButtons.OK, 
         MessageBoxIcon.Information);
   }

   // Listing 3A-42-3
   public void TriggerRowUpdateEvents() {
      DataSet dstUser = new DataSet("Users");
      // Declare and instantiate connection
      SqlConnection cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Declare and instantiate data adapter
      SqlDataAdapter dadUserMan = new SqlDataAdapter("SELECT * FROM tblUser", 
         cnnUserMan);
      // Declare and instantiate command builder
      SqlCommandBuilder cmbUser = new SqlCommandBuilder(dadUserMan);
      // Set up event handlers
      dadUserMan.RowUpdating  += new SqlRowUpdatingEventHandler(OnRowUpdating);
      dadUserMan.RowUpdated  += new SqlRowUpdatedEventHandler(OnRowUpdated);

      // Open the connection
      cnnUserMan.Open();
      // Populate the dataset
      dadUserMan.Fill(dstUser, "tblUser"); 
      // Modify second row
      dstUser.Tables["tblUser"].Rows[1]["FirstName"] = "Tom";
      // Populate the data source
      dadUserMan.Update(dstUser, "tblUser"); 
   }

   // Listing 3A-43
   public void SetDataAdapterCommandPropertiesUsingCommandBuilder() {
      const string STR_SQL_USER_SELECT = "SELECT * FROM tblUser";

      SqlConnection cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      SqlCommand cmmUserSelect = new SqlCommand(STR_SQL_USER_SELECT, cnnUserMan);
      SqlDataAdapter dadUserMan = new SqlDataAdapter(cmmUserSelect);
      SqlCommandBuilder cmbUser = new SqlCommandBuilder(dadUserMan);
      DataSet dstDummy = new DataSet("DummyDataSet");

      // Open the connection
      cnnUserMan.Open();

      // Fill dummy data set, update row in table and update dataset
      dadUserMan.Fill(dstDummy, "tblUser");
      dstDummy.Tables["tblUser"].Rows.Add(new Object[7] {null, null, null, "1st Name", 
         "LastName", DateTime.Now.ToString().Replace(" ", ""), ""}); 
      dadUserMan.Update(dstDummy, "tblUser");
   }

   public void InstantiateDataSet() {
      DataSet dstUnnamed1 = new DataSet();
      DataSet dstNamed1 = new DataSet("UserManDataSet");

      DataSet dstUnnamed2;
      DataSet dstNamed2;

      dstUnnamed2 = new DataSet();
      dstNamed2 = new DataSet("UserManDataSet");
   }

   // Listing 3B-2-1
   private static void OnMergeFailed(object sender, MergeFailedEventArgs args) {
      // Display a message detailing the merge conflict
      MessageBox.Show("There were errors when merging the datasets:\n\n" + 
         args.Conflict + " The conflict happened in table " + args.Table + ".");
   }

   // Listing 3B-2-2
   public void TriggerMergeFailureEvent() {
      // Declare and instantiate data sets
      DataSet dstUser1 = new DataSet("Users1");
      DataSet dstUser2 = new DataSet("Users2");

      // Declare and instantiate connections
      SqlConnection cnnUserMan1 = new SqlConnection(STR_CONNECTION_STRING);
      SqlConnection cnnUserMan2 = new SqlConnection("Data Source=DBSERVER;User Id=UserMan;Password=userman;Initial Catalog=UserMan");
      // Declare and instantiate data adapters
      SqlDataAdapter prdadUserMan1 = new SqlDataAdapter("SELECT * FROM tblUser", 
         cnnUserMan1);
      SqlDataAdapter prdadUserMan2 = new SqlDataAdapter("SELECT * FROM tblUser", 
         cnnUserMan2);
      // Set up event handler
      dstUser1.MergeFailed += new MergeFailedEventHandler(OnMergeFailed);

      // Open the connections
      cnnUserMan1.Open();
      cnnUserMan2.Open();
      // Populate the datasets
      prdadUserMan1.Fill(dstUser1, "tblUser"); 
      prdadUserMan2.Fill(dstUser2, "tblUser"); 
      // Close the connections
      cnnUserMan1.Close();
      cnnUserMan2.Close();

      // Merge the data sets
      dstUser1.Merge(dstUser2);
   }

   // Listing 3B-4
   public void UpdateDataSet() {
      const string STR_SQL_USER_SELECT = "SELECT * FROM tblUser";
      const string STR_SQL_USER_DELETE = "DELETE FROM tblUser WHERE Id=@Id";
      const string STR_SQL_USER_INSERT = "INSERT INTO tblUser(FirstName" +
               ", LastName, LoginName, Password) VALUES(@FirstName, @LastName, @LoginName, @Password)";
      const string STR_SQL_USER_UPDATE = "UPDATE tblUser SET FirstName=" +
               "@FirstName, LastName=@LastName, LoginName=@LoginName, Password=@Password WHERE Id=@Id";

      SqlConnection cnnUserMan;
      SqlCommand cmmUserSelect;
      SqlCommand cmmUserDelete;
      SqlCommand cmmUserInsert;
      SqlCommand cmmUserUpdate;
      SqlDataAdapter dadUserMan;
      DataSet dstUserMan, dstChanges;
      DataRow drwUser;
      SqlParameter prmSQLDelete, prmSQLUpdate;

      // Instantiate and open the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();

      // Instantiate the commands
      cmmUserSelect = new SqlCommand(STR_SQL_USER_SELECT, cnnUserMan);
      cmmUserDelete = new SqlCommand(STR_SQL_USER_DELETE, cnnUserMan);
      cmmUserInsert = new SqlCommand(STR_SQL_USER_INSERT, cnnUserMan);
      cmmUserUpdate = new SqlCommand(STR_SQL_USER_UPDATE, cnnUserMan);

      // Instantiate data adapter
      dadUserMan = new SqlDataAdapter(STR_SQL_USER_SELECT, cnnUserMan);
      // Set data adapter command properties
      dadUserMan.SelectCommand = cmmUserSelect;
      dadUserMan.InsertCommand = cmmUserInsert;
      dadUserMan.DeleteCommand = cmmUserDelete;
      dadUserMan.UpdateCommand = cmmUserUpdate;

      // Add Delete command parameters
      prmSQLDelete = dadUserMan.DeleteCommand.Parameters.Add("@Id", SqlDbType.Int, 0, "Id");
      prmSQLDelete.Direction = ParameterDirection.Input;
      prmSQLDelete.SourceVersion = DataRowVersion.Original;

      // Add Update command parameters
      cmmUserUpdate.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, "FirstName");
      cmmUserUpdate.Parameters.Add("@LastName", SqlDbType.VarChar, 50, "LastName");
      cmmUserUpdate.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, "LoginName");
      cmmUserUpdate.Parameters.Add("@Password", SqlDbType.VarChar, 50, "Password");

      prmSQLUpdate = dadUserMan.UpdateCommand.Parameters.Add("@Id", SqlDbType.Int, 0, "Id");
      prmSQLUpdate.Direction = ParameterDirection.Input;
      prmSQLUpdate.SourceVersion = DataRowVersion.Original;

      // Add insert command parameters
      cmmUserInsert.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, "FirstName");
      cmmUserInsert.Parameters.Add("@LastName", SqlDbType.VarChar, 50, "LastName");
      cmmUserInsert.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, "LoginName");
      cmmUserInsert.Parameters.Add("@Password", SqlDbType.VarChar, 50, "Password");

      // Instantiate dataset
      dstUserMan = new DataSet();
      // Populate the data set
      dadUserMan.Fill(dstUserMan, "tblUser");

      // Add new row
      drwUser = dstUserMan.Tables["tblUser"].NewRow();
      drwUser = dstUserMan.Tables["tblUser"].NewRow();
      drwUser["FirstName"] = "New User";
      drwUser["LastName"] = "New User LastName";
      drwUser["LoginName"] = "NewUser";
      drwUser["Password"] = "password";
      dstUserMan.Tables["tblUser"].Rows.Add(drwUser);

      // Update an existing row (with index 3)
      dstUserMan.Tables["tblUser"].Rows[3]["FirstName"] = "FirstName";
      dstUserMan.Tables["tblUser"].Rows[3]["LastName"] = "LastName";
      dstUserMan.Tables["tblUser"].Rows[3]["LoginName"] = "User3";

      // Delete row with index 4
      //dstUserMan.Tables["tblUser"].Rows[4].Delete();

      // Check if any data has changed in the data set
      if (dstUserMan.HasChanges()) {
         // Save all changed rows in a new data set
         dstChanges = dstUserMan.GetChanges();
         // Check if the changed rows contains any errors
         if (dstChanges.HasErrors) {
            // Reject the changes
            dstUserMan.RejectChanges();
         }
         else {
            // Update the data source
            dadUserMan.Update(dstChanges, "tblUser");
         }
      }
   }

   public void ClearDataSet() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUser;
      SqlDataAdapter dadUser;
      DataSet dstUser;

      // Instantiate and open the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();
      // Instantiate the command
      cmmUser = new SqlCommand("SELECT * FROM tblUser", cnnUserMan);
      // Instantiate and initialize the data adapter
      dadUser = new SqlDataAdapter();
      dadUser.SelectCommand = cmmUser;
      // Instantiate data set
      dstUser = new DataSet();
      // Fill the data set
      dadUser.Fill(dstUser, "tblUser");
      // Do your stuff
      // ...
      // Clear the data from the data set
      dstUser.Clear();
   }

   public void CloneDataSetStructure() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUser;
      SqlDataAdapter dadUser;
      DataSet dstUser;
      DataSet dstClone;

      // Instantiate and open the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();
      // Instantiate the command and data set
      cmmUser = new SqlCommand("SELECT * FROM tblUser", cnnUserMan);
      dstUser = new DataSet();
      // Instantiate and initialize the data adapter
      dadUser = new SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan);
      dadUser.SelectCommand = cmmUser;
      // Fill the data set
      dadUser.Fill(dstUser, "tblUser");
      // Clone the data set
      dstClone = dstUser.Clone();
   }

   public void CopyDataSetStructureAndData() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUser;
      SqlDataAdapter dadUser;
      DataSet dstUser;
      DataSet dstCopy;

      // Instantiate and open the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();
      // Instantiate the command and data set
      cmmUser = new SqlCommand("SELECT * FROM tblUser", cnnUserMan);
      dstUser = new DataSet();
      // Instantiate and initialize the data adapter
      dadUser = new SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan);
      dadUser.SelectCommand = cmmUser;
      // Fill the data set
      dadUser.Fill(dstUser, "tblUser");
      // Copy the data set
      dstCopy = dstUser.Copy();
   }

   // Listing 3B-5
   public void MergeDataSetWithDataRows() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUser;
      SqlDataAdapter dadUser;
      DataSet dstUser;
      DataTable dtbUser;
      DataRow[] arrdrwUser = new DataRow[1];
      DataRow drwUser;

      // Instantiate and open the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();
      // Instantiate the command, data set and data table
      cmmUser = new SqlCommand("SELECT * FROM tblUser", cnnUserMan);
      dstUser = new DataSet();
      dtbUser = new DataTable();
      // Instantiate and initialize the data adapter
      dadUser = new SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan);
      dadUser.SelectCommand = cmmUser;
      // Fill the data set
      dadUser.Fill(dstUser, "tblUser");
      // Create new row and fill with data
      drwUser = dstUser.Tables["tblUser"].NewRow();
      drwUser["LoginName"] = "NewUser1";
      drwUser["FirstName"] = "New";
      drwUser["LastName"] = "User";
      arrdrwUser.SetValue(drwUser, 0);
      // Merge the data set with the data row array
      dstUser.Merge(arrdrwUser);
   }

   // Listing 3B-6
   public void MergeDataSets() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUser;
      SqlDataAdapter dadUser;
      DataSet dstUser;
      DataSet dstCopy;

      // Instantiate and open the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();
      // Instantiate the command and data set
      cmmUser = new SqlCommand("SELECT * FROM tblUser", cnnUserMan);
      dstUser = new DataSet();
      // Instantiate and initialize the data adapter
      dadUser = new SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan);
      dadUser.SelectCommand = cmmUser;
      // Fill the data set
      dadUser.Fill(dstUser, "tblUser");
      // Copy the data set
      dstCopy = dstUser.Copy();
      // Do your stuff with the data sets
      // ...
      // Merge the two data sets
      dstUser.Merge(dstCopy);
   }

   // Listing 3B-7
   public void MergeDataSetWithDataTable() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUser;
      SqlDataAdapter dadUser;
      DataSet dstUser;
      DataTable dtbUser;

      // Instantiate and open the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();
      // Instantiate the command, data set and data table
      cmmUser = new SqlCommand("SELECT * FROM tblUser", cnnUserMan);
      dstUser = new DataSet();
      dtbUser = new DataTable();
      // Instantiate and initialize the data adapter
      dadUser = new SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan);
      dadUser.SelectCommand = cmmUser;
      // Fill the data set and data table
      dadUser.Fill(dstUser, "tblUser");
      dadUser.Fill(dtbUser);
      // Do your stuff with the data set and the data table
      // ...
      // Merge the data set with the data table
      dstUser.Merge(dtbUser);
   }

   // Listing 3B-8
   public void DetectAllDataSetChanges() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUser;
      SqlDataAdapter dadUser;
      DataSet dstUser;
      DataSet dstChanges;

      // Instantiate and open the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();
      // Instantiate the command and data set
      cmmUser = new SqlCommand("SELECT * FROM tblUser", cnnUserMan);
      dstUser = new DataSet();
      // Instantiate and initialize the data adapter
      dadUser = new SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan);
      dadUser.SelectCommand = cmmUser;
      // Fill the data set
      dadUser.Fill(dstUser, "tblUser");
      // Do your stuff with the data set
      // ...
      // Check if any data has changed in the data set
      if (dstUser.HasChanges()) {
         // Save all changes in a new data set
         dstChanges = dstUser.GetChanges();
      }
   }

   // Listing 3B-9
   public void DetectDifferentDataSetChanges() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUser;
      SqlDataAdapter dadUser;
      DataSet dstUser;
      DataSet dstChanges;
      DataSet dstAdditions;
      DataSet dstDeletions;

      // Instantiate and open the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();
      // Instantiate the command and data set
      cmmUser = new SqlCommand("SELECT * FROM tblUser", cnnUserMan);
      dstUser = new DataSet();
      // Instantiate and initialize the data adapter
      dadUser = new SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan);
      dadUser.SelectCommand = cmmUser;
      // Fill the data set
      dadUser.Fill(dstUser, "tblUser");
      // Do your stuff with the data set
      // ...
      // Check if any data has changed in the data set
      if (dstUser.HasChanges()) {
         // Save all modified rows in a new data set
         dstChanges = dstUser.GetChanges(DataRowState.Modified);
         // Save all added rows in a new data set
         dstAdditions = dstUser.GetChanges(DataRowState.Added);
         // Save all deleted rows in a new data set
         dstDeletions = dstUser.GetChanges(DataRowState.Deleted);
      }
   }

   // Listing 3B-10
   public void AcceptOrRejectDataSetChanges() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUser;
      SqlDataAdapter dadUser;
      DataSet dstUser, dstChanges;
      DataRow drwUser;

      // Instantiate and open the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();
      // Instantiate the command and the data set
      cmmUser = new SqlCommand("SELECT * FROM tblUser", cnnUserMan);
      dstUser = new DataSet();
      // Instantiate and initialize the data adapter
      dadUser = new SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan);
      dadUser.SelectCommand = cmmUser;
      // Fill the data set
      dadUser.Fill(dstUser, "tblUser");
      // Create a new data row with the schema from the user table
      drwUser = dstUser.Tables["tblUser"].NewRow();
      // Enter values in the data row columns
      drwUser["LoginName"] = "NewUser1";
      drwUser["FirstName"] = "New";
      drwUser["LastName"] = "User";
      // Add the data row to the user table
      dstUser.Tables["tblUser"].Rows.Add(drwUser);
      // Check if any data has changed in the data set
      if (dstUser.HasChanges()) {
         // Save all changed rows in a new data set
         dstChanges = dstUser.GetChanges();
         // Check if the changed rows contains any errors
         if (dstChanges.HasErrors) {
            // Display the row state of all rows before rejecting changes
            for (int intCounter = 0; intCounter <= dstUser.Tables[0].Rows.Count - 1; intCounter++) {
               MessageBox.Show("HasErrors=True, Before RejectChanges, RowState=" +
                  dstUser.Tables[0].Rows[intCounter].RowState.ToString() +
                  ", LoginName=" +
                  dstUser.Tables[0].Rows[intCounter]["LoginName"].ToString());
            }
            // Reject the changes to the data set
            dstUser.RejectChanges();
            // Display the row state of all rows after rejecting changes
            for (int intCounter = 0;  intCounter <= dstUser.Tables[0].Rows.Count - 1; intCounter++) {
               MessageBox.Show("HasErrors=True, After RejectChanges, RowState=" +
                  dstUser.Tables[0].Rows[intCounter].RowState.ToString() +
                  ", LoginName=" +
                  dstUser.Tables[0].Rows[intCounter]["LoginName"].ToString());
            }
         }																																																																
      }
      else {
         // Display the row state of all rows before accepting changes
         for (int intCounter = 0; intCounter <= dstUser.Tables[0].Rows.Count - 1; intCounter++) {
            MessageBox.Show("HasErrors=False, Before AcceptChanges, RowState=" +
               dstUser.Tables[0].Rows[intCounter].RowState.ToString() +
               ", LoginName=" +
               dstUser.Tables[0].Rows[intCounter]["LoginName"].ToString());
         }
         // Accept the changes to the data set
         dstUser.AcceptChanges();
         // Display the row state of all rows after accepting changes
         for (int intCounter = 0; intCounter <= dstUser.Tables[0].Rows.Count - 1; intCounter++) {
            MessageBox.Show("HasErrors=False, After AcceptChanges, RowState=" +
               dstUser.Tables[0].Rows[intCounter].RowState.ToString() +
               ", LoginName=" +
               dstUser.Tables[0].Rows[intCounter]["LoginName"].ToString());
         }
      }
   }

   public void InstantiateDataTable() {
      DataTable dtbNoArgumentsWithInitialize = new DataTable();
      DataTable dtbTableNameArgumentWithInitialize = new DataTable("TableName");

      DataTable dtbNoArgumentsWithoutInitialize;
      DataTable dtbTableNameArgumentWithoutInitialize;

      dtbNoArgumentsWithoutInitialize = new DataTable();
      dtbTableNameArgumentWithoutInitialize = new DataTable("TableName");
   }

   // Listing 3B-11
   public void BuildDataTable() {
      DataTable dtbUser;
      DataColumn dclUser;
      DataColumn[] arrdclPrimaryKey = new DataColumn[1];

      dtbUser = new DataTable("tblUser");

      // Create table structure
      dclUser = new DataColumn();
      dclUser.ColumnName = "Id";
      dclUser.DataType = Type.GetType("System.Int32");
      dclUser.AutoIncrement = true;
      dclUser.AutoIncrementSeed = 1;
      dclUser.AutoIncrementStep = 1;
      dclUser.AllowDBNull = false;
      // Add column to data table structure
      dtbUser.Columns.Add(dclUser);
      // Add column to PK array
      arrdclPrimaryKey[0] = dclUser;
      // Set primary key
      dtbUser.PrimaryKey = arrdclPrimaryKey;

      dclUser = new DataColumn();
      dclUser.ColumnName = "ADName";
      dclUser.DataType = Type.GetType("System.String");
      dclUser.MaxLength = 100;
      // Add column to data table structure
      dtbUser.Columns.Add(dclUser);

      dclUser = new DataColumn();
      dclUser.ColumnName = "ADSID";
      dclUser.DataType = Type.GetType("System.String");
      // Add column to data table structure
      dtbUser.Columns.Add(dclUser);

      dclUser = new DataColumn();
      dclUser.ColumnName = "FirstName";
      dclUser.DataType = Type.GetType("System.String");
      dclUser.MaxLength = 50;
      // Add column to data table structure
      dtbUser.Columns.Add(dclUser);

      dclUser = new DataColumn();
      dclUser.ColumnName = "LastName";
      dclUser.DataType = Type.GetType("System.String");
      dclUser.MaxLength = 50;
      // Add column to data table structure
      dtbUser.Columns.Add(dclUser);

      dclUser = new DataColumn();
      dclUser.ColumnName = "LoginName";
      dclUser.DataType = Type.GetType("System.String");
      dclUser.MaxLength = 50;
      dclUser.AllowDBNull = false;
      dclUser.Unique = true;
      // Add column to data table structure
      dtbUser.Columns.Add(dclUser);
      dclUser = new DataColumn();
      dclUser.ColumnName = "Password";
      dclUser.DataType = Type.GetType("System.String");
      dclUser.MaxLength = 50;
      dclUser.AllowDBNull = false;
      // Add column to data table structure
      dtbUser.Columns.Add(dclUser);
   }

   public void ClearDataTable() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUser;
      SqlDataAdapter dadUser;
      DataTable dtbUser;

      // Instantiate and open the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();

      // Instantiate the command
      cmmUser = new SqlCommand("SELECT * FROM tblUser", cnnUserMan);
      // Instantiate and initialize the data adapter
      dadUser = new SqlDataAdapter();
      dadUser.SelectCommand = cmmUser;
      // Instantiate data table
      dtbUser = new DataTable("tblUser");
      // Fill the data table
      dadUser.Fill(dtbUser);
      // Do your stuff
      // ...
      // Clear the data from the data table
      dtbUser.Clear();
   }

   // Listing 3B-12
   public void CloneDataTableStructure() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUser;
      SqlDataAdapter dadUser;
      DataTable dtbUser;
      DataTable dtbClone;

      // Instantiate and open the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();
      // Instantiate the command and data table
      cmmUser = new SqlCommand("SELECT * FROM tblUser", cnnUserMan);
      dtbUser = new DataTable();
      // Instantiate and initialize the data adapter
      dadUser = new SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan);
      dadUser.SelectCommand = cmmUser;
      // Fill the data table
      dadUser.Fill(dtbUser);
      // Clone the data table
      dtbClone = dtbUser.Clone();
   }

   // Listing 3B-13
   public void CopyDataTable() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUser;
      SqlDataAdapter dadUser;
      DataTable dtbUser;
      DataTable dtbCopy;

      // Instantiate and open the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();
      // Instantiate the command and data tables
      cmmUser = new SqlCommand("SELECT * FROM tblUser", cnnUserMan);
      dtbUser = new DataTable();
      // Instantiate and initialize the data adapter
      dadUser = new SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan);
      dadUser.SelectCommand = cmmUser;
      // Fill the data table
      dadUser.Fill(dtbUser);
      // Copy the data table
      dtbCopy = dtbUser.Copy();
   }

   // Listing 3B-14
   public void SearchDataTable() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUser;
      SqlDataAdapter dadUser;
      DataTable dtbUser;

      // Instantiate and open the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();
      // Instantiate the command and data table
      cmmUser = new SqlCommand("SELECT * FROM tblUser", cnnUserMan);
      dtbUser = new DataTable();
      // Instantiate and initialize the data adapter
      dadUser = new SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan);
      dadUser.SelectCommand = cmmUser;
      // Fill the data table
      dadUser.Fill(dtbUser);
      // Filter the data table view
      dtbUser.DefaultView.RowFilter = "LastName = 'Doe'";

      // Loop through all the rows in the data table view
      for (int intCounter = 0; intCounter <= dtbUser.DefaultView.Count - 1; intCounter++) {
         MessageBox.Show(dtbUser.DefaultView[intCounter].Row["LastName"].ToString());
      }
   }

   // Listing 3B-15
   public void CopyRowsInDataTable() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUser;
      SqlDataAdapter dadUser;
      DataTable dtbUser;
      SqlCommandBuilder cmbUser;

      // Instantiate and open the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();
      // Instantiate the command and data table
      cmmUser = new SqlCommand("SELECT * FROM tblUser", cnnUserMan);
      dtbUser = new DataTable();
      // Instantiate and initialize the data adapter
      dadUser = new SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan);
      dadUser.SelectCommand = cmmUser;
      cmbUser = new SqlCommandBuilder(dadUser);
      // Fill the data table
      dadUser.Fill(dtbUser);

      // Copy a row from the same table using ImportRow method
      dtbUser.ImportRow(dtbUser.Rows[0]);	
      // Make sure the Update method detects the new row
      dtbUser.Rows[dtbUser.Rows.Count - 1]["LoginName"] = "NewLogin1";

      // Copy the first row from the same table using the LoadDataRow
      // If you change the last argument of this method to true, the
      // RowState property will be set to Unchanged
      dtbUser.LoadDataRow(new Object[7] {null, dtbUser.Rows[0]["ADName"], 
                                           dtbUser.Rows[0]["ADSID"], dtbUser.Rows[0]["FirstName"], 
                                           dtbUser.Rows[0]["LastName"], "NewLogin2", 
                                           dtbUser.Rows[0]["Password"]}, false);

      // Loop through all the rows in the data table,
      // displaying the Id and RowState value
      for (int intCounter = 0; intCounter <= dtbUser.Rows.Count - 1; intCounter++) {
         MessageBox.Show(dtbUser.Rows[intCounter]["Id"].ToString() + " " +
            dtbUser.Rows[intCounter].RowState.ToString());
      }

      // Update the data source
      dadUser.Update(dtbUser);
   }

   // Listing 3B-16-1
   private static void OnColumnChanging(object sender, DataColumnChangeEventArgs e) {
      // Display a message showing some of the Column properties
      MessageBox.Show("Column Properties:\n\n" + 
         "ColumnName: " + e.Column.ColumnName + "\n" + 
         "DataType: " + e.Column.DataType.ToString() + "\n"  + 
         "CommandType: " + e.Column.Table.ToString() + "\n"  + 
         "Original Value: " + e.Row[e.Column.ColumnName, DataRowVersion.Original].ToString() + "\n"  + 
         "Proposed Value: " + e.ProposedValue.ToString(),
         "ColumnChanging", MessageBoxButtons.OK, 
         MessageBoxIcon.Information);
   }

   // Listing 3B-16-2
   private static void OnColumnChanged(object sender, DataColumnChangeEventArgs e) {
      // Display a message showing some of the Column properties
      MessageBox.Show("Column Properties:\n\n" + 
         "ColumnName: " + e.Column.ColumnName + "\n" + 
         "DataType: " + e.Column.DataType.ToString() + "\n"  + 
         "CommandType: " + e.Column.Table.ToString() + "\n"  + 
         "Original Value: " + e.Row[e.Column.ColumnName, DataRowVersion.Original].ToString() + "\n"  + 
         "Proposed Value: " + e.ProposedValue.ToString(),
         "ColumnChanged", MessageBoxButtons.OK, 
         MessageBoxIcon.Information);
   }

   // Listing 3B-16-3
   public void TriggerColumnChangeEvents() {
      DataTable dtbUser = new DataTable("tblUser");
      // Declare and instantiate connection
      SqlConnection cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Declare and instantiate data adapter
      SqlDataAdapter dadUserMan = new SqlDataAdapter("SELECT * FROM tblUser", 
         cnnUserMan);
      // Set up event handlers
      dtbUser.ColumnChanging += new DataColumnChangeEventHandler(OnColumnChanging);
      dtbUser.ColumnChanged += new DataColumnChangeEventHandler(OnColumnChanged);

      // Open the connection
      cnnUserMan.Open();
      // Populate the data table
      dadUserMan.Fill(dtbUser); 
      // Modify second row, this triggers the Column Change events
      dtbUser.Rows[1]["FirstName"] = "Tom";
   }

   // Listing 3B-17-1
   private static void OnRowChanging(object sender, DataRowChangeEventArgs e) {
      // Display a message showing some of the Row properties
      MessageBox.Show("Row Properties:\n\n" + 
         "RowState: " + e.Row.RowState.ToString() + "\n" + 
         "Table: " + e.Row.Table.ToString() + "\n" + 
         "Action: " + e.Action.ToString(),
         "RowChanging", MessageBoxButtons.OK, 
         MessageBoxIcon.Information);
   }

   // Listing 3B-17-2
   private static void OnRowChanged(object sender, DataRowChangeEventArgs e) {
      // Display a message showing some of the Row properties
      MessageBox.Show("Row Properties:\n\n" + 
         "RowState: " + e.Row.RowState.ToString() + "\n" + 
         "Table: " + e.Row.Table.ToString() + "\n" + 
         "Action: " + e.Action.ToString(),
         "RowChanged", MessageBoxButtons.OK, 
         MessageBoxIcon.Information);
   }

   // Listing 3B-17-3
   public void TriggerRowChangeEvents() {
      DataTable dtbUser = new DataTable("tblUser");
      // Declare and instantiate connection
      SqlConnection cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Declare and instantiate data adapter
      SqlDataAdapter dadUserMan = new SqlDataAdapter("SELECT * FROM tblUser", 
         cnnUserMan);
      // Set up event handlers
      dtbUser.RowChanging += new DataRowChangeEventHandler(OnRowChanging);
      dtbUser.RowChanged += new DataRowChangeEventHandler(OnRowChanged);

      // Open the connection
      cnnUserMan.Open();
      // Populate the data table
      dadUserMan.Fill(dtbUser); 
      // Modify second row, this triggers the row Change events
      dtbUser.Rows[1]["FirstName"] = "Tom";
   }

   // Listing 3B-18-1
   private static void OnRowDeleting(object sender, DataRowChangeEventArgs e) {
      // Display a message showing some of the Row properties
      MessageBox.Show("Row Properties:\n\n" + 
         "RowState: " + e.Row.RowState.ToString() + "\n" + 
         "Table: " + e.Row.Table.ToString() + "\n" + 
         "Action: " + e.Action.ToString(),
         "RowChanging", MessageBoxButtons.OK, 
         MessageBoxIcon.Information);
   }

   // Listing 3B-18-2
   private static void OnRowDeleted(object sender, DataRowChangeEventArgs e) {
      // Display a message showing some of the Row properties
      MessageBox.Show("Row Properties:\n\n" + 
         "RowState: " + e.Row.RowState.ToString() + "\n" + 
         "Table: " + e.Row.Table.ToString() + "\n" + 
         "Action: " + e.Action.ToString(),
         "RowChanged", MessageBoxButtons.OK, 
         MessageBoxIcon.Information);
   }

   // Listing 3B-18-3
   public void TriggerRowDeleteEvents() {
      DataTable dtbUser = new DataTable("tblUser");
      // Declare and instantiate connection
      SqlConnection cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Declare and instantiate data adapter
      SqlDataAdapter dadUserMan = new SqlDataAdapter("SELECT * FROM tblUser", 
         cnnUserMan);
      // Set up event handlers
      dtbUser.RowDeleting += new DataRowChangeEventHandler(OnRowDeleting);
      dtbUser.RowDeleted += new DataRowChangeEventHandler(OnRowDeleted);

      // Open the connection
      cnnUserMan.Open();
      // Populate the data table
      dadUserMan.Fill(dtbUser); 
      // Delete second row, this triggers the row delete events
      dtbUser.Rows[1].Delete();
   }

   // Listing 3B-19-1
   protected void OnListChanged(object sender, System.ComponentModel.ListChangedEventArgs args) {
      // Display a message showing some of the List properties
      MessageBox.Show("List Properties:\n\n" + 
         "ListChangedType: " + args.ListChangedType.ToString() + "\n" + 
         "OldIndex: " + args.OldIndex.ToString() + "\n" + 
         "NewIndex: " + args.NewIndex.ToString(),
         "ListChanged", MessageBoxButtons.OK, 
         MessageBoxIcon.Information);
   }

   // Listing 3B-19-2
   public void TriggerListChangeEvent() {
      DataTable dtbUser = new DataTable("tblUser");
      // Declare and instantiate connection
      SqlConnection cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      // Declare and instantiate data adapter
      SqlDataAdapter dadUserMan = new SqlDataAdapter("SELECT * FROM tblUser", 
         cnnUserMan);

      // Open the connection
      cnnUserMan.Open();
      // Populate the data table
      dadUserMan.Fill(dtbUser); 
      // Declare and instantiate data view
      DataView dvwUser = new DataView(dtbUser);
      // Set up event handler
      dvwUser.ListChanged  += new System.ComponentModel.ListChangedEventHandler(OnListChanged);
      // Trigger list change event by adding new item/row
      dvwUser.AddNew();
   }

   public void InstantiateDataView() {
      DataSet dstUser = new DataSet();

      DataView dvwNoArgumentsWithInitializer = new DataView();
      DataView dvwTableArgumentWithInitializer = new DataView(dstUser.Tables["tblUser"]);

      DataView dvwNoArgumentsWithoutInitializer;
      DataView dvwTableArgumentWithoutInitializer;

      dvwNoArgumentsWithoutInitializer = new DataView();
      dvwTableArgumentWithoutInitializer = new DataView(dstUser.Tables["tblUser"]);
   }

   // Listing 3B-20
   public void SearchDataView() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUser;
      SqlDataAdapter dadUser;
      DataTable dtbUser;
      DataView dvwUser;
      Object objPKValue;
      int intIndex;

      // Instantiate and open the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();
      // Instantiate the command and data table
      cmmUser = new SqlCommand("SELECT * FROM tblUser", cnnUserMan);
      dtbUser = new DataTable();
      // Instantiate and initialize the data adapter
      dadUser = new SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan);
      dadUser.SelectCommand = cmmUser;
      // Fill the data table
      dadUser.Fill(dtbUser);
      // Filter the data table view
      dtbUser.DefaultView.RowFilter = "LastName = 'Doe'";
      // Create the new data view
      dvwUser = dtbUser.DefaultView;
      // Specify a sort order
      dvwUser.Sort = "Id ASC";
      // Find and display the user with an id of 1
      objPKValue = 1;
      intIndex = dvwUser.Find(objPKValue);
      MessageBox.Show(dvwUser[intIndex].Row["LastName"].ToString());
   }

   // Listing 3B-21
   public void SortDataView() {
      SqlConnection cnnUserMan;
      SqlCommand cmmUser;
      SqlDataAdapter dadUser;
      DataTable dtbUser;

      // Instantiate and open the connection
      cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();
      // Instantiate the command and data table
      cmmUser = new SqlCommand("SELECT * FROM tblUser", cnnUserMan);
      dtbUser = new DataTable();
      // Instantiate and initialize the data adapter
      dadUser = new SqlDataAdapter("SELECT * FROM tblUser", cnnUserMan);
      dadUser.SelectCommand = cmmUser;
      // Fill the data table
      dadUser.Fill(dtbUser);
      // Sort the data table view after LastName in ascending order
      dtbUser.DefaultView.Sort = "LastName ASC";

      // Loop through all the rows in the data table,
      // displaying the LastName
      for (int intCounter = 0; intCounter <= dtbUser.DefaultView.Count - 1; intCounter++) {
         MessageBox.Show(dtbUser.DefaultView[intCounter]["LastName"].ToString());
      }
   }

   public void InstantiateDataRow() {
      DataTable dtbUser = new DataTable();
      DataRow drwUser;

      drwUser = dtbUser.NewRow();
   }

   // Listing 3B-22
   public void InstantiateDataColumn() {
      DataColumn dtcDefaultValues = new DataColumn();
      DataColumn dtcColumnName = new DataColumn("ColumnName");
      DataColumn dtcColumnNameAndDataType = new DataColumn("ColumnName", 
         Type.GetType("System.String"));
      DataColumn dtcColumnNameAndDataTypeAndExpression = new DataColumn("ColumnName", 
         Type.GetType("System.String"), "ColumnName + 'Extra Text'");
      DataColumn dtcColumnNameAndDataTypeAndExpressionAndMappingType = new 
         DataColumn("ColumnName", Type.GetType("System.Int32"), "ColumName + 10", 
         MappingType.Attribute);
   }

   // Listing 3B-23
   public void InstantiateDataRelation() {
      // Declare parent and child columns for use in relationship
      DataColumn dtcParentColumn = new DataColumn("ParentColumn");
      DataColumn dtcChildColumn = new DataColumn("ChildColumn");
      // Declare and initialize array of parent and child 
      // columns for use in relationship
      DataColumn[] arrdtcParentColumn = new DataColumn[2];
      DataColumn[] arrdtcChildColumn = new DataColumn[2];
      arrdtcParentColumn[0] = new DataColumn("ParentColumn1");
      arrdtcParentColumn[1] = new DataColumn("ParentColumn2");
      arrdtcChildColumn[0] = new DataColumn("ChildColumn1");
      arrdtcChildColumn[1] = new DataColumn("ChildColumn2");

      // This constructor will fail, unless you add the
      // specified parent and child columns to a table
      DataRelation dtrParentColumnAndChildColumn = 
         new DataRelation("RelationName", dtcParentColumn,
         dtcChildColumn);
      // This constructor will fail, unless you add the
      // specified parent and child columns to a table
      DataRelation dtrParentColumnAndChildColumnAndConstraints = 
         new DataRelation("RelationName", dtcParentColumn,
         dtcChildColumn, false);

      // This constructor will fail, unless you add the
      // specified arrays of parent and child columns to a table
      DataRelation dtrParentColumnsAndChildColumns = 
         new DataRelation("RelationName", arrdtcParentColumn, 
         arrdtcChildColumn, false);
      // This constructor will fail, unless you add the
      // specified arrays of parent and child columns to a table
      DataRelation dtrParentColumnsAndChildColumnsAndConstraints = 
         new DataRelation("RelationName", arrdtcParentColumn, 
         arrdtcChildColumn, false);

      // This constructor takes string values for all arguments
      // except for the last argument, Nested. This argument is 
      // used for indicating if this relation is used in connection
      // with hierarchical data, like an XML document
      DataRelation dtrStringsAndNested = 
         new DataRelation("RelationName", "ParentTableName",
         "ChildTableName", new string[1] {"PrimaryKeyColumn1"}, 
         new string[1] {"ForeignKeyColumn1"}, false);
   }

   // Listing 3B-24
   public void BuildUserManDatabase() {
      // Declare and instantiate data set
      DataSet dstUserMan = new DataSet("UserMan");
      // Declare and instantiate tables in data set
      DataTable dtbUser = new DataTable("tblUser");
      DataTable dtbRights = new DataTable("tblRights");
      DataTable dtbUserRights = new DataTable("tblUserRights");
      DataTable dtbLog = new DataTable("tblLog");
      // Declare table elements
      DataColumn dclUser, dclRights, dclUserRights, dclLog;
      DataColumn[] arrdclUserPrimaryKey, arrdclRightsPrimaryKey, 
         arrdclUserRightsPrimaryKey, arrdclLogPrimaryKey;
      // Declare table relations
      DataRelation dtrUser2Log, dtrUser2UserRights, dtrRights2UserRights;

      // Set up data set for saving to XML
      dstUserMan.Namespace = "UserMan";
      dstUserMan.Locale = new CultureInfo("En-US", true);
      dstUserMan.Prefix = "Development";

      // Create user table structure
      // Create Id column
      dclUser = new DataColumn("Id", Type.GetType("System.Int32"),"", 
         MappingType.Element);
      // Make the Id column an auto increment column, incrementing by 1 
      // every time a new row is added to the table, with a seed of 1
      dclUser.AutoIncrement = true;
      dclUser.AutoIncrementSeed = 1;
      dclUser.AutoIncrementStep = 1;
      // Disallow null values in column
      dclUser.AllowDBNull = false;
      // Add Id column to user table structure
      dtbUser.Columns.Add(dclUser);
      // Create single-column primary key
      arrdclUserPrimaryKey = new DataColumn[1];
      // Add Id column to PK array
      arrdclUserPrimaryKey[0] = dclUser;
      // Set primary key
      dtbUser.PrimaryKey = arrdclUserPrimaryKey;

      // Create ADName column
      dclUser = new DataColumn("ADName", Type.GetType("System.String"));
      dclUser.MaxLength = 100;
      // Add column to user table structure
      dtbUser.Columns.Add(dclUser);

      // Create ADSID column
      dclUser = new DataColumn("ADSID", Type.GetType("System.String"));
      dclUser.MaxLength = 50;
      // Add column to user table structure
      dtbUser.Columns.Add(dclUser);

      // Create FirstName column
      dclUser = new DataColumn("FirstName", Type.GetType("System.String"));
      dclUser.MaxLength = 50;
      // Add column to user table structure
      dtbUser.Columns.Add(dclUser);

      // Create LastName column
      dclUser = new DataColumn("LastName", Type.GetType("System.String"));
      dclUser.MaxLength = 50;
      // Add column to user table structure
      dtbUser.Columns.Add(dclUser);

      // Create LoginName column
      dclUser = new DataColumn("LoginName", Type.GetType("System.String"));
      // Disallow null values in column
      dclUser.AllowDBNull = false;
      // Disallow duplicate values in column
      dclUser.Unique = true;
      dclUser.MaxLength = 50;
      // Add column to user table structure
      dtbUser.Columns.Add(dclUser);

      // Create Password column
      dclUser = new DataColumn("Password", Type.GetType("System.String"));
      // Disallow null values in column
      dclUser.AllowDBNull = false;
      dclUser.MaxLength = 50;
      // Add column to user table structure
      dtbUser.Columns.Add(dclUser);

      // Add User table to dataset
      dstUserMan.Tables.Add(dtbUser);

      // Create Rights table structure
      // Create Id column
      dclRights = new DataColumn("Id", Type.GetType("System.Int32"),"", 
         MappingType.Element);
      // Make the Id column an auto increment column, incrementing by 1 
      // every time a new row is added to the table, with a seed of 1
      dclRights.AutoIncrement = true;
      dclRights.AutoIncrementSeed = 1;
      dclRights.AutoIncrementStep = 1;
      // Disallow null values in column
      dclRights.AllowDBNull = false;
      // Add Id column to Rights table structure
      dtbRights.Columns.Add(dclRights);
      // Create single-column primary key
      arrdclRightsPrimaryKey = new DataColumn[1];
      // Add Id column to PK array
      arrdclRightsPrimaryKey[0] = dclRights;
      // Set primary key
      dtbRights.PrimaryKey = arrdclRightsPrimaryKey;

      // Create Name column
      dclRights = new DataColumn("Name", Type.GetType("System.String"));
      dclUser.MaxLength = 50;
      // Add column to Rights table structure
      dtbRights.Columns.Add(dclRights);

      // Create Description column
      dclRights = new DataColumn("Description", Type.GetType("System.String"));
      dclUser.MaxLength = 255;
      // Add column to Rights table structure
      dtbRights.Columns.Add(dclRights);

      // Add Rights table to dataset
      dstUserMan.Tables.Add(dtbRights);

      // Create Log table structure
      // Create Id column
      dclLog = new DataColumn("Id", Type.GetType("System.Int32"),"", 
         MappingType.Element);
      // Make the Id column an auto increment column, incrementing by 1 
      // every time a new row is added to the table, with a seed of 1
      dclLog.AutoIncrement = true;
      dclLog.AutoIncrementSeed = 1;
      dclLog.AutoIncrementStep = 1;
      // Disallow null values in column
      dclLog.AllowDBNull = false;
      // Add Id column to Log table structure
      dtbLog.Columns.Add(dclLog);
      // Create single-column primary key
      arrdclLogPrimaryKey = new DataColumn[1];
      // Add Id column to PK array
      arrdclLogPrimaryKey[0] = dclLog;
      // Set primary key
      dtbLog.PrimaryKey = arrdclLogPrimaryKey;

      // Create Logged column
      dclLog = new DataColumn("Logged", Type.GetType("System.DateTime"));
      // Add column to Log table structure
      dtbLog.Columns.Add(dclLog);

      // Create Description column
      dclLog = new DataColumn("Description", Type.GetType("System.String"));
      dclUser.MaxLength = 255;
      // Add column to Log table structure
      dtbLog.Columns.Add(dclLog);

      // Create UserId column
      dclLog = new DataColumn("UserId", Type.GetType("System.Int32"),"", 
         MappingType.Element);
      // Disallow null values in column
      dclLog.AllowDBNull = false;
      // Add UserId column to Log table structure
      dtbLog.Columns.Add(dclLog);

      // Add Log table to dataset
      dstUserMan.Tables.Add(dtbLog);

      // Create UserRights table structure
      // Create UserId column
      dclUserRights = new DataColumn("UserId", Type.GetType("System.Int32"),"", 
         MappingType.Element);
      // Disallow null values in column
      dclUserRights.AllowDBNull = false;
      // Disallow duplicate values in column
      dclUserRights.Unique = true;
      // Add Id column to UserRights table structure
      dtbUserRights.Columns.Add(dclUserRights);

      // Create composite primary key
      arrdclUserRightsPrimaryKey = new DataColumn[2];
      // Add UserId column to PK array
      arrdclUserRightsPrimaryKey[0] = dclUserRights;
	
      // Create RightsId column
      dclUserRights = new DataColumn("RightsId", Type.GetType("System.Int32"),"", 
         MappingType.Element);
      // Disallow null values in column
      dclUserRights.AllowDBNull = false;
      // Disallow duplicate values in column
      dclUserRights.Unique = true;
      // Add RightsId column to UserRights table structure
      dtbUserRights.Columns.Add(dclUserRights);

      // Add RightsId column to PK array
      arrdclUserRightsPrimaryKey[1] = dclUserRights;
      // Set primary key
      dtbUserRights.PrimaryKey = arrdclUserRightsPrimaryKey;

      // Add UserRights table to dataset
      dstUserMan.Tables.Add(dtbUserRights);

      // Create table relations
      dtrUser2Log = new DataRelation("User2Log", "tblUser",
         "tblLog", new string[1] {"Id"}, 
         new string[1] {"UserId"}, false);
      dtrUser2UserRights = new DataRelation("User2UserRights", "tblUser",
         "tblUserRights", new string[1] {"I"}, 
         new string[1] {"UserId"}, false);
      dtrRights2UserRights = new DataRelation("Rights2UserRight", "tblRights",
         "tblUserRights", new string[1] {"Id"}, 
         new string[1] {"RightsId"}, false);
	
      // Write data set schema to XML file
      //dstUserMan.WriteXmlSchema("C:\\UserMan.xml");
   }

   // Listing 3B-25
   public void LockDataSourceRowsUsingTransactions() {
      const string STR_SQL_USER_SELECT = "SELECT * FROM tblUser";

      SqlConnection cnnLocked, cnnUnlocked;
      SqlDataAdapter dadLocked, dadUnlocked;
      SqlTransaction traUserMan;
      SqlCommand cmdSelectUsers;
      DataSet dstLocked = new DataSet("Locked DataSet");
      DataSet dstUnlocked = new DataSet("Unlocked DataSet");
      
      // Instantiate and open the connections
      cnnLocked = new SqlConnection(STR_CONNECTION_STRING);
      cnnLocked.Open();
      cnnUnlocked = new SqlConnection(STR_CONNECTION_STRING);
      cnnUnlocked.Open();
      // Begin transaction
      traUserMan = cnnLocked.BeginTransaction(IsolationLevel.Serializable);
      // Set up select command
      cmdSelectUsers = new SqlCommand(STR_SQL_USER_SELECT, cnnLocked, traUserMan);

      // Instantiate and initialize data adapters
      dadLocked = new SqlDataAdapter(STR_SQL_USER_SELECT, cnnLocked);
      dadLocked.SelectCommand = cmdSelectUsers;
      dadUnlocked = new SqlDataAdapter(STR_SQL_USER_SELECT, cnnUnlocked);
      // Declare and instantiate command builders
      SqlCommandBuilder cmbUser1 = new SqlCommandBuilder(dadLocked);
      SqlCommandBuilder cmbUser2 = new SqlCommandBuilder(dadUnlocked);

      // Populate the data sets
      dadLocked.Fill(dstLocked, "tblUser");
      dadUnlocked.Fill(dstUnlocked, "tblUser");

      // Update an existing row in unlocked data set
      dstUnlocked.Tables["tblUser"].Rows[2]["FirstName"] = "FirstName";

      try {
         // Update the unlocked data source
         dadUnlocked.Update(dstUnlocked, "tblUser");
         // Commit transaction
         traUserMan.Commit();
      }
      catch (SqlException objE) {
         // Roll back transaction
         traUserMan.Rollback();
         MessageBox.Show(objE.Message);
      }
      finally {
         // Close connections
         cnnLocked.Close();
         cnnUnlocked.Close();
      }
   }

   // Listing 3B-26
   public void TriggerConcurrencyViolation() {
      const string STR_SQL_USER_SELECT = "SELECT * FROM tblUser";

      SqlConnection cnnUser1, cnnUser2;
      SqlDataAdapter dadUser1, dadUser2;
      DataSet dstUser1 = new DataSet("User1 DataSet");
      DataSet dstUser2 = new DataSet("User2 DataSet");
      
      // Instantiate and open the connections
      cnnUser1 = new SqlConnection(STR_CONNECTION_STRING);
      cnnUser1.Open();
      cnnUser2 = new SqlConnection(STR_CONNECTION_STRING);
      cnnUser2.Open();

      // Instantiate and initialize data adapters
      dadUser1 = new SqlDataAdapter(STR_SQL_USER_SELECT, cnnUser1);
      dadUser2 = new SqlDataAdapter(STR_SQL_USER_SELECT, cnnUser2);
      SqlCommandBuilder cmbUser1 = new SqlCommandBuilder(dadUser1);
      SqlCommandBuilder cmbUser2 = new SqlCommandBuilder(dadUser2);

      // Populate the data sets
      dadUser1.Fill(dstUser1, "tblUser");
      dadUser2.Fill(dstUser2, "tblUser");

      // Update an existing row in first data set
      dstUser1.Tables["tblUser"].Rows[2]["FirstName"] = "FirstName";
      // Update the data source with changes to the first data set
      dadUser1.Update(dstUser1, "tblUser");
      // Update an existing row in second data set
      dstUser2.Tables["tblUser"].Rows[2]["FirstName"] = "FName";

      try {
         // Update the data source with changes to the second data set
         dadUser2.Update(dstUser2, "tblUser");
      }
      catch (DBConcurrencyException objE) {
         MessageBox.Show(objE.Message);
      }
      finally {
         // Close connections
         cnnUser1.Close();
         cnnUser2.Close();
      }
   }

   // Listing 3B-27
   public void IgnoreConcurrencyViolations() {
      const string STR_SQL_USER_SELECT = "SELECT * FROM tblUser";
      const string STR_SQL_USER_UPDATE = "UPDATE tblUser SET ADName=@ADName, ADSID=@ADSID, FirstName=" +
         "@FirstName, LastName=@LastName, LoginName=@LoginName, Password=@Password WHERE Id=@Id";

      SqlCommand cmmUserUpdate1, cmmUserUpdate2;
      SqlParameter prmSQLUpdate;

      SqlConnection cnnUser1;
      SqlDataAdapter dadUser1, dadUser2;
      DataSet dstUser1 = new DataSet("User DataSet1");
      DataSet dstUser2 = new DataSet("User DataSet2");
      
      // Instantiate and open the connection
      cnnUser1 = new SqlConnection(STR_CONNECTION_STRING);
      cnnUser1.Open();

      // Instantiate the update commands
      cmmUserUpdate1 = new SqlCommand(STR_SQL_USER_UPDATE, cnnUser1);
      cmmUserUpdate2 = new SqlCommand(STR_SQL_USER_UPDATE, cnnUser1);

      // Instantiate and initialize data adapters
      dadUser1 = new SqlDataAdapter(STR_SQL_USER_SELECT, cnnUser1);
      dadUser2 = new SqlDataAdapter(STR_SQL_USER_SELECT, cnnUser1);

      // Set data adapters update command property
      dadUser1.UpdateCommand = cmmUserUpdate1;
      dadUser2.UpdateCommand = cmmUserUpdate2;

      // Add Update command parameters
      cmmUserUpdate1.Parameters.Add("@ADName", SqlDbType.VarChar, 100, "ADName");
      cmmUserUpdate1.Parameters.Add("@ADSID", SqlDbType.VarChar, 50, "ADSID");
      cmmUserUpdate1.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, "FirstName");
      cmmUserUpdate1.Parameters.Add("@LastName", SqlDbType.VarChar, 50, "LastName");
      cmmUserUpdate1.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, "LoginName");
      cmmUserUpdate1.Parameters.Add("@Password", SqlDbType.VarChar, 50, "Password");

      prmSQLUpdate = dadUser1.UpdateCommand.Parameters.Add("@Id", SqlDbType.Int, 4, "Id");
      prmSQLUpdate.Direction = ParameterDirection.Input;
      prmSQLUpdate.SourceVersion = DataRowVersion.Original;

      cmmUserUpdate2.Parameters.Add("@ADName", SqlDbType.VarChar, 100, "ADName");
      cmmUserUpdate2.Parameters.Add("@ADSID", SqlDbType.VarChar, 50, "ADSID");
      cmmUserUpdate2.Parameters.Add("@FirstName", SqlDbType.VarChar, 50, "FirstName");
      cmmUserUpdate2.Parameters.Add("@LastName", SqlDbType.VarChar, 50, "LastName");
      cmmUserUpdate2.Parameters.Add("@LoginName", SqlDbType.VarChar, 50, "LoginName");
      cmmUserUpdate2.Parameters.Add("@Password", SqlDbType.VarChar, 50, "Password");

      prmSQLUpdate = dadUser2.UpdateCommand.Parameters.Add("@Id", SqlDbType.Int, 4, "Id");
      prmSQLUpdate.Direction = ParameterDirection.Input;
      prmSQLUpdate.SourceVersion = DataRowVersion.Original;

      // Populate the data sets
      dadUser1.Fill(dstUser1, "tblUser");
      dadUser2.Fill(dstUser2, "tblUser");

      // Update an existing row in first data set
      dstUser1.Tables["tblUser"].Rows[2]["FirstName"] = "FirstName";
      // Update the data source with changes to the first data set
      dadUser1.Update(dstUser1, "tblUser");
      // Update an existing row in second data set
      dstUser2.Tables["tblUser"].Rows[2]["FirstName"] = "FName";
      // Update the data source with changes to the second data set
      dadUser2.Update(dstUser2, "tblUser");
   }

   // Listing 3B-28
   public void HandleConcurrencyViolations() {
      const string STR_SQL_USER_SELECT = "SELECT * FROM tblUser";

      SqlConnection cnnUser1;
      SqlDataAdapter dadUser1, dadUser2;
      DataSet dstUser1 = new DataSet("User DataSet1");
      DataSet dstUser2 = new DataSet("User DataSet2");
      
      // Instantiate and open the connection
      cnnUser1 = new SqlConnection(STR_CONNECTION_STRING);
      cnnUser1.Open();

      // Instantiate and initialize data adapters
      dadUser1 = new SqlDataAdapter(STR_SQL_USER_SELECT, cnnUser1);
      dadUser2 = new SqlDataAdapter(STR_SQL_USER_SELECT, cnnUser1);
      // Declare and instantiate command builder
      SqlCommandBuilder cmbUser1 = new SqlCommandBuilder(dadUser1);
      SqlCommandBuilder cmbUser2 = new SqlCommandBuilder(dadUser2);

      // Populate the data sets
      dadUser1.Fill(dstUser1, "tblUser");
      dadUser2.Fill(dstUser2, "tblUser");

      // Update an existing row in first data set
      dstUser1.Tables["tblUser"].Rows[2]["FirstName"] = "FirstName";
      // Update the data source with changes to the first data set
      dadUser1.Update(dstUser1, "tblUser");
      // Update an existing row in second data set
      dstUser2.Tables["tblUser"].Rows[2]["FirstName"] = "FName";

      try {
         // Update the data source with changes to the second data set
         dadUser2.Update(dstUser2, "tblUser");
      }
      catch (DBConcurrencyException objE) {
         DialogResult objResult;
         string strCurrentDataSourceFirstName;
         // Instantiate command to find the current data source value
         SqlCommand cmdCurrentDataSourceValue = 
            new SqlCommand("SELECT FirstName FROM tblUser WHERE Id=" + 
            objE.Row["Id", DataRowVersion.Original].ToString(), cnnUser1);

         // Find current value in data source
         strCurrentDataSourceFirstName = (string) cmdCurrentDataSourceValue.ExecuteScalar();

         // Prompt the user about which value to save
         objResult = MessageBox.Show("A concurrency violation exception was thrown when updating the source." +
            "These are the values for the column in error:\n\n" + 
            "Original DataSet Value: " + objE.Row["FirstName", DataRowVersion.Original].ToString()  + "\n"  + 
            "Current Data Source Value: " + strCurrentDataSourceFirstName  + "\n"  + 
            "Current DataSet Value: " + objE.Row["FirstName", DataRowVersion.Current].ToString()  + "\n"  + 
            "Do you want to overwrite the current data source value?",  "Concurrency Violation", 
            MessageBoxButtons.YesNo, MessageBoxIcon.Question);
         // Does the user want to overwrite the current data source value?
         if (objResult == DialogResult.Yes) {
            // Merge the content of the data source with the dataset in error
            dstUser2.Merge(dstUser1, true);
            dadUser2.Update(dstUser2, "tblUser");
         }
      }
      finally {
         // Close connection
         cnnUser1.Close();
      }
   }
}