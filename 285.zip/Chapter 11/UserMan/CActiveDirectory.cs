// Listing 11-13
using System;
using System.Data.OleDb;
using System.Runtime.InteropServices;

namespace UserMan {
	/// <summary>
	/// Summary description for CActiveDirectory.
	/// </summary>
   public class CActiveDirectory {
      // Declare the APIs needed to manipulate the RAW user SID
      [DllImport("advapi32.dll")]
      public static unsafe extern long GetSidSubAuthority(long pSid, long nSubAuthority);
      [DllImport("advapi32.dll")]
      public static unsafe extern long GetSidSubAuthorityCount(long pSid);
      [DllImport("advapi32.dll")]
      public static unsafe extern long GetSidIdentifierAuthority(long pSid);
      [DllImport("kernel32")]
      public static unsafe extern void RtlMoveMemory(long Destination, long Source, int Length);

      private const string PR_STR_CONNECTION_STRING = "Provider=ADsDSOObject;" +
         "User Id=UserMan;Password=userman";
      private string prstrADName;
      private string prstrADSID;
      private string prstrUserName;

      public CActiveDirectory(string strUserName) {
         prstrUserName = strUserName;
         prOpenConnection();
      }

      ~ CActiveDirectory() {
         prCloseConnection();
      }

      // Database objects
      private OleDbConnection prcnnAD;
      private OleDbCommand prcmmAD;
      private OleDbDataReader prdrdAD;

      private void prOpenConnection() {
         // Instantiate and open connection
         prcnnAD = new OleDbConnection(PR_STR_CONNECTION_STRING);
         prcnnAD.Open();
         prRetrieveUserInformation();
      }

      private void prCloseConnection() {
         // Close connection
         prcnnAD.Close();
      }

      private void prRetrieveUserInformation() {
         try {
            // Instantiate command
            prcmmAD = new OleDbCommand("SELECT objectSid, samAccountName FROM " +
               "'LDAP://vb-joker.com' WHERE objectCategory='person' AND " +
               "objectClass='user' AND cn='" + prstrUserName + "'", prcnnAD);
            // Retrieve user info in data reader
            prdrdAD = prcmmAD.ExecuteReader();
            // Move to the first row
            if (prdrdAD.Read()) {
               // Save SAM account name (pre-Windows 2000)
               prstrADName = prdrdAD["samAccountName"].ToString();
               // Save human readable SID
               prstrADSID = prConvertSID2SDDL((byte[]) prdrdAD["objectSid"]);
            }
         }
         catch (Exception objE) {
            throw new Exception("An error occurred trying to retrieve the user information from Active Directory.", objE);
         }
      }

      public string ADName {
         get {
            return prstrADName;
         }
      }

      public string ADSID {
         get {
            return prstrADSID;
         }
      }

      private string prConvertSID2SDDL(byte[] objSID) {
         string strSDDL;
         long pSia;
         byte[] pSiaByte = new byte[6];
         byte[] pSid = new byte[512];
         long pSubAuthorityCount;
         byte bSubAuthorityCount = 0;
         long pAuthority = 0;
         long lAuthority = 0;
         double dblAuthority = 0;

         // Convert the raw sid into its SDDL form ( S-?-?-???-?????? )
         // The first item in the S- format is the rivision level.  If we look closely at the
         // SID structure in the WinNT.H C Header, we find that the revision value for the SID is
         // stored in the 0th byte to the raw sid.
         // Another interesting fact is that the last byte of the Identifying authority structure contains
         // the second component of the SDDL form, so lets retrieve both of those and
         // place them into the string.

         try {
            pSia = GetSidIdentifierAuthority(objSID[0]);

            // The GetSidIdentifierAuthority returns a pointer to the Identifying Authority structure
            // The pointer must be copied into some memory that VB knows how to manage, so....
            RtlMoveMemory(pSiaByte[0], pSia, 6);
            strSDDL = "S-" + objSID[0].ToString() + "-" + pSiaByte[5].ToString();

            // The rest of the SDDL form contains a list of sub authorities separated by
            // "-"s.  The total number of these authorities can be obtained by
            // calling the GetSidSubAuthorityCount.  The value returned is a pointer into the
            // SID memory that contains the Sub Authority value, once again, this memory
            // must be copied into something that VB knows how to manage.
            //
            // Notice that only 1 byte is copied.  This is because the sub authority count
            // is stored in a single byte ( see the SID srtructure definition above )

            pSubAuthorityCount = GetSidSubAuthorityCount(objSID[0]);
            RtlMoveMemory(bSubAuthorityCount, pSubAuthorityCount, 1);

            // We can loop throught the sub authorities and convert
            // their DWORD values to VB longs, then convert them to a string.
            // The count is 0 based, so we start a 0 and goto the
            // number of sub authorities - 1
            for (int intCounter = 0; intCounter <= (bSubAuthorityCount - 1); intCounter++) {
               pAuthority = GetSidSubAuthority(objSID[0], intCounter);
               RtlMoveMemory(lAuthority, pAuthority, lAuthority.ToString().Length);

               // VB by default assumes its data types to be signed types. The sub authorities should
               // be unsigned and hence the following code has to work around this problem to get the
               // sub authorities as unsigned data types

               // Get rid of the most significant bit (the signed bit) if it is set (And 0x7FFFFFFF), and then add it
               // back in into the right location in the double variable (+ 2^31)

               dblAuthority = lAuthority;
               if ((lAuthority & 0x80000000) != 0) {
                  dblAuthority = lAuthority & 0x7FFFFFFF;
                  dblAuthority = dblAuthority + Math.Pow(31, 2);
               }
            }
         }
         catch (Exception objE) {
            throw new Exception("Can't convert SID to string!", objE);
         }

         strSDDL = strSDDL + "-" + dblAuthority.ToString();

         return strSDDL;
      }
   }
}