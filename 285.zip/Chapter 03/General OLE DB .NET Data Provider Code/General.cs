//#define Oracle 
//#define SQLSERVER 
#define MSAccess
// You simply uncomment the line above for the DBMS you want to use

using System;
using System.Reflection;
using System.Globalization;
using System.Data;
using System.Data.OleDb;
using System.Xml;
using System.Windows.Forms;
using ADODB;

public class CGeneral {
#if SQLSERVER
	// This connection string os for connecting to SQL Server
   // You must change the Data Source value
	public const string STR_CONNECTION_STRING = 
		"Provider=SQLOLEDB;Data Source=USERMANPC;User Id=UserMan;Password=userman;Initial Catalog=UserMan";
#elif MSAccess
	// This connection string os for connecting to an Access mdb
	// I'm not using any security, hence the blank User Id and password. I'm also
	// Opening the mdb in shared mode. You must edit the path to your database file
	public const string STR_CONNECTION_STRING = 
		"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\DBPWC#\\UserMan.mdb;User Id=;Password=;" +
		"Mode=Share Deny None;";
#elif Oracle
	// This connection string os for connecting to Oracle
   // You must change the Data Source value
	public const string STR_CONNECTION_STRING = 
		"Provider=MSDAORA;Password=userman;User ID=USERMAN;Data Source=USERMAN";
#endif

	// Listing 3A-1
	public void OpenConnection(string strConnectionString) {
		// Declare connection object
		OleDbConnection cnnUserMan;

		// Instantiate the connection object
		cnnUserMan = new OleDbConnection();
		// Set up connection string
		cnnUserMan.ConnectionString = strConnectionString;

		// Open the connection
		cnnUserMan.Open();
	}

   // Listing 3A-2-1 & Listing 3A-6-1
   // Declare and instantiate connection
   private OleDbConnection prcnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);

   // Listing 3A-2-2
//   public CGeneral() {
//      // Set up event handler
//      prcnnUserMan.StateChange  += new StateChangeEventHandler(OnStateChange);
//   }

   // Listing 3A-2-3
   protected static void OnStateChange(object sender, StateChangeEventArgs args) {
      // Display the original and the current state
      MessageBox.Show("The original connection state was: " + args.OriginalState.ToString() +
         "\nThe current connection state is: " + args.CurrentState.ToString());
   }

   // Listing 3A-2-3
   public void TriggerStateChangeEvent() {
      // Open the connection
      prcnnUserMan.Open();
      // Close the connection
      prcnnUserMan.Close();
   }
   
   public void DisableAutomaticConnectionPooling() {
		OleDbConnection cnnUserMan;

		// Instantiate and open the OleDb connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING + ";OLE DB Services=-4");
		cnnUserMan.Open();
		// Close the OleDb connection
		cnnUserMan.Close();
	}

	// Listing 3A-4
	public void ClearConnectionPool() {
		// Declare connection object
		OleDbConnection cnnUserMan;

		// Instantiate the connection object
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		// Open the connection
		cnnUserMan.Open();

		// Do your stuff
		// ...
		// Close connection and release pool
		cnnUserMan.Close();
		OleDbConnection.ReleaseObjectPool();
	}

   // Listing 3A-6-2
   public CGeneral() {
      // Set up event handler
      prcnnUserMan.InfoMessage  += new OleDbInfoMessageEventHandler(OnInfoMessage);
   }

   // Listing 3A-6-3
   protected static void OnInfoMessage(object sender, OleDbInfoMessageEventArgs args) {
      // Loop through all the error messages 
      foreach (OleDbError objError in args.Errors) {
         // Display the error properties
         MessageBox.Show("The " + objError.Source + " has raised a warning. " +
            " These are the properties :\n"  +
            "\nNative Error: " + objError.NativeError.ToString() +
            "\nSQL State: " + objError.SQLState +
            "\nMessage: " + objError.Message);
      }

      // Display the message, error code and the source
      MessageBox.Show("Info Message: " + args.Message +
         "\nInfo Error Code: " + args.ErrorCode.ToString() +
         "\nInfo Source: " + args.Source);
   }
   
   // Listing 3A-8
	public void BeginNonDefaultIsolationLevelTransaction() {
		OleDbConnection cnnUserMan;
		OleDbTransaction traUserMan;

		// Instantiate the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		// Open the connection
		cnnUserMan.Open();
		// Begin transaction
		traUserMan = cnnUserMan.BeginTransaction(IsolationLevel.ReadCommitted);
	}

	// Listing 3A-12
	public void NestTransactions() {
      // The SQLOLEDB OLE DB and the MSDAORA Oracle Provider don't support
      // Nesting
#if MSAccess
      OleDbConnection cnnUserMan;
		OleDbTransaction traUserManMain;
		OleDbTransaction traUserManFamily;
		OleDbTransaction traUserManAddress;

		// Instantiate the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		// Open the connection
		cnnUserMan.Open();

		// Start main transaction
		traUserManMain = cnnUserMan.BeginTransaction();
		// Update family tables
		// ...
		// Begin nested transaction
		traUserManFamily = traUserManMain.Begin();
		// Update address tables
		// ...
		// Begin nested transaction
		traUserManAddress = traUserManFamily.Begin();
		// Roll back address table updates
		traUserManAddress.Rollback();
#endif
   }

	// Listing 3A-13
	public void DetermineTransactionIsolationLevel() {
		OleDbConnection cnnUserMan;
		OleDbTransaction traUserMan;
		
		// Instantiate the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		// Open the connection
		cnnUserMan.Open();

		// Start transaction with non-default isolation level
		traUserMan = cnnUserMan.BeginTransaction(IsolationLevel.ReadCommitted);

		// Return the isolation level as text
		MessageBox.Show(traUserMan.IsolationLevel.ToString());
	}

	// Listing 3A-15
	public void CheckConnectionStringPropertyException() {
		OleDbConnection cnnUserMan;

		// Instantiate the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		// Open the connection
		cnnUserMan.Open();

		try {
			// Set the connection string
			cnnUserMan.ConnectionString = STR_CONNECTION_STRING;
		}
		catch (Exception objException) {
			// Check if setting the ConnectionString threw the exception
			if (objException.TargetSite.Name == "set_ConnectionString") {
				MessageBox.Show("The ConnectionString property threw the exception!");
			}
		}
	}

   // Listing 3A-18
	public void CheckOpenMethodException() {
		OleDbConnection cnnUserMan;

		try {
			// Instantiate the connection
			cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
			// Open the connection
			cnnUserMan.Open();
			// Open the connection
			cnnUserMan.Open(); 
		}
		catch (Exception objException) {
			// Check if we tried to open an already open connection
			if (objException.TargetSite.Name == "Open") {
				MessageBox.Show("The Open method threw the exception!");
			}
		}
	}

	// Listing 3A-19
	public void TraversingAllOleDbErrors() {
		OleDbConnection cnnUserMan;

		try {
			// Instantiate the connection
			cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
			// Open the connection
			cnnUserMan.Open();
			// Do your stuff...
			// ... 
		}
		catch (OleDbException objException) {
			// This catch block will handle all exceptions that 
			// the OleDbAdapter cannot handle
			foreach (OleDbError objError in objException.Errors) {
				MessageBox.Show(objError.Message);
			}
		}
		catch (Exception objException) {
			// This catch block will catch all exceptions that
			//	the OleDbAdapter can handle
			MessageBox.Show(objException.Message);
		}
	}

	// Listing 3A-21
	public void InstantiateCommandObject() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUserMan;
		string strSQL;

		// Instantiate the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		// Open the connection
		cnnUserMan.Open();
		// Build query string
		strSQL = "SELECT * FROM tblUser";
		// Instantiate the command
		cmmUserMan = new OleDbCommand(strSQL, cnnUserMan);
	}

	// Listing 3A-22
	public void ExecuteNonQueryCommand() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUserMan;
		string strSQL;

		// Instantiate the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		// Open the connection
		cnnUserMan.Open();
		// Build delete query string
		strSQL = "DELETE FROM tblUser WHERE LoginName='User99'";
		// Instantiate and execute the delete command
		cmmUserMan = new OleDbCommand(strSQL, cnnUserMan);
		cmmUserMan.ExecuteNonQuery();
		// Build insert query string
#if Oracle
      // You need to manually add the id value using the USERID sequence
		strSQL = "INSERT INTO tblUser (Id, LoginName) VALUES(USERID.NEXTVAL, 'User99')";
#else
		strSQL = "INSERT INTO tblUser (LoginName) VALUES('User99')";
#endif

		// Instantiate and execute the insert command
		cmmUserMan = new OleDbCommand(strSQL, cnnUserMan);
		cmmUserMan.ExecuteNonQuery();
	}

	// Listing 3A-23
	public void ExecuteReaderCommand() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUserMan;
		OleDbDataReader drdTest;
		string strSQL;

		// Instantiate the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		// Open the connection
		cnnUserMan.Open();
		// Build query string
		strSQL = "SELECT * FROM tblUser";
		// Instantiate and execute the command
		cmmUserMan = new OleDbCommand(strSQL, cnnUserMan);
		drdTest = cmmUserMan.ExecuteReader();
	}

	// Listing 3A-24
	public void ExecuteScalarCommand() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUserMan;
		int intNumRows;
      object objNumRows;
		string strSQL;

		// Instantiate the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		// Open the connection
		cnnUserMan.Open();
		// Build query string
		strSQL = "SELECT COUNT(*) FROM tblUser";
		// Instantiate the command
		cmmUserMan = new OleDbCommand(strSQL, cnnUserMan);
		// Save the number of rows in the table
#if Oracle
      // The OLE DB Provider for Oracle returns a value of type Decimal
      objNumRows = cmmUserMan.ExecuteScalar();
#else
      intNumRows = (int) cmmUserMan.ExecuteScalar();
#endif
	}

	// Listing 3A-26
	public void CheckCommandTimeoutPropertyException() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUserMan;
		string strSQL;

		try {
			// Instantiate the connection
			cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
			// Open the connection
			cnnUserMan.Open();
			// Build query string
			strSQL = "SELECT * FROM tblUser";
			// Instantiate the command
			cmmUserMan = new OleDbCommand(strSQL, cnnUserMan);
			// Change command timeout
			cmmUserMan.CommandTimeout = -1;
		}
		catch (ArgumentException objException) {
			// Check if we tried to set command timeout to an invalid value
			if (objException.TargetSite.Name == "set_CommandTimeout") {
				MessageBox.Show("The CommandTimeout property threw the exception.");
			}
		}
	}

   // Listing 3A-29
	public void CheckUpdateRowSourcePropertyException() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUserMan;
		string strSQL;

		try {
			// Instantiate the connection
			cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
			// Open the connection
			cnnUserMan.Open();
			// Build query string
			strSQL = "SELECT * FROM tblUser";
			// Instantiate the command
			cmmUserMan = new OleDbCommand(strSQL, cnnUserMan);
			// Change Row source Update
			cmmUserMan.UpdatedRowSource = UpdateRowSource.OutputParameters + 3;
		}
		catch (ArgumentException objException) {
			// Check if we tried to set the row source update to an invalid value
			if (objException.TargetSite.Name == "set_UpdatedRowSource") {
				MessageBox.Show("The UpdatedRowSource property threw the exception.");
			}
		}
	}

	// Listing 3A-30
	public void InstantiateDataReader() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUserMan;
		OleDbDataReader drdUserMan;
		string strSQL;

		// Instantiate the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		// Open the connection
		cnnUserMan.Open();
		// Build query string
		strSQL = "SELECT * FROM tblUser";
		// Instantiate the command
		cmmUserMan = new OleDbCommand(strSQL, cnnUserMan);
		// Instantiate data reader using the ExecuteReader method 
		// of the command class
		drdUserMan = cmmUserMan.ExecuteReader();
	}

	// Listing 3A-31
	public void ReadRowsFromDataReader() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUserMan;
		OleDbDataReader drdUser;
		string strSQL;
		long lngCounter = 0;

		// Instantiate the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		// Open the connection
		cnnUserMan.Open();
		// Build query string
		strSQL = "SELECT * FROM tblUser";
		// Instantiate the command
		cmmUserMan = new OleDbCommand(strSQL, cnnUserMan);
		// Excute command and return rows in data reader
		drdUser = cmmUserMan.ExecuteReader();
		// Loop through all the returned rows
		while (drdUser.Read()) {
			++lngCounter;
		}

		// Display the number of rows returned
		MessageBox.Show(lngCounter.ToString());
	}

	// Listing 3A-32
	public void CheckForNullValueInColumn(int intColumn) {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUserMan;
		OleDbDataReader drdUser;
		string strSQL;

		// Instantiate the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		// Open the connection
		cnnUserMan.Open();
		// Build query string
		strSQL = "SELECT * FROM tblUser";
		// Instantiate the command
		cmmUserMan = new OleDbCommand(strSQL, cnnUserMan);
		// Excute command and return rows in data reader
		drdUser = cmmUserMan.ExecuteReader();
		// Advance reader to first row
		drdUser.Read();
		// Check if the column contains a NULL value
		if (drdUser.IsDBNull(intColumn)) {
			MessageBox.Show("Column " + intColumn.ToString() + " contains a NULL value!");
		}
		else {
			MessageBox.Show("Column " + intColumn.ToString() + " does not contain a NULL value!");
		}
	}

	// Listing 3A-36
	public void InstantiateAndInitializeDataAdapter() {
		const string STR_SQL_USER = "SELECT * FROM tblUser";

		OleDbConnection cnnUserMan;
		OleDbCommand cmmUser;
		OleDbDataAdapter dadDefaultConstructor;
		OleDbDataAdapter dadOleDbCommandArgument;
		OleDbDataAdapter dadOleDbConnectionArgument;
		OleDbDataAdapter dadStringArguments;

		// Instantiate and open the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();
		// Instantiate the command
		cmmUser = new OleDbCommand(STR_SQL_USER);

		// Instantiate data adapters
		dadDefaultConstructor = new OleDbDataAdapter();
		dadOleDbCommandArgument = new OleDbDataAdapter(cmmUser);
		dadOleDbConnectionArgument = new OleDbDataAdapter(STR_SQL_USER, cnnUserMan);
		dadStringArguments = new OleDbDataAdapter(STR_SQL_USER, STR_CONNECTION_STRING);
		// Initialize data adapters
		dadDefaultConstructor.SelectCommand = cmmUser;
		dadDefaultConstructor.SelectCommand.Connection = cnnUserMan;
	}

	// Listing 3A-39
	public void SetDataAdapterCommandProperties() {
		const string STR_SQL_USER_SELECT = "SELECT * FROM tblUser";
		const string STR_SQL_USER_DELETE  = "DELETE FROM tblUser WHERE Id=?";
#if Oracle
      // You need to manually add the id value using the USERID sequence
		const string STR_SQL_USER_INSERT = "INSERT INTO tblUser(Id, FirstName, " +
			"LastName, LoginName, Password) VALUES(USERID.NEXTVAL, ?, ?, ?, ?)";
#else
		const string STR_SQL_USER_INSERT = "INSERT INTO tblUser(FirstName, " +
			"LastName, LoginName, Password) VALUES(?, ?, ?, ?)";
#endif
		const string STR_SQL_USER_UPDATE = "UPDATE tblUser SET FirstName=" +
			"?, LastName=?, LoginName=?, Password=? WHERE Id=?";

		OleDbConnection cnnUserMan;
		OleDbCommand cmmUserSelect;
		OleDbCommand cmmUserDelete;
		OleDbCommand cmmUserInsert;
		OleDbCommand cmmUserUpdate;
		OleDbDataAdapter dadUserMan;
		OleDbParameter prmSQLDelete, prmSQLUpdate;

		// Instantiate and open the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();
		// Instantiate the commands
		cmmUserSelect = new OleDbCommand(STR_SQL_USER_SELECT, cnnUserMan);
		cmmUserDelete = new OleDbCommand(STR_SQL_USER_DELETE, cnnUserMan);
		cmmUserInsert = new OleDbCommand(STR_SQL_USER_INSERT, cnnUserMan);
		cmmUserUpdate = new OleDbCommand(STR_SQL_USER_UPDATE, cnnUserMan);

		// Instantiate data adapter
		dadUserMan = new OleDbDataAdapter(STR_SQL_USER_SELECT, cnnUserMan);
		// Set data adapter command properties
		dadUserMan.SelectCommand = cmmUserSelect;
		dadUserMan.InsertCommand = cmmUserInsert;
		dadUserMan.DeleteCommand = cmmUserDelete;
		dadUserMan.UpdateCommand = cmmUserUpdate;

		// Add Delete command parameters
		prmSQLDelete = dadUserMan.DeleteCommand.Parameters.Add("@Id", OleDbType.Integer, 4, "Id");
		prmSQLDelete.Direction = ParameterDirection.Input;
		prmSQLDelete.SourceVersion = DataRowVersion.Original;

		// Add Update command parameters
		cmmUserUpdate.Parameters.Add("@FirstName", OleDbType.VarChar, 50, "FirstName");
		cmmUserUpdate.Parameters.Add("@LastName", OleDbType.VarChar, 50, "LastName");
		cmmUserUpdate.Parameters.Add("@LoginName", OleDbType.VarChar, 50, "LoginName");
		cmmUserUpdate.Parameters.Add("@Password", OleDbType.VarChar, 50, "Password");

		prmSQLUpdate = dadUserMan.UpdateCommand.Parameters.Add("@Id", OleDbType.Integer, 4, "Id");
		prmSQLUpdate.Direction = ParameterDirection.Input;
		prmSQLUpdate.SourceVersion = DataRowVersion.Original;

		// Add insert command parameters
		cmmUserInsert.Parameters.Add("@FirstName", OleDbType.VarChar, 50, "FirstName");
		cmmUserInsert.Parameters.Add("@LastName", OleDbType.VarChar, 50, "LastName");
		cmmUserInsert.Parameters.Add("@LoginName", OleDbType.VarChar, 50, "LoginName");
		cmmUserInsert.Parameters.Add("@Password", OleDbType.VarChar, 50, "Password");
   }

   // Listing 3A-41-1
   protected static void OnFillError(object sender, FillErrorEventArgs args) {
      // Display a message indicating what table an error occurred in and
      // let the user decided whether to continue populating the dataset
      args.Continue = (MessageBox.Show("There were errors filling the Data Table: " + args.DataTable + 
         ". Do you want to continue?", "Continue Updating", MessageBoxButtons.YesNo, 
         MessageBoxIcon.Question) == DialogResult.Yes);
   }

   // Listing 3A-41-2
   public void TriggerFillErrorEvent() {
      DataSet dstUser = new DataSet("Users");
      // Declare and instantiate connection
      OleDbConnection cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
      // Declare and instantiate data adapter
      OleDbDataAdapter prdadUserMan = new OleDbDataAdapter("SELECT * FROM tblUser", 
         cnnUserMan);
      // Set up event handler
      prdadUserMan.FillError  += new FillErrorEventHandler(OnFillError);

      // Open the connection
      cnnUserMan.Open();
      // Populate the dataset
      prdadUserMan.Fill(dstUser, "tblUser"); 
   }

   // Listing 3A-42-1
   protected static void OnRowUpdating(object sender, OleDbRowUpdatingEventArgs e) {
      // Display a message showing all the Command properties
      // if a command exists
      if (! (e.Command == null)) {
         MessageBox.Show("Command Properties:\n\n" + 
            "CommandText: " + e.Command.CommandText + "\n" + 
            "CommandTimeout: " + e.Command.CommandTimeout.ToString() + "\n"  + 
            "CommandType: " + e.Command.CommandType.ToString(),
            "RowUpdating", MessageBoxButtons.OK, 
            MessageBoxIcon.Information);
      }
      // Display a message showing all the Errors properties, 
      // if an error exists
      if (! (e.Errors == null)) {
         MessageBox.Show("Errors Properties:\n\n" + 
            "HelpLink: " + e.Errors.HelpLink + "\n"  + 
            "Message: " + e.Errors.Message + "\n"  + 
            "Source: " + e.Errors.Source + "\n" +
            "StackTrace: " + e.Errors.StackTrace  + "\n" +
            "TargetSite: " + e.Errors.TargetSite  + "\n",
            "RowUpdating", MessageBoxButtons.OK, 
            MessageBoxIcon.Information);
      }
      // Display a message showing all the Errors properties
      MessageBox.Show("Misc. Properties:\n\n" + 
         "StatementType: " + e.StatementType.ToString() + "\n"  + 
         "Status: " + e.Status.ToString(),
         "RowUpdating", MessageBoxButtons.OK, 
         MessageBoxIcon.Information);
   }

   // Listing 3A-42-2
   protected static void OnRowUpdated(object sender, OleDbRowUpdatedEventArgs e) {
      // Display a message showing all the Command properties
      // if a command exists
      if (! (e.Command == null)) {
         MessageBox.Show("Command Properties:\n\n" + 
            "CommandText: " + e.Command.CommandText + "\n" + 
            "CommandTimeout: " + e.Command.CommandTimeout.ToString() + "\n"  + 
            "CommandType: " + e.Command.CommandType.ToString(),
            "RowUpdating", MessageBoxButtons.OK, 
            MessageBoxIcon.Information);
      }
      // Display a message showing all the Errors properties, 
      // if an error exists
      if (! (e.Errors == null)) {
         MessageBox.Show("Errors Properties:\n\n" + 
            "HelpLink: " + e.Errors.HelpLink + "\n"  + 
            "Message: " + e.Errors.Message + "\n"  + 
            "Source: " + e.Errors.Source + "\n" +
            "StackTrace: " + e.Errors.StackTrace  + "\n" +
            "TargetSite: " + e.Errors.TargetSite  + "\n",
            "RowUpdating", MessageBoxButtons.OK, 
            MessageBoxIcon.Information);
      }
      // Display a message showing all the Errors properties
      MessageBox.Show("Misc. Properties:\n\n" + 
         "StatementType: " + e.StatementType.ToString() + "\n"  + 
         "Status: " + e.Status.ToString(),
         "RowUpdating", MessageBoxButtons.OK, 
         MessageBoxIcon.Information);
   }

   // Listing 3A-42-3
   public void TriggerRowUpdateEvents() {
      DataSet dstUser = new DataSet("Users");
      // Declare and instantiate connection
      OleDbConnection cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
      // Declare and instantiate data adapter
      OleDbDataAdapter dadUserMan = new OleDbDataAdapter("SELECT * FROM tblUser", 
         cnnUserMan);
      // Declare and instantiate command builder
      OleDbCommandBuilder cmbUser = new OleDbCommandBuilder(dadUserMan);
      // Set up event handlers
      dadUserMan.RowUpdating  += new OleDbRowUpdatingEventHandler(OnRowUpdating);
      dadUserMan.RowUpdated  += new OleDbRowUpdatedEventHandler(OnRowUpdated);

      // Open the connection
      cnnUserMan.Open();
      // Populate the dataset
      dadUserMan.Fill(dstUser, "tblUser"); 
      // Modify second row
      dstUser.Tables["tblUser"].Rows[1]["FirstName"] = "Tom";
      // Populate the data source
      dadUserMan.Update(dstUser, "tblUser"); 
   }
   
   // Listing 3A-43
	public void SetDataAdapterCommandPropertiesUsingCommandBuilder() {
		const string STR_SQL_USER_SELECT = "SELECT * FROM tblUser";
#if Oracle
      // You need to manually add the id value using the USERID sequence
      const string STR_SQL_USER_INSERT = "INSERT INTO tblUser(Id, FirstName, " +
         "LastName, LoginName, Password) VALUES(USERID.NEXTVAL, ?, ?, ?, ?)";
#else
      const string STR_SQL_USER_INSERT = "INSERT INTO tblUser(FirstName, " +
         "LastName, LoginName, Password) VALUES(?, ?, ?, ?)";
#endif

		OleDbConnection cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		OleDbCommand cmmUserSelect = new OleDbCommand(STR_SQL_USER_SELECT, cnnUserMan);
      OleDbCommand cmmUserInsert = new OleDbCommand(STR_SQL_USER_INSERT, cnnUserMan);
      OleDbDataAdapter dadUserMan = new OleDbDataAdapter(cmmUserSelect);
#if Oracle
      dadUserMan.InsertCommand = cmmUserInsert;
#endif
      OleDbCommandBuilder cmbUser = new OleDbCommandBuilder(dadUserMan);
		DataSet dstDummy = new DataSet("DummyDataSet");

		// Open the connection
		cnnUserMan.Open();

		// Fill dummy data set, update row in table and update dataset
		dadUserMan.Fill(dstDummy, "tblUser");
      dstDummy.Tables["tblUser"].Rows.Add(new Object[7] {null, null, null, "1st Name", 
         "LastName", DateTime.Now.ToString().Replace(" ", ""), ""}); 
      dadUserMan.Update(dstDummy, "tblUser");
	}

	public void InstantiateDataSet() {
		DataSet dstUnnamed1 = new DataSet();
		DataSet dstNamed1 = new DataSet("UserManDataSet");

		DataSet dstUnnamed2;
		DataSet dstNamed2;

		dstUnnamed2 = new DataSet();
		dstNamed2 = new DataSet("UserManDataSet");
	}

   // Listing 3B-2-1
   private static void OnMergeFailed(object sender, MergeFailedEventArgs args) {
      // Display a message detailing the merge conflict
      MessageBox.Show("There were errors when merging the datasets:\n\n" + 
         args.Conflict + " The conflict happened in table " + args.Table + ".");
   }

   // Listing 3B-2-2
   public void TriggerMergeFailureEvent() {
      // Declare and instantiate data sets
      DataSet dstUser1 = new DataSet("Users1");
      DataSet dstUser2 = new DataSet("Users2");

      // Declare and instantiate connections
      OleDbConnection cnnUserMan1 = new OleDbConnection(STR_CONNECTION_STRING);
#if SQLSERVER
      OleDbConnection cnnUserMan2 = new OleDbConnection("Provider=SQLOLEDB;Data Source=DBSERVER;User Id=UserMan;Password=userman;Initial Catalog=UserMan");
#elif MSAccess
      OleDbConnection cnnUserMan2 = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Database.mdb;User Id=;Password=;");
#elif Oracle
      OleDbConnection cnnUserMan2 = new OleDbConnection("Provider=MSDAORA;Data Source=DB;User Id=UserMan;Password=userman");
#endif

      // Declare and instantiate data adapters
      OleDbDataAdapter prdadUserMan1 = new OleDbDataAdapter("SELECT * FROM tblUser", 
         cnnUserMan1);
      OleDbDataAdapter prdadUserMan2 = new OleDbDataAdapter("SELECT * FROM tblUser", 
         cnnUserMan2);
      // Set up event handler
      dstUser1.MergeFailed += new MergeFailedEventHandler(OnMergeFailed);

      // Open the connections
      cnnUserMan1.Open();
      cnnUserMan2.Open();
      // Populate the datasets
      prdadUserMan1.Fill(dstUser1, "tblUser"); 
      prdadUserMan2.Fill(dstUser2, "tblUser"); 
      // Close the connections
      cnnUserMan1.Close();
      cnnUserMan2.Close();

      // Merge the data sets
      dstUser1.Merge(dstUser2);
   }
   
   // Listing 3B-3
	public void FillDataSetFromRecordset() {
		const string STR_SQL_USER_SELECT = "SELECT * FROM tblUser";

		OleDbConnection cnnUserMan;
		OleDbDataAdapter dadUserMan;
		DataSet dstUserMan;

		ADODB.Recordset rstUser;
		ADODB.Connection cnnADOUserMan;

		int intNumRows;

		// Instantiate and open the connections
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();
		cnnADOUserMan = new ADODB.Connection();
		cnnADOUserMan.Open(STR_CONNECTION_STRING, "", "", 0);

		// Instantiate data adapter
		dadUserMan = new OleDbDataAdapter(STR_SQL_USER_SELECT, cnnUserMan);

		// Instantiate dataset
		dstUserMan = new DataSet();
		// Instantiate recordset
		rstUser = new ADODB.Recordset();

		// Populate recordset
		rstUser.Open(STR_SQL_USER_SELECT, cnnADOUserMan, 
			ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockReadOnly, 0);
		// Fill dataset
		intNumRows = dadUserMan.Fill(dstUserMan, rstUser, "tblUser");
	}	

	// Listing 3B-4
	public void UpdateDataSet() {
		const string STR_SQL_USER_SELECT = "SELECT * FROM tblUser";
		const string STR_SQL_USER_DELETE = "DELETE FROM tblUser WHERE Id=?";
#if Oracle
      // You need to manually add the id value using the USERID sequence
      const string STR_SQL_USER_INSERT = "INSERT INTO tblUser(Id, FirstName, " +
               "LastName, LoginName, Password) VALUES(USERID.NEXTVAL, ?, ?, ?, ?)";
#else
		const string STR_SQL_USER_INSERT = "INSERT INTO tblUser(FirstName, " +
					"LastName, LoginName, Password) VALUES(?, ?, ?, ?)";
#endif
		const string STR_SQL_USER_UPDATE = "UPDATE tblUser SET FirstName=?, " +
					"LastName=?, LoginName=?, Password=? WHERE Id=?";

		OleDbConnection cnnUserMan;
		OleDbCommand cmmUserSelect;
		OleDbCommand cmmUserDelete;
		OleDbCommand cmmUserInsert;
		OleDbCommand cmmUserUpdate;
		OleDbDataAdapter dadUserMan;
		DataSet dstUserMan, dstChanges;
		DataRow drwUser;
		OleDbParameter prmSQLDelete, prmSQLUpdate;

		// Instantiate and open the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();

		// Instantiate the commands
		cmmUserSelect = new OleDbCommand(STR_SQL_USER_SELECT, cnnUserMan);
		cmmUserDelete = new OleDbCommand(STR_SQL_USER_DELETE, cnnUserMan);
		cmmUserInsert = new OleDbCommand(STR_SQL_USER_INSERT, cnnUserMan);
		cmmUserUpdate = new OleDbCommand(STR_SQL_USER_UPDATE, cnnUserMan);

		// Instantiate data adapter
		dadUserMan = new OleDbDataAdapter(STR_SQL_USER_SELECT, cnnUserMan);
		// Set data adapter command properties
		dadUserMan.SelectCommand = cmmUserSelect;
		dadUserMan.InsertCommand = cmmUserInsert;
		dadUserMan.DeleteCommand = cmmUserDelete;
		dadUserMan.UpdateCommand = cmmUserUpdate;

		// Add Delete command parameters
		prmSQLDelete = dadUserMan.DeleteCommand.Parameters.Add("@Id", OleDbType.Integer, 0, "Id");
		prmSQLDelete.Direction = ParameterDirection.Input;
		prmSQLDelete.SourceVersion = DataRowVersion.Original;

		// Add Update command parameters
		cmmUserUpdate.Parameters.Add("@FirstName", OleDbType.VarChar, 50, "FirstName");
		cmmUserUpdate.Parameters.Add("@LastName", OleDbType.VarChar, 50, "LastName");
		cmmUserUpdate.Parameters.Add("@LoginName", OleDbType.VarChar, 50, "LoginName");
		cmmUserUpdate.Parameters.Add("@Password", OleDbType.VarChar, 50, "Password");

		prmSQLUpdate = dadUserMan.UpdateCommand.Parameters.Add("@Id", OleDbType.Integer, 0, "Id");
		prmSQLUpdate.Direction = ParameterDirection.Input;
		prmSQLUpdate.SourceVersion = DataRowVersion.Original;

		// Add insert command parameters
		cmmUserInsert.Parameters.Add("@FirstName", OleDbType.VarChar, 50, "FirstName");
		cmmUserInsert.Parameters.Add("@LastName", OleDbType.VarChar, 50, "LastName");
		cmmUserInsert.Parameters.Add("@LoginName", OleDbType.VarChar, 50, "LoginName");
		cmmUserInsert.Parameters.Add("@Password", OleDbType.VarChar, 50, "Password");

		// Instantiate dataset
		dstUserMan = new DataSet();
		// Populate the data set
		dadUserMan.Fill(dstUserMan, "tblUser");

		// Add new row
		drwUser = dstUserMan.Tables["tblUser"].NewRow();
		drwUser["FirstName"] = "New User";
		drwUser["LastName"] = "New User LastName";
		drwUser["LoginName"] = "NewUser";
		drwUser["Password"] = "password";
		dstUserMan.Tables["tblUser"].Rows.Add(drwUser);

		// Update an existing row (with index 3)
		dstUserMan.Tables["tblUser"].Rows[3]["FirstName"] = "FirstName";
		dstUserMan.Tables["tblUser"].Rows[3]["LastName"] = "LastName";
		dstUserMan.Tables["tblUser"].Rows[3]["LoginName"] = "User3";

		// Delete row with index 4
		dstUserMan.Tables["tblUser"].Rows[4].Delete();

		// Check if any data has changed in the data set
		if (dstUserMan.HasChanges()) {
			// Save all changed rows in a new data set
			dstChanges = dstUserMan.GetChanges();
			// Check if the changed rows contains any errors
			if (dstChanges.HasErrors) {
				// Reject the changes
				dstUserMan.RejectChanges();
			}
			else {
				// Update the data source
				dadUserMan.Update(dstChanges, "tblUser");
			}
		}
	}

	public void ClearDataSet() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUser;
		OleDbDataAdapter dadUser;
		DataSet dstUser;

		// Instantiate and open the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();
		// Instantiate the command
		cmmUser = new OleDbCommand("SELECT * FROM tblUser", cnnUserMan);
		// Instantiate and initialize the data adapter
		dadUser = new OleDbDataAdapter();
		dadUser.SelectCommand = cmmUser;
		// Instantiate data set
		dstUser = new DataSet();
		// Fill the data set
		dadUser.Fill(dstUser, "tblUser");
		// Do your stuff
		// ...
		// Clear the data from the data set
		dstUser.Clear();
	}

	public void CloneDataSetStructure() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUser;
		OleDbDataAdapter dadUser;
		DataSet dstUser;
		DataSet dstClone;

		// Instantiate and open the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();
		// Instantiate the command and data set
		cmmUser = new OleDbCommand("SELECT * FROM tblUser", cnnUserMan);
		dstUser = new DataSet();
		// Instantiate and initialize the data adapter
		dadUser = new OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan);
		dadUser.SelectCommand = cmmUser;
		// Fill the data set
		dadUser.Fill(dstUser, "tblUser");
		// Clone the data set
		dstClone = dstUser.Clone();
	}

	public void CopyDataSetStructureAndData() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUser;
		OleDbDataAdapter dadUser;
		DataSet dstUser;
		DataSet dstCopy;

		// Instantiate and open the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();
		// Instantiate the command and data set
		cmmUser = new OleDbCommand("SELECT * FROM tblUser", cnnUserMan);
		dstUser = new DataSet();
		// Instantiate and initialize the data adapter
		dadUser = new OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan);
		dadUser.SelectCommand = cmmUser;
		// Fill the data set
		dadUser.Fill(dstUser, "tblUser");
		// Copy the data set
		dstCopy = dstUser.Copy();
	}

	// Listing 3B-5
	public void MergeDataSetWithDataRows() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUser;
		OleDbDataAdapter dadUser;
		DataSet dstUser;
		DataTable dtbUser;
		DataRow[] arrdrwUser = new DataRow[1];
		DataRow drwUser;

		// Instantiate and open the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();
		// Instantiate the command, data set and data table
		cmmUser = new OleDbCommand("SELECT * FROM tblUser", cnnUserMan);
		dstUser = new DataSet();
		dtbUser = new DataTable();
		// Instantiate and initialize the data adapter
		dadUser = new OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan);
		dadUser.SelectCommand = cmmUser;
		// Fill the data set
		dadUser.Fill(dstUser, "tblUser");
		// Create new row and fill with data
		drwUser = dstUser.Tables["tblUser"].NewRow();
		drwUser["LoginName"] = "NewUser1";
		drwUser["FirstName"] = "New";
		drwUser["LastName"] = "User";
		arrdrwUser.SetValue(drwUser, 0);
		// Merge the data set with the data row array
		dstUser.Merge(arrdrwUser);
	}

	// Listing 3B-6
	public void MergeDataSets() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUser;
		OleDbDataAdapter dadUser;
		DataSet dstUser;
		DataSet dstCopy;

		// Instantiate and open the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();
		// Instantiate the command and data set
		cmmUser = new OleDbCommand("SELECT * FROM tblUser", cnnUserMan);
		dstUser = new DataSet();
		// Instantiate and initialize the data adapter
		dadUser = new OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan);
		dadUser.SelectCommand = cmmUser;
		// Fill the data set
		dadUser.Fill(dstUser, "tblUser");
		// Copy the data set
		dstCopy = dstUser.Copy();
		// Do your stuff with the data sets
		// ...
		// Merge the two data sets
		dstUser.Merge(dstCopy);
	}

	// Listing 3B-7
	public void MergeDataSetWithDataTable() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUser;
		OleDbDataAdapter dadUser;
		DataSet dstUser;
		DataTable dtbUser;

		// Instantiate and open the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();
		// Instantiate the command, data set and data table
		cmmUser = new OleDbCommand("SELECT * FROM tblUser", cnnUserMan);
		dstUser = new DataSet();
		dtbUser = new DataTable();
		// Instantiate and initialize the data adapter
		dadUser = new OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan);
		dadUser.SelectCommand = cmmUser;
		// Fill the data set and data table
		dadUser.Fill(dstUser, "tblUser");
		dadUser.Fill(dtbUser);
		// Do your stuff with the data set and the data table
		// ...
		// Merge the data set with the data table
		dstUser.Merge(dtbUser);
	}

	// Listing 3B-8
	public void DetectAllDataSetChanges() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUser;
		OleDbDataAdapter dadUser;
		DataSet dstUser;
		DataSet dstChanges;

		// Instantiate and open the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();
		// Instantiate the command and data set
		cmmUser = new OleDbCommand("SELECT * FROM tblUser", cnnUserMan);
		dstUser = new DataSet();
		// Instantiate and initialize the data adapter
		dadUser = new OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan);
		dadUser.SelectCommand = cmmUser;
		// Fill the data set
		dadUser.Fill(dstUser, "tblUser");
		// Do your stuff with the data set
		// ...
		// Check if any data has changed in the data set
		if (dstUser.HasChanges()) {
			// Save all changes in a new data set
			dstChanges = dstUser.GetChanges();
		}
	}

	// Listing 3B-9
	public void DetectDifferentDataSetChanges() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUser;
		OleDbDataAdapter dadUser;
		DataSet dstUser;
		DataSet dstChanges;
		DataSet dstAdditions;
		DataSet dstDeletions;

		// Instantiate and open the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();
		// Instantiate the command and data set
		cmmUser = new OleDbCommand("SELECT * FROM tblUser", cnnUserMan);
		dstUser = new DataSet();
		// Instantiate and initialize the data adapter
		dadUser = new OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan);
		dadUser.SelectCommand = cmmUser;
		// Fill the data set
		dadUser.Fill(dstUser, "tblUser");
		// Do your stuff with the data set
		// ...
		// Check if any data has changed in the data set
		if (dstUser.HasChanges()) {
			// Save all modified rows in a new data set
			dstChanges = dstUser.GetChanges(DataRowState.Modified);
			// Save all added rows in a new data set
			dstAdditions = dstUser.GetChanges(DataRowState.Added);
			// Save all deleted rows in a new data set
			dstDeletions = dstUser.GetChanges(DataRowState.Deleted);
		}
	}

	// Listing 3B-10
	public void AcceptOrRejectDataSetChanges() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUser;
		OleDbDataAdapter dadUser;
		DataSet dstUser, dstChanges;
		DataRow drwUser;

		// Instantiate and open the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();
		// Instantiate the command and the data set
		cmmUser = new OleDbCommand("SELECT * FROM tblUser", cnnUserMan);
		dstUser = new DataSet();
		// Instantiate and initialize the data adapter
		dadUser = new OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan);
		dadUser.SelectCommand = cmmUser;
		// Fill the data set
		dadUser.Fill(dstUser, "tblUser");
		// Create a new data row with the schema from the user table
		drwUser = dstUser.Tables["tblUser"].NewRow();
		// Enter values in the data row columns
		drwUser["LoginName"] = "NewUser1";
		drwUser["FirstName"] = "New";
		drwUser["LastName"] = "User";
		// Add the data row to the user table
		dstUser.Tables["tblUser"].Rows.Add(drwUser);
		// Check if any data has changed in the data set
		if (dstUser.HasChanges()) {
			// Save all changed rows in a new data set
			dstChanges = dstUser.GetChanges();
			// Check if the changed rows contains any errors
			if (dstChanges.HasErrors) {
				// Display the row state of all rows before rejecting changes
				for (int intCounter = 0; intCounter <= dstUser.Tables[0].Rows.Count - 1; intCounter++) {
					MessageBox.Show("HasErrors=True, Before RejectChanges, RowState=" +
						dstUser.Tables[0].Rows[intCounter].RowState.ToString() +
						", LoginName=" +
						dstUser.Tables[0].Rows[intCounter]["LoginName"].ToString());
				}
				// Reject the changes to the data set
				dstUser.RejectChanges();
				// Display the row state of all rows after rejecting changes
				for (int intCounter = 0;  intCounter <= dstUser.Tables[0].Rows.Count - 1; intCounter++) {
					MessageBox.Show("HasErrors=True, After RejectChanges, RowState=" +
						dstUser.Tables[0].Rows[intCounter].RowState.ToString() +
						", LoginName=" +
						dstUser.Tables[0].Rows[intCounter]["LoginName"].ToString());
				}
			}																																																																
		}
		else {
			// Display the row state of all rows before accepting changes
			for (int intCounter = 0; intCounter <= dstUser.Tables[0].Rows.Count - 1; intCounter++) {
				MessageBox.Show("HasErrors=False, Before AcceptChanges, RowState=" +
					dstUser.Tables[0].Rows[intCounter].RowState.ToString() +
					", LoginName=" +
					dstUser.Tables[0].Rows[intCounter]["LoginName"].ToString());
			}
			// Accept the changes to the data set
			dstUser.AcceptChanges();
			// Display the row state of all rows after accepting changes
			for (int intCounter = 0; intCounter <= dstUser.Tables[0].Rows.Count - 1; intCounter++) {
				MessageBox.Show("HasErrors=False, After AcceptChanges, RowState=" +
					dstUser.Tables[0].Rows[intCounter].RowState.ToString() +
					", LoginName=" +
					dstUser.Tables[0].Rows[intCounter]["LoginName"].ToString());
			}
		}
	}

	public void InstantiateDataTable() {
		DataTable dtbNoArgumentsWithInitialize = new DataTable();
		DataTable dtbTableNameArgumentWithInitialize = new DataTable("TableName");

		DataTable dtbNoArgumentsWithoutInitialize;
		DataTable dtbTableNameArgumentWithoutInitialize;

		dtbNoArgumentsWithoutInitialize = new DataTable();
		dtbTableNameArgumentWithoutInitialize = new DataTable("TableName");
	}

	// Listing 3B-11
	public void BuildDataTable() {
		DataTable dtbUser;
		DataColumn dclUser;
		DataColumn[] arrdclPrimaryKey = new DataColumn[1];

		dtbUser = new DataTable("tblUser");

		// Create table structure
		dclUser = new DataColumn();
		dclUser.ColumnName = "Id";
		dclUser.DataType = Type.GetType("System.Int32");
		dclUser.AutoIncrement = true;
		dclUser.AutoIncrementSeed = 1;
		dclUser.AutoIncrementStep = 1;
		dclUser.AllowDBNull = false;
		//' Add column to data table structure
		dtbUser.Columns.Add(dclUser);
		// Add column to PK array
		arrdclPrimaryKey[0] = dclUser;
		// Set primary key
		dtbUser.PrimaryKey = arrdclPrimaryKey;

		dclUser = new DataColumn();
		dclUser.ColumnName = "ADName";
		dclUser.DataType = Type.GetType("System.String");
		// Add column to data table structure
		dtbUser.Columns.Add(dclUser);

		dclUser = new DataColumn();
		dclUser.ColumnName = "ADSID";
		dclUser.DataType = Type.GetType("System.String");
		// Add column to data table structure
		dtbUser.Columns.Add(dclUser);

		dclUser = new DataColumn();
		dclUser.ColumnName = "FirstName";
		dclUser.DataType = Type.GetType("System.String");
		// Add column to data table structure
		dtbUser.Columns.Add(dclUser);

		dclUser = new DataColumn();
		dclUser.ColumnName = "LastName";
		dclUser.DataType = Type.GetType("System.String");
		// Add column to data table structure
		dtbUser.Columns.Add(dclUser);

		dclUser = new DataColumn();
		dclUser.ColumnName = "LoginName";
		dclUser.DataType = Type.GetType("System.String");
		dclUser.AllowDBNull = false;
		dclUser.Unique = true;
		// Add column to data table structure
		dtbUser.Columns.Add(dclUser);
		dclUser = new DataColumn();
		dclUser.ColumnName = "Password";
		dclUser.DataType = Type.GetType("System.String");
		dclUser.AllowDBNull = false;
		// Add column to data table structure
		dtbUser.Columns.Add(dclUser);
	}

	public void ClearDataTable() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUser;
		OleDbDataAdapter dadUser;
		DataTable dtbUser;

		// Instantiate and open the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();

		// Instantiate the command
		cmmUser = new OleDbCommand("SELECT * FROM tblUser", cnnUserMan);
		// Instantiate and initialize the data adapter
		dadUser = new OleDbDataAdapter();
		dadUser.SelectCommand = cmmUser;
		// Instantiate data table
		dtbUser = new DataTable("tblUser");
		// Fill the data table
		dadUser.Fill(dtbUser);
		// Do your stuff
		// ...
		// Clear the data from the data table
		dtbUser.Clear();
	}

	// Listing 3B-12
	public void CloneDataTableStructure() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUser;
		OleDbDataAdapter dadUser;
		DataTable dtbUser;
		DataTable dtbClone;

		// Instantiate and open the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();
		// Instantiate the command and data table
		cmmUser = new OleDbCommand("SELECT * FROM tblUser", cnnUserMan);
		dtbUser = new DataTable();
		// Instantiate and initialize the data adapter
		dadUser = new OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan);
		dadUser.SelectCommand = cmmUser;
		// Fill the data table
		dadUser.Fill(dtbUser);
		// Clone the data table
		dtbClone = dtbUser.Clone();
	}

	// Listing 3B-13
	public void CopyDataTable() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUser;
		OleDbDataAdapter dadUser;
		DataTable dtbUser;
		DataTable dtbCopy;

		// Instantiate and open the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();
		// Instantiate the command and data tables
		cmmUser = new OleDbCommand("SELECT * FROM tblUser", cnnUserMan);
		dtbUser = new DataTable();
		// Instantiate and initialize the data adapter
		dadUser = new OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan);
		dadUser.SelectCommand = cmmUser;
		// Fill the data table
		dadUser.Fill(dtbUser);
		// Copy the data table
		dtbCopy = dtbUser.Copy();
	}

	// Listing 3B-14
	public void SearchDataTable() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUser;
		OleDbDataAdapter dadUser;
		DataTable dtbUser;

		// Instantiate and open the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();
		// Instantiate the command and data table
		cmmUser = new OleDbCommand("SELECT * FROM tblUser", cnnUserMan);
		dtbUser = new DataTable();
		// Instantiate and initialize the data adapter
		dadUser = new OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan);
		dadUser.SelectCommand = cmmUser;
		// Fill the data table
		dadUser.Fill(dtbUser);
		// Filter the data table view
		dtbUser.DefaultView.RowFilter = "LastName = 'Doe'";

		// Loop through all the rows in the data table view
		for (int intCounter = 0; intCounter <= dtbUser.DefaultView.Count - 1; intCounter++) {
			MessageBox.Show(dtbUser.DefaultView[0].Row["LastName"].ToString());
		}
	}

	// Listing 3B-15
	public void CopyRowsInDataTable() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUser;
		OleDbDataAdapter dadUser;
		DataTable dtbUser;
		OleDbCommandBuilder cmbUser;

		// Instantiate and open the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();
		// Instantiate the command and data table
		cmmUser = new OleDbCommand("SELECT * FROM tblUser", cnnUserMan);
		dtbUser = new DataTable();
		// Instantiate and initialize the data adapter
		dadUser = new OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan);
		dadUser.SelectCommand = cmmUser;
		cmbUser = new OleDbCommandBuilder(dadUser);
		// Fill the data table
		dadUser.Fill(dtbUser);

		// Copy a row from the same table using ImportRow method
		dtbUser.ImportRow(dtbUser.Rows[0]);	
		// Make sure the Update method detects the new row
		dtbUser.Rows[dtbUser.Rows.Count - 1]["LoginName"] = "NewLogin1";

		// Copy the first row from the same table using the LoadDataRow
		// If you change the last argument of this method to true, the
		// RowState property will be set to Unchanged
		dtbUser.LoadDataRow(new Object[7] {null, dtbUser.Rows[0]["ADName"], 
														 dtbUser.Rows[0]["ADSID"], dtbUser.Rows[0]["FirstName"], 
														 dtbUser.Rows[0]["LastName"], "NewLogin2", 
														 dtbUser.Rows[0]["Password"]}, false);

		// Loop through all the rows in the data table,
		// displaying the Id and RowState value
		for (int intCounter = 0; intCounter <= dtbUser.Rows.Count - 1; intCounter++) {
			MessageBox.Show(dtbUser.Rows[intCounter]["Id"].ToString() + " " +
				dtbUser.Rows[intCounter].RowState.ToString());
		}

		// Update the data source
		dadUser.Update(dtbUser);
	}

   // Listing 3B-16-1
   private static void OnColumnChanging(object sender, DataColumnChangeEventArgs e) {
      // Display a message showing some of the Column properties
      MessageBox.Show("Column Properties:\n\n" + 
         "ColumnName: " + e.Column.ColumnName + "\n" + 
         "DataType: " + e.Column.DataType.ToString() + "\n"  + 
         "CommandType: " + e.Column.Table.ToString() + "\n"  + 
         "Original Value: " + e.Row[e.Column.ColumnName, DataRowVersion.Original].ToString() + "\n"  + 
         "Proposed Value: " + e.ProposedValue.ToString(),
         "ColumnChanging", MessageBoxButtons.OK, 
         MessageBoxIcon.Information);
   }

   // Listing 3B-16-2
   private static void OnColumnChanged(object sender, DataColumnChangeEventArgs e) {
      // Display a message showing some of the Column properties
      MessageBox.Show("Column Properties:\n\n" + 
         "ColumnName: " + e.Column.ColumnName + "\n" + 
         "DataType: " + e.Column.DataType.ToString() + "\n"  + 
         "CommandType: " + e.Column.Table.ToString() + "\n"  + 
         "Original Value: " + e.Row[e.Column.ColumnName, DataRowVersion.Original].ToString() + "\n"  + 
         "Proposed Value: " + e.ProposedValue.ToString(),
         "ColumnChanged", MessageBoxButtons.OK, 
         MessageBoxIcon.Information);
   }

   // Listing 3B-16-3
   public void TriggerColumnChangeEvents() {
      DataTable dtbUser = new DataTable("tblUser");
      // Declare and instantiate connection
      OleDbConnection cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
      // Declare and instantiate data adapter
      OleDbDataAdapter dadUserMan = new OleDbDataAdapter("SELECT * FROM tblUser", 
         cnnUserMan);
      // Set up event handlers
      dtbUser.ColumnChanging += new DataColumnChangeEventHandler(OnColumnChanging);
      dtbUser.ColumnChanged += new DataColumnChangeEventHandler(OnColumnChanged);

      // Open the connection
      cnnUserMan.Open();
      // Populate the data table
      dadUserMan.Fill(dtbUser); 
      // Modify second row, this triggers the Column Change events
      dtbUser.Rows[1]["FirstName"] = "Tom";
   }

   // Listing 3B-17-1
   private static void OnRowChanging(object sender, DataRowChangeEventArgs e) {
      // Display a message showing some of the Row properties
      MessageBox.Show("Row Properties:\n\n" + 
         "RowState: " + e.Row.RowState.ToString() + "\n" + 
         "Table: " + e.Row.Table.ToString() + "\n" + 
         "Action: " + e.Action.ToString(),
         "RowChanging", MessageBoxButtons.OK, 
         MessageBoxIcon.Information);
   }

   // Listing 3B-17-2
   private static void OnRowChanged(object sender, DataRowChangeEventArgs e) {
      // Display a message showing some of the Row properties
      MessageBox.Show("Row Properties:\n\n" + 
         "RowState: " + e.Row.RowState.ToString() + "\n" + 
         "Table: " + e.Row.Table.ToString() + "\n" + 
         "Action: " + e.Action.ToString(),
         "RowChanged", MessageBoxButtons.OK, 
         MessageBoxIcon.Information);
   }

   // Listing 3B-17-3
   public void TriggerRowChangeEvents() {
      DataTable dtbUser = new DataTable("tblUser");
      // Declare and instantiate connection
      OleDbConnection cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
      // Declare and instantiate data adapter
      OleDbDataAdapter dadUserMan = new OleDbDataAdapter("SELECT * FROM tblUser", 
         cnnUserMan);
      // Set up event handlers
      dtbUser.RowChanging += new DataRowChangeEventHandler(OnRowChanging);
      dtbUser.RowChanged += new DataRowChangeEventHandler(OnRowChanged);

      // Open the connection
      cnnUserMan.Open();
      // Populate the data table
      dadUserMan.Fill(dtbUser); 
      // Modify second row, this triggers the row Change events
      dtbUser.Rows[1]["FirstName"] = "Tom";
   }

   // Listing 3B-18-1
   private static void OnRowDeleting(object sender, DataRowChangeEventArgs e) {
      // Display a message showing some of the Row properties
      MessageBox.Show("Row Properties:\n\n" + 
         "RowState: " + e.Row.RowState.ToString() + "\n" + 
         "Table: " + e.Row.Table.ToString() + "\n" + 
         "Action: " + e.Action.ToString(),
         "RowChanging", MessageBoxButtons.OK, 
         MessageBoxIcon.Information);
   }

   // Listing 3B-18-2
   private static void OnRowDeleted(object sender, DataRowChangeEventArgs e) {
      // Display a message showing some of the Row properties
      MessageBox.Show("Row Properties:\n\n" + 
         "RowState: " + e.Row.RowState.ToString() + "\n" + 
         "Table: " + e.Row.Table.ToString() + "\n" + 
         "Action: " + e.Action.ToString(),
         "RowChanged", MessageBoxButtons.OK, 
         MessageBoxIcon.Information);
   }

   // Listing 3B-18-3
   public void TriggerRowDeleteEvents() {
      DataTable dtbUser = new DataTable("tblUser");
      // Declare and instantiate connection
      OleDbConnection cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
      // Declare and instantiate data adapter
      OleDbDataAdapter dadUserMan = new OleDbDataAdapter("SELECT * FROM tblUser", 
         cnnUserMan);
      // Set up event handlers
      dtbUser.RowDeleting += new DataRowChangeEventHandler(OnRowDeleting);
      dtbUser.RowDeleted += new DataRowChangeEventHandler(OnRowDeleted);

      // Open the connection
      cnnUserMan.Open();
      // Populate the data table
      dadUserMan.Fill(dtbUser); 
      // Delete second row, this triggers the row delete events
      dtbUser.Rows[1].Delete();
   }

   // Listing 3B-19-1
   protected void OnListChanged(object sender, System.ComponentModel.ListChangedEventArgs args) {
      // Display a message showing some of the List properties
      MessageBox.Show("List Properties:\n\n" + 
         "ListChangedType: " + args.ListChangedType.ToString() + "\n" + 
         "OldIndex: " + args.OldIndex.ToString() + "\n" + 
         "NewIndex: " + args.NewIndex.ToString(),
         "ListChanged", MessageBoxButtons.OK, 
         MessageBoxIcon.Information);
   }

   // Listing 3B-19-2
   public void TriggerListChangeEvent() {
      DataTable dtbUser = new DataTable("tblUser");
      // Declare and instantiate connection
      OleDbConnection cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
      // Declare and instantiate data adapter
      OleDbDataAdapter dadUserMan = new OleDbDataAdapter("SELECT * FROM tblUser", 
         cnnUserMan);

      // Open the connection
      cnnUserMan.Open();
      // Populate the data table
      dadUserMan.Fill(dtbUser); 
      // Declare and instantiate data view
      DataView dvwUser = new DataView(dtbUser);
      // Set up event handler
      dvwUser.ListChanged  += new System.ComponentModel.ListChangedEventHandler(OnListChanged);
      // Trigger list change event by adding new item/row
      dvwUser.AddNew();
   }

   public void InstantiateDataView() {
		DataSet dstUser = new DataSet();

		DataView dvwNoArgumentsWithInitializer = new DataView();
		DataView dvwTableArgumentWithInitializer = new DataView(dstUser.Tables["tblUser"]);

		DataView dvwNoArgumentsWithoutInitializer;
		DataView dvwTableArgumentWithoutInitializer;

		dvwNoArgumentsWithoutInitializer = new DataView();
		dvwTableArgumentWithoutInitializer = new DataView(dstUser.Tables["tblUser"]);
	}

	// Listing 3B-20
	public void SearchDataView() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUser;
		OleDbDataAdapter dadUser;
		DataTable dtbUser;
		DataView dvwUser;
		Object objPKValue;
		int intIndex;

		// Instantiate and open the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();
		// Instantiate the command and data table
		cmmUser = new OleDbCommand("SELECT * FROM tblUser", cnnUserMan);
		dtbUser = new DataTable();
		// Instantiate and initialize the data adapter
		dadUser = new OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan);
		dadUser.SelectCommand = cmmUser;
		// Fill the data table
		dadUser.Fill(dtbUser);
		// Filter the data table view
		dtbUser.DefaultView.RowFilter = "LastName = 'Doe'";
		// Create the new data view
		dvwUser = dtbUser.DefaultView;
		// Specify a sort order
		dvwUser.Sort = "Id ASC";
		// Find the user with an id of 1
		objPKValue = 1;
		intIndex = dvwUser.Find(objPKValue);
      MessageBox.Show(dvwUser[intIndex].Row["LastName"].ToString());
   }

	// Listing 3B-21
	public void SortDataView() {
		OleDbConnection cnnUserMan;
		OleDbCommand cmmUser;
		OleDbDataAdapter dadUser;
		DataTable dtbUser;

		// Instantiate and open the connection
		cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();
		// Instantiate the command and data table
		cmmUser = new OleDbCommand("SELECT * FROM tblUser", cnnUserMan);
		dtbUser = new DataTable();
		// Instantiate and initialize the data adapter
		dadUser = new OleDbDataAdapter("SELECT * FROM tblUser", cnnUserMan);
		dadUser.SelectCommand = cmmUser;
		// Fill the data table
		dadUser.Fill(dtbUser);
		// Sort the data table view after LastName in ascending order
		dtbUser.DefaultView.Sort = "LastName ASC";

		// Loop through all the rows in the data table,
		// displaying the LastName
		for (int intCounter = 0; intCounter <= dtbUser.DefaultView.Count - 1; intCounter++) {
			MessageBox.Show(dtbUser.DefaultView[intCounter]["LastName"].ToString());
		}
	}

	public void InstantiateDataRow() {
		DataTable dtbUser = new DataTable();
		DataRow drwUser;

		drwUser = dtbUser.NewRow();
	}

	// Listing 3B-22
	public void InstantiateDataColumn() {
		DataColumn dtcDefaultValues = new DataColumn();
		DataColumn dtcColumnName = new DataColumn("ColumnName");
		DataColumn dtcColumnNameAndDataType = new DataColumn("ColumnName", 
			Type.GetType("System.String"));
		DataColumn dtcColumnNameAndDataTypeAndExpression = new DataColumn("ColumnName", 
			Type.GetType("System.String"), "ColumnName + 'Extra Text'");
		DataColumn dtcColumnNameAndDataTypeAndExpressionAndMappingType = new 
			DataColumn("ColumnName", Type.GetType("System.Int32"), "ColumName + 10", 
			MappingType.Attribute);
	}

	// Listing 3B-23
	public void InstantiateDataRelation() {
		// Declare parent and child columns for use in relationship
		DataColumn dtcParentColumn = new DataColumn("ParentColumn");
		DataColumn dtcChildColumn = new DataColumn("ChildColumn");
		// Declare and initialize array of parent and child 
		// columns for use in relationship
		DataColumn[] arrdtcParentColumn = new DataColumn[2];
		DataColumn[] arrdtcChildColumn = new DataColumn[2];
		arrdtcParentColumn[0] = new DataColumn("ParentColumn1");
		arrdtcParentColumn[1] = new DataColumn("ParentColumn2");
		arrdtcChildColumn[0] = new DataColumn("ChildColumn1");
		arrdtcChildColumn[1] = new DataColumn("ChildColumn2");

		// This constructor will fail, unless you add the
		// specified parent and child columns to a table
		DataRelation dtrParentColumnAndChildColumn = 
			new DataRelation("RelationName", dtcParentColumn,
			dtcChildColumn);
		// This constructor will fail, unless you add the
		// specified parent and child columns to a table
		DataRelation dtrParentColumnAndChildColumnAndConstraints = 
			new DataRelation("RelationName", dtcParentColumn,
			dtcChildColumn, false);

		// This constructor will fail, unless you add the
		// specified arrays of parent and child columns to a table
		DataRelation dtrParentColumnsAndChildColumns = 
			new DataRelation("RelationName", arrdtcParentColumn, 
			arrdtcChildColumn, false);
		// This constructor will fail, unless you add the
		// specified arrays of parent and child columns to a table
		DataRelation dtrParentColumnsAndChildColumnsAndConstraints = 
			new DataRelation("RelationName", arrdtcParentColumn, 
			arrdtcChildColumn, false);

		// This constructor takes string values for all arguments
		// except for the last argument, Nested. This argument is 
		// used for indicating if this relation is used in connection
		// with hierarchical data, like an XML document
		DataRelation dtrStringsAndNested = 
			new DataRelation("RelationName", "ParentTableName",
			"ChildTableName", new string[1] {"PrimaryKeyColumn1"}, 
			new string[1] {"ForeignKeyColumn1"}, false);
	}

	// Listing 3B-24
	public void BuildUserManDatabase() {
		// Declare and instantiate data set
		DataSet dstUserMan = new DataSet("UserMan");
		// Declare and instantiate tables in data set
		DataTable dtbUser = new DataTable("tblUser");
		DataTable dtbRights = new DataTable("tblRights");
		DataTable dtbUserRights = new DataTable("tblUserRights");
		DataTable dtbLog = new DataTable("tblLog");
		// Declare table elements
		DataColumn dclUser, dclRights, dclUserRights, dclLog;
		DataColumn[] arrdclUserPrimaryKey, arrdclRightsPrimaryKey, 
			arrdclUserRightsPrimaryKey, arrdclLogPrimaryKey;
		// Declare table relations
		DataRelation dtrUser2Log, dtrUser2UserRights, dtrRights2UserRights;

		// Set up data set for saving to XML
		dstUserMan.Namespace = "UserMan";
		dstUserMan.Locale = new CultureInfo("En-US", true);
		dstUserMan.Prefix = "Development";

		// Create user table structure
		// Create Id column
		dclUser = new DataColumn("Id", Type.GetType("System.Int32"),"", 
			MappingType.Element);
		// Make the Id column an auto increment column, incrementing by 1 
		// every time a new row is added to the table, with a seed of 1
		dclUser.AutoIncrement = true;
		dclUser.AutoIncrementSeed = 1;
		dclUser.AutoIncrementStep = 1;
		// Disallow null values in column
		dclUser.AllowDBNull = false;
		// Add Id column to user table structure
		dtbUser.Columns.Add(dclUser);
		// Create single-column primary key
		arrdclUserPrimaryKey = new DataColumn[1];
		// Add Id column to PK array
		arrdclUserPrimaryKey[0] = dclUser;
		// Set primary key
		dtbUser.PrimaryKey = arrdclUserPrimaryKey;

		// Create ADName column
		dclUser = new DataColumn("ADName", Type.GetType("System.String"));
		dclUser.MaxLength = 100;
		// Add column to user table structure
		dtbUser.Columns.Add(dclUser);

		// Create ADSID column
      dclUser = new DataColumn("ADSID", Type.GetType("System.String"));
      dclUser.MaxLength = 50;
      // Add column to user table structure
		dtbUser.Columns.Add(dclUser);

		// Create FirstName column
		dclUser = new DataColumn("FirstName", Type.GetType("System.String"));
		dclUser.MaxLength = 50;
		// Add column to user table structure
		dtbUser.Columns.Add(dclUser);

		// Create LastName column
		dclUser = new DataColumn("LastName", Type.GetType("System.String"));
		dclUser.MaxLength = 50;
		// Add column to user table structure
		dtbUser.Columns.Add(dclUser);

		// Create LoginName column
		dclUser = new DataColumn("LoginName", Type.GetType("System.String"));
		// Disallow null values in column
		dclUser.AllowDBNull = false;
		// Disallow duplicate values in column
		dclUser.Unique = true;
		dclUser.MaxLength = 50;
		// Add column to user table structure
		dtbUser.Columns.Add(dclUser);

		// Create Password column
		dclUser = new DataColumn("Password", Type.GetType("System.String"));
		// Disallow null values in column
		dclUser.AllowDBNull = false;
		dclUser.MaxLength = 50;
		// Add column to user table structure
		dtbUser.Columns.Add(dclUser);

		// Add User table to dataset
		dstUserMan.Tables.Add(dtbUser);

		// Create Rights table structure
		// Create Id column
		dclRights = new DataColumn("Id", Type.GetType("System.Int32"),"", 
			MappingType.Element);
		// Make the Id column an auto increment column, incrementing by 1 
		// every time a new row is added to the table, with a seed of 1
		dclRights.AutoIncrement = true;
		dclRights.AutoIncrementSeed = 1;
		dclRights.AutoIncrementStep = 1;
		// Disallow null values in column
		dclRights.AllowDBNull = false;
		// Add Id column to Rights table structure
		dtbRights.Columns.Add(dclRights);
		// Create single-column primary key
		arrdclRightsPrimaryKey = new DataColumn[1];
		// Add Id column to PK array
		arrdclRightsPrimaryKey[0] = dclRights;
		// Set primary key
		dtbRights.PrimaryKey = arrdclRightsPrimaryKey;

		// Create Name column
		dclRights = new DataColumn("Name", Type.GetType("System.String"));
		dclUser.MaxLength = 50;
		// Add column to Rights table structure
		dtbRights.Columns.Add(dclRights);

		// Create Description column
		dclRights = new DataColumn("Description", Type.GetType("System.String"));
		dclUser.MaxLength = 255;
		// Add column to Rights table structure
		dtbRights.Columns.Add(dclRights);

		// Add Rights table to dataset
		dstUserMan.Tables.Add(dtbRights);

		// Create Log table structure
		// Create Id column
		dclLog = new DataColumn("Id", Type.GetType("System.Int32"),"", 
			MappingType.Element);
		// Make the Id column an auto increment column, incrementing by 1 
		// every time a new row is added to the table, with a seed of 1
		dclLog.AutoIncrement = true;
		dclLog.AutoIncrementSeed = 1;
		dclLog.AutoIncrementStep = 1;
		// Disallow null values in column
		dclLog.AllowDBNull = false;
		// Add Id column to Log table structure
		dtbLog.Columns.Add(dclLog);
		// Create single-column primary key
		arrdclLogPrimaryKey = new DataColumn[1];
		// Add Id column to PK array
		arrdclLogPrimaryKey[0] = dclLog;
		// Set primary key
		dtbLog.PrimaryKey = arrdclLogPrimaryKey;

		// Create Logged column
		dclLog = new DataColumn("Logged", Type.GetType("System.DateTime"));
		// Add column to Log table structure
		dtbLog.Columns.Add(dclLog);

		// Create Description column
		dclLog = new DataColumn("Description", Type.GetType("System.String"));
		dclUser.MaxLength = 255;
		// Add column to Log table structure
		dtbLog.Columns.Add(dclLog);

		// Create UserId column
		dclLog = new DataColumn("UserId", Type.GetType("System.Int32"),"", 
			MappingType.Element);
		// Disallow null values in column
		dclLog.AllowDBNull = false;
		// Add UserId column to Log table structure
		dtbLog.Columns.Add(dclLog);

		// Add Log table to dataset
		dstUserMan.Tables.Add(dtbLog);

		// Create UserRights table structure
		// Create UserId column
		dclUserRights = new DataColumn("UserId", Type.GetType("System.Int32"),"", 
			MappingType.Element);
		// Disallow null values in column
		dclUserRights.AllowDBNull = false;
		// Disallow duplicate values in column
		dclUserRights.Unique = true;
		// Add Id column to UserRights table structure
		dtbUserRights.Columns.Add(dclUserRights);

		// Create composite primary key
		arrdclUserRightsPrimaryKey = new DataColumn[2];
		// Add UserId column to PK array
		arrdclUserRightsPrimaryKey[0] = dclUserRights;
		
		// Create RightsId column
		dclUserRights = new DataColumn("RightsId", Type.GetType("System.Int32"),"", 
			MappingType.Element);
		// Disallow null values in column
		dclUserRights.AllowDBNull = false;
		// Disallow duplicate values in column
		dclUserRights.Unique = true;
		// Add RightsId column to UserRights table structure
		dtbUserRights.Columns.Add(dclUserRights);

		// Add RightsId column to PK array
		arrdclUserRightsPrimaryKey[1] = dclUserRights;
		// Set primary key
		dtbUserRights.PrimaryKey = arrdclUserRightsPrimaryKey;

		// Add UserRights table to dataset
		dstUserMan.Tables.Add(dtbUserRights);

		// Create table relations
		dtrUser2Log = new DataRelation("User2Log", "tblUser",
			"tblLog", new string[1] {"Id"}, 
			new string[1] {"UserId"}, false);
		dtrUser2UserRights = new DataRelation("User2UserRights", "tblUser",
			"tblUserRights", new string[1] {"I"}, 
			new string[1] {"UserId"}, false);
		dtrRights2UserRights = new DataRelation("Rights2UserRight", "tblRights",
			"tblUserRights", new string[1] {"Id"}, 
			new string[1] {"RightsId"}, false);
		
		// Write data set schema to XML file
		//dstUserMan.WriteXmlSchema("C:\\UserMan.xml");
	}

   // Listing 3B-25
   public void LockDataSourceRowsUsingTransactions() {
#if !MSAccess
      const string STR_SQL_USER_SELECT = "SELECT * FROM tblUser";

      OleDbConnection cnnLocked, cnnUnlocked;
      OleDbDataAdapter dadLocked, dadUnlocked;
      OleDbTransaction traUserMan;
      OleDbCommand cmdSelectUsers;
      DataSet dstLocked = new DataSet("Locked DataSet");
      DataSet dstUnlocked = new DataSet("Unlocked DataSet");
      
      // Instantiate and open the connections
      cnnLocked = new OleDbConnection(STR_CONNECTION_STRING);
      cnnLocked.Open();
      cnnUnlocked = new OleDbConnection(STR_CONNECTION_STRING);
      cnnUnlocked.Open();
      // Begin transaction
      traUserMan = cnnLocked.BeginTransaction(IsolationLevel.Serializable);
      // Set up slect command
      cmdSelectUsers = new OleDbCommand(STR_SQL_USER_SELECT, cnnLocked, traUserMan);

      // Instantiate and initialize data adapters
      dadLocked = new OleDbDataAdapter(STR_SQL_USER_SELECT, cnnLocked);
      dadLocked.SelectCommand = cmdSelectUsers;
      dadUnlocked = new OleDbDataAdapter(STR_SQL_USER_SELECT, cnnUnlocked);
      // Declare and instantiate command builders
      OleDbCommandBuilder cmbUser1 = new OleDbCommandBuilder(dadLocked);
      OleDbCommandBuilder cmbUser2 = new OleDbCommandBuilder(dadUnlocked);

      // Populate the data sets
      dadLocked.Fill(dstLocked, "tblUser");
      dadUnlocked.Fill(dstUnlocked, "tblUser");

      // Update an existing row in unlocked data set
      dstUnlocked.Tables["tblUser"].Rows[2]["FirstName"] = "FirstName";

      try {
         // Update the unlocked data source
         dadUnlocked.Update(dstUnlocked, "tblUser");
         // Commit transaction
         traUserMan.Commit();
      }
      catch (OleDbException objE) {
         // Roll back transaction
         traUserMan.Rollback();
         MessageBox.Show(objE.Message);
      }
      finally {
         // Close connections
         cnnLocked.Close();
         cnnUnlocked.Close();
      }
#endif
   }

   // Listing 3B-26
   public void TriggerConcurrencyViolation() {
      const string STR_SQL_USER_SELECT = "SELECT * FROM tblUser";

      OleDbConnection cnnUser1, cnnUser2;
      OleDbDataAdapter dadUser1, dadUser2;
      DataSet dstUser1 = new DataSet("User1 DataSet");
      DataSet dstUser2 = new DataSet("User2 DataSet");
      
      // Instantiate and open the connections
      cnnUser1 = new OleDbConnection(STR_CONNECTION_STRING);
      cnnUser1.Open();
      cnnUser2 = new OleDbConnection(STR_CONNECTION_STRING);
      cnnUser2.Open();

      // Instantiate and initialize data adapters
      dadUser1 = new OleDbDataAdapter(STR_SQL_USER_SELECT, cnnUser1);
      dadUser2 = new OleDbDataAdapter(STR_SQL_USER_SELECT, cnnUser2);
      OleDbCommandBuilder cmbUser1 = new OleDbCommandBuilder(dadUser1);
      OleDbCommandBuilder cmbUser2 = new OleDbCommandBuilder(dadUser2);

      // Populate the data sets
      dadUser1.Fill(dstUser1, "tblUser");
      dadUser2.Fill(dstUser2, "tblUser");

      // Update an existing row in first data set
      dstUser1.Tables["tblUser"].Rows[2]["FirstName"] = "FirstName";
      // Update the data source with changes to the first data set
      dadUser1.Update(dstUser1, "tblUser");
      // Update an existing row in second data set
      dstUser2.Tables["tblUser"].Rows[2]["FirstName"] = "FName";

      try {
         // Update the data source with changes to the second data set
         dadUser2.Update(dstUser2, "tblUser");
      }
      catch (DBConcurrencyException objE) {
         MessageBox.Show(objE.Message);
      }
      finally {
         // Close connections
         cnnUser1.Close();
         cnnUser2.Close();
      }
   }

   // Listing 3B-27
   public void IgnoreConcurrencyViolations() {
      const string STR_SQL_USER_SELECT = "SELECT * FROM tblUser";
      const string STR_SQL_USER_UPDATE = "UPDATE tblUser SET ADName=@ADName, ADSID=@ADSID, FirstName=" +
               "@FirstName, LastName=@LastName, LoginName=@LoginName, Password=@Password WHERE Id=@Id";

      OleDbCommand cmmUserUpdate1, cmmUserUpdate2;
      OleDbParameter prmSQLUpdate;

      OleDbConnection cnnUser1;
      OleDbDataAdapter dadUser1, dadUser2;
      DataSet dstUser1 = new DataSet("User DataSet1");
      DataSet dstUser2 = new DataSet("User DataSet2");
      
      // Instantiate and open the connection
      cnnUser1 = new OleDbConnection(STR_CONNECTION_STRING);
      cnnUser1.Open();

      // Instantiate the update commands
      cmmUserUpdate1 = new OleDbCommand(STR_SQL_USER_UPDATE, cnnUser1);
      cmmUserUpdate2 = new OleDbCommand(STR_SQL_USER_UPDATE, cnnUser1);

      // Instantiate and initialize data adapters
      dadUser1 = new OleDbDataAdapter(STR_SQL_USER_SELECT, cnnUser1);
      dadUser2 = new OleDbDataAdapter(STR_SQL_USER_SELECT, cnnUser1);

      // Set data adapters update command property
      dadUser1.UpdateCommand = cmmUserUpdate1;
      dadUser2.UpdateCommand = cmmUserUpdate2;

      // Add Update command parameters
      cmmUserUpdate1.Parameters.Add("@ADName", OleDbType.VarChar, 100, "ADName");
      cmmUserUpdate1.Parameters.Add("@ADSID", OleDbType.VarChar, 50, "ADSID");
      cmmUserUpdate1.Parameters.Add("@FirstName", OleDbType.VarChar, 50, "FirstName");
      cmmUserUpdate1.Parameters.Add("@LastName", OleDbType.VarChar, 50, "LastName");
      cmmUserUpdate1.Parameters.Add("@LoginName", OleDbType.VarChar, 50, "LoginName");
      cmmUserUpdate1.Parameters.Add("@Password", OleDbType.VarChar, 50, "Password");

      prmSQLUpdate = dadUser1.UpdateCommand.Parameters.Add("@Id", OleDbType.Integer, 4, "Id");
      prmSQLUpdate.Direction = ParameterDirection.Input;
      prmSQLUpdate.SourceVersion = DataRowVersion.Original;

      cmmUserUpdate2.Parameters.Add("@ADName", OleDbType.VarChar, 100, "ADName");
      cmmUserUpdate2.Parameters.Add("@ADSID", OleDbType.VarChar, 50, "ADSID");
      cmmUserUpdate2.Parameters.Add("@FirstName", OleDbType.VarChar, 50, "FirstName");
      cmmUserUpdate2.Parameters.Add("@LastName", OleDbType.VarChar, 50, "LastName");
      cmmUserUpdate2.Parameters.Add("@LoginName", OleDbType.VarChar, 50, "LoginName");
      cmmUserUpdate2.Parameters.Add("@Password", OleDbType.VarChar, 50, "Password");

      prmSQLUpdate = dadUser2.UpdateCommand.Parameters.Add("@Id", OleDbType.Integer, 4, "Id");
      prmSQLUpdate.Direction = ParameterDirection.Input;
      prmSQLUpdate.SourceVersion = DataRowVersion.Original;

      // Populate the data sets
      dadUser1.Fill(dstUser1, "tblUser");
      dadUser2.Fill(dstUser2, "tblUser");

      // Update an existing row in first data set
      dstUser1.Tables["tblUser"].Rows[2]["FirstName"] = "FirstName";
      // Update the data source with changes to the first data set
      dadUser1.Update(dstUser1, "tblUser");
      // Update an existing row in second data set
      dstUser2.Tables["tblUser"].Rows[2]["FirstName"] = "FName";
      // Update the data source with changes to the second data set
      dadUser2.Update(dstUser2, "tblUser");
   }

   // Listing 3B-28
   public void HandleConcurrencyViolations() {
      const string STR_SQL_USER_SELECT = "SELECT * FROM tblUser";

      OleDbConnection cnnUser1;
      OleDbDataAdapter dadUser1, dadUser2;
      DataSet dstUser1 = new DataSet("User DataSet1");
      DataSet dstUser2 = new DataSet("User DataSet2");
      
      // Instantiate and open the connection
      cnnUser1 = new OleDbConnection(STR_CONNECTION_STRING);
      cnnUser1.Open();

      // Instantiate and initialize data adapters
      dadUser1 = new OleDbDataAdapter(STR_SQL_USER_SELECT, cnnUser1);
      dadUser2 = new OleDbDataAdapter(STR_SQL_USER_SELECT, cnnUser1);
      // Declare and instantiate command builder
      OleDbCommandBuilder cmbUser1 = new OleDbCommandBuilder(dadUser1);
      OleDbCommandBuilder cmbUser2 = new OleDbCommandBuilder(dadUser2);

      // Populate the data sets
      dadUser1.Fill(dstUser1, "tblUser");
      dadUser2.Fill(dstUser2, "tblUser");

      // Update an existing row in first data set
      dstUser1.Tables["tblUser"].Rows[2]["FirstName"] = "FirstName";
      // Update the data source with changes to the first data set
      dadUser1.Update(dstUser1, "tblUser");
      // Update an existing row in second data set
      dstUser2.Tables["tblUser"].Rows[2]["FirstName"] = "FName";

      try {
         // Update the data source with changes to the second data set
         dadUser2.Update(dstUser2, "tblUser");
      }
      catch (DBConcurrencyException objE) {
         DialogResult objResult;
         string strCurrentDataSourceFirstName;
         // Instantiate command to find the current data source value
         OleDbCommand cmdCurrentDataSourceValue = 
            new OleDbCommand("SELECT FirstName FROM tblUser WHERE Id=" + 
            objE.Row["Id", DataRowVersion.Original].ToString(), cnnUser1);

         // Find current value in data source
         strCurrentDataSourceFirstName = (string) cmdCurrentDataSourceValue.ExecuteScalar();

         // Prompt the user about which value to save
         objResult = MessageBox.Show("A concurrency violation exception was thrown when updating the source." +
            "These are the values for the column in error:\n\n" + 
            "Original DataSet Value: " + objE.Row["FirstName", DataRowVersion.Original].ToString()  + "\n"  + 
            "Current Data Source Value: " + strCurrentDataSourceFirstName  + "\n"  + 
            "Current DataSet Value: " + objE.Row["FirstName", DataRowVersion.Current].ToString()  + "\n"  + 
            "Do you want to overwrite the current data source value?",  "Concurrency Violation", 
            MessageBoxButtons.YesNo, MessageBoxIcon.Question);
         // Does the user want to overwrite the current data source value?
         if (objResult == DialogResult.Yes) {
            // Merge the content of the data source with the dataset in error
            dstUser2.Merge(dstUser1, true);
            dadUser2.Update(dstUser2, "tblUser");
         }
      }
      finally {
         // Close connection
         cnnUser1.Close();
      }
   }
}