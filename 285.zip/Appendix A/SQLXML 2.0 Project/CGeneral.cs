using System;
using System.Data;
using System.IO;
using System.Xml;
using System.Windows.Forms;
using Microsoft.Data.SqlXml;

/// <summary>
/// Summary description for CGeneral.
/// </summary>
public class CGeneral {
   // Listing A-6
   private const string PR_STR_CONNECTION_STRING = 
      "Provider=SQLOLEDB;Data Source=USERMANPC;User Id=UserMan;" +
      "Password=userman;Initial Catalog=UserMan";
   
   public CGeneral() {
      //
      // TODO: Add constructor logic here
      //
   }

   public void InstantiateSqlXmlAdapter() {
      // Declare and instantiate command
      SqlXmlCommand cmdUser = 
         new SqlXmlCommand(PR_STR_CONNECTION_STRING);

      // Declare and instantiate adapters
      SqlXmlAdapter dadUserMan1 = 
         new SqlXmlAdapter(cmdUser);
      SqlXmlAdapter dadUserMan2 = 
         new SqlXmlAdapter("SELECT * FROM tblUser FOR XML AUTO", 
         SqlXmlCommandType.Sql, PR_STR_CONNECTION_STRING);
   }

   // Listing A-7
   public void PopulateDataSetUsingSql() {
      // Declare SELECT statement
      string strSQL = "SELECT * FROM tblUser FOR XML AUTO, ELEMENTS";
      // Declare and instantiate DataSet
      DataSet dstUserMan = new DataSet("UserMan");
      // Declare, instantiate and initialize command
      SqlXmlCommand cmdUser = 
         new SqlXmlCommand(PR_STR_CONNECTION_STRING);
      cmdUser.CommandText = strSQL;

      // Declare and instantiate adapters
      SqlXmlAdapter dadUserMan1 = 
         new SqlXmlAdapter(cmdUser);
      SqlXmlAdapter dadUserMan2 = 
         new SqlXmlAdapter(strSQL, SqlXmlCommandType.Sql, 
         PR_STR_CONNECTION_STRING);

      // Fill DataSet. Uncomment one of the lines below 
      // and comment out the other to test either
      dadUserMan1.Fill(dstUserMan);
      //dadUserMan2.Fill(dstUserMan);
   }

   // Listing A-8
   public void PopulateDataSetUsingSql2() {
      // Declare SELECT statement
      string strSQL = "SELECT * FROM tblUser FOR XML AUTO";
      // Declare and instantiate DataSet
      DataSet dstUserMan = new DataSet("UserMan");
      // Declare, instantiate and initialize command
      SqlXmlCommand cmdUser = 
         new SqlXmlCommand(PR_STR_CONNECTION_STRING);
      cmdUser.CommandText = strSQL;
      // You need to set the RootTag property, otherwise
      // otherwise there is no root tag and an exception
      // is thrown
      cmdUser.RootTag = "UserMan";

      // Declare and instantiate adapter
      SqlXmlAdapter dadUserMan1 = 
         new SqlXmlAdapter(cmdUser);

      // Fill DataSet
      dadUserMan1.Fill(dstUserMan);
   }

   // Listing A-9
   public void PopulateDataSetUsingStringTemplate() {
      // Declare template
      string strTemplate = "<ROOT xmlns:sql='urn:schemas-microsoft-com:xml-sql'>" +
         "<sql:query>" + "SELECT * FROM tblUser FOR XML AUTO" + "</sql:query>" +
         "</ROOT>";
      // Declare and instantiate DataSet
      DataSet dstUserMan = new DataSet("UserMan");

      // Declare and instantiate adapter
      SqlXmlAdapter dadUserMan = 
         new SqlXmlAdapter(strTemplate, SqlXmlCommandType.Template, 
         PR_STR_CONNECTION_STRING);

      // Fill DataSet
      dadUserMan.Fill(dstUserMan);
      // Write xml document to disk (Listing A-10)
      //dstUserMan.WriteXml("C:\\ReturnedDocument.xml");
      // Check how many tables are in the DataSet
      //MessageBox.Show(dstUserMan.Tables.Count.ToString());
   }

   // Listing A-11
   public void PopulateDataSetUsingTemplateFile() {
      // Declare template file
      string strTemplateFile = "C:\\AllUsers.xml";
     // Declare output file
     string strOutputFile = "C:\\ReturnedDocument.xml";
      // Declare and instantiate DataSet
      DataSet dstUserMan = new DataSet("UserMan");

      // Declare and instantiate adapter
      SqlXmlAdapter dadUserMan = 
         new SqlXmlAdapter(strTemplateFile, SqlXmlCommandType.TemplateFile, 
         PR_STR_CONNECTION_STRING);

      // Fill DataSet
      dadUserMan.Fill(dstUserMan);
      // Write xml document to disk
      dstUserMan.WriteXml(strOutputFile);
   }
 
   // Listing A-12
   public void UpdateDataSourceFromDataSet() {
      // Declare template file
      string strTemplateFile = "C:\\AllUsers.xml";
      // Declare and instantiate DataSet
      DataSet dstUserMan = new DataSet("UserMan");

      // Declare and instantiate adapter
      SqlXmlAdapter dadUserMan = 
         new SqlXmlAdapter(strTemplateFile, SqlXmlCommandType.TemplateFile, 
         PR_STR_CONNECTION_STRING);

      // Fill DataSet
      dadUserMan.Fill(dstUserMan);
      // Update DataSet
      dstUserMan.Tables["tblUser"].Rows[0]["FirstName"] = "Johnny";

      if (dstUserMan.HasChanges()) {
         // Update data source
         dadUserMan.Update(dstUserMan);
      }
   }

   public void InstantiateSqlXmlCommand() {
      SqlXmlCommand cmdUser = new SqlXmlCommand(PR_STR_CONNECTION_STRING);
   }

   // Listing A-13
   public void PopulateXmlReader() {
      // Declare XmlReader
      XmlReader xrdUser;
      // Declare SELECT statement
      string strSQL = "SELECT * FROM tblUser FOR XML AUTO";
      // Declare, instantiate and initialize command
      SqlXmlCommand cmdUser = 
         new SqlXmlCommand(PR_STR_CONNECTION_STRING);
      cmdUser.CommandText = strSQL;
      // Retrieve result set in Xml Reader
      xrdUser = cmdUser.ExecuteXmlReader();
   }

   // Listing A-14
   public void SaveCommandResultToStream() {
      Stream stmUser;
      StreamWriter smwUser;
      // Declare SELECT statement
      string strSQL = "SELECT * FROM tblUser FOR XML AUTO";
      // Declare, instantiate and initialize command
      SqlXmlCommand cmdUser = 
         new SqlXmlCommand(PR_STR_CONNECTION_STRING);
      cmdUser.CommandText = strSQL;
      // You need to set the RootTag property, otherwise
      // otherwise there is no root tag
      cmdUser.RootTag = "UserMan";

      // Execute command and save result set in stream
      stmUser = cmdUser.ExecuteStream();
      // Read content of stream into stream reader
      StreamReader smrUser = new StreamReader(stmUser);

      // Create new file to hold the result stream
      smwUser = new StreamWriter("C:\\Users.xml");
      // Write the result set to disk
      smwUser.Write(smrUser.ReadToEnd());
      // Flush and close the stream writer
      smwUser.Flush();
      smwUser.Close();
   }

   // Listing A-15
   public void AppendCommandResultToStream() {
      Stream stmUser;
      StreamWriter smwUser;
      // Declare SELECT statement
      string strSQL = "SELECT * FROM tblUser FOR XML AUTO";
      // Declare, instantiate and initialize command
      SqlXmlCommand cmdUser = 
         new SqlXmlCommand(PR_STR_CONNECTION_STRING);
      cmdUser.CommandText = strSQL;
      // You need to set the RootTag property, otherwise
      // there is no root element to form a valid XML
      // document
      cmdUser.RootTag = "UserMan";

      // Execute command and save result set in stream
      stmUser = cmdUser.ExecuteStream();
      // Append new result set to existing stream
      cmdUser.ExecuteToStream(stmUser);
      // Read content of stream into stream reader
      StreamReader smrUser = new StreamReader(stmUser);

      // Create new file to hold the result stream
      smwUser = new StreamWriter("C:\\Users.xml");
      // Set the stream position to 0
      stmUser.Position = 0;
      // Write the result set to disk
      smwUser.Write(smrUser.ReadToEnd());
      // Flush and close the stream writer
      smwUser.Flush();
      smwUser.Close();
   }

   // Listing A-16
   public void ExecuteNamedParameterCommand() {
      Stream stmUser;
      StreamWriter smwUser;
      SqlXmlParameter prmLastName;
      // Declare SELECT statement
      string strSQL = "SELECT * FROM tblUser WHERE LastName=LastName FOR XML AUTO";
      // Declare, instantiate and initialize command
      SqlXmlCommand cmdUser = 
         new SqlXmlCommand(PR_STR_CONNECTION_STRING);
      cmdUser.CommandText = strSQL;
      // You need to set the RootTag property, otherwise
      // there is no root element to form a valid XML
      // document
      cmdUser.RootTag = "UserMan";
      // Add named parameter and set properties
      prmLastName = cmdUser.CreateParameter();
      prmLastName.Name = "LastName";
      prmLastName.Value = "Doe";
      // Execute command and save result set in stream
      stmUser = cmdUser.ExecuteStream();
      // Read content of stream into stream reader
      StreamReader smrUser = new StreamReader(stmUser);

      // Create new file to hold the result stream
      smwUser = new StreamWriter("C:\\Users.xml");
      // Write the result set to disk
      smwUser.Write(smrUser.ReadToEnd());
      // Flush and close the stream writer
      smwUser.Flush();
      smwUser.Close();
   }

   // Listing A-17
   public void ExecutePositionalParameterCommand() {
      Stream stmUser;
      StreamWriter smwUser;
      SqlXmlParameter prmLastName, prmFirstName;
      // Declare SELECT statement
      string strSQL = "SELECT * FROM tblUser WHERE LastName=? " +
         "AND FirstName=? FOR XML AUTO";
      // Declare, instantiate and initialize command
      SqlXmlCommand cmdUser = 
         new SqlXmlCommand(PR_STR_CONNECTION_STRING);
      cmdUser.CommandText = strSQL;
      // You need to set the RootTag property, otherwise
      // there is no root element to form a valid XML
      // document
      cmdUser.RootTag = "UserMan";
      // Add positional parameters and set value properties
      prmLastName = cmdUser.CreateParameter();
      prmLastName.Value = "Doe";
      prmFirstName = cmdUser.CreateParameter();
      prmFirstName.Value = "John";
      // Execute command and save result set in stream
      stmUser = cmdUser.ExecuteStream();
      // Read content of stream into stream reader
      StreamReader smrUser = new StreamReader(stmUser);

      // Create new file to hold the result stream
      smwUser = new StreamWriter("C:\\Users.xml");
      // Write the result set to disk
      smwUser.Write(smrUser.ReadToEnd());
      // Flush and close the stream writer
      smwUser.Flush();
      smwUser.Close();
   }

   // Listing A-18
   public void ExecuteXPathQuery() {
      Stream stmUser;
      StreamWriter smwUser;
      // Declare, instantiate and initialize command
      SqlXmlCommand cmdUser = 
         new SqlXmlCommand(PR_STR_CONNECTION_STRING);
      cmdUser.CommandText = "tblUser/@LoginName";
      cmdUser.CommandType = SqlXmlCommandType.XPath;
      // You need to set the RootTag property, otherwise
      // there is no root element to form a valid XML
      // document
      cmdUser.RootTag = "UserMan";
      // Execute command and save result set in stream
      stmUser = cmdUser.ExecuteStream();
      // Read content of stream into stream reader
      StreamReader smrUser = new StreamReader(stmUser);

      // Create new file to hold the result stream
      smwUser = new StreamWriter("C:\\Users.xml");
      // Write the result set to disk
      smwUser.Write(smrUser.ReadToEnd());
      // Flush and close the stream writer
      smwUser.Flush();
      smwUser.Close();
   }

   // Listing A-20
   public void ExecuteXPathQueryUsingMappingSchema() {
      Stream stmUser;
      StreamWriter smwUser;
      // Declare, instantiate and initialize command
      SqlXmlCommand cmdUser = 
         new SqlXmlCommand(PR_STR_CONNECTION_STRING);
      cmdUser.CommandText = "Users";
      cmdUser.CommandType = SqlXmlCommandType.XPath;
      cmdUser.SchemaPath = "C:\\Users.xsd";
      // You need to set the RootTag property, otherwise
      // there is no root element to form a valid XML
      // document
      cmdUser.RootTag = "UserMan";
      // Execute command and save result set in stream
      stmUser = cmdUser.ExecuteStream();
      // Read content of stream into stream reader
      StreamReader smrUser = new StreamReader(stmUser);

      // Create new file to hold the result stream
      smwUser = new StreamWriter("C:\\Users.xml");
      // Write the result set to disk
      smwUser.Write(smrUser.ReadToEnd());
      // Flush and close the stream writer
      smwUser.Flush();
      smwUser.Close();
   }

   // Listing A-21
   public void ExecuteNonQuery() {
      // Declare, instantiate and initialize command
      SqlXmlCommand cmdUser = 
         new SqlXmlCommand(PR_STR_CONNECTION_STRING);
      cmdUser.CommandText = "UPDATE tblUser " +
         "SET FirstName='FirstName' WHERE FirstName IS NULL";
      // Execute non query
      cmdUser.ExecuteNonQuery();
   }

   // Listing A-23
   public void ExecuteNonQueryStringTemplate() {
      // Declare, instantiate and initialize command
      SqlXmlCommand cmdUser = 
         new SqlXmlCommand(PR_STR_CONNECTION_STRING);
      cmdUser.CommandText = "<ROOT xmlns:sql='urn:schemas-microsoft-com:xml-sql'>" +
         "<sql:query>" +
         "UPDATE tblUser " +
         "SET FirstName='FirstName' WHERE FirstName IS NULL" +
         "</sql:query>" +
         "</ROOT>";
      cmdUser.CommandType = SqlXmlCommandType.Template;
      // Execute non query
      cmdUser.ExecuteNonQuery();
   }

   // Listing A-24
   public void ExecuteNonQueryTemplate() {
      // Declare, instantiate and initialize command
      SqlXmlCommand cmdUser = 
         new SqlXmlCommand(PR_STR_CONNECTION_STRING);
      cmdUser.CommandText = "C:\\UpdateUsers.xml";
      cmdUser.CommandType = SqlXmlCommandType.TemplateFile;
      // Execute non query
      cmdUser.ExecuteNonQuery();
   }

   // Listing A-25
   public void ExecuteDiffGram() {
      // Declare template file
      string strTemplate = "C:\\AllUsers.xml";
      // Declare and instantiate DataSet
      DataSet dstUserMan = new DataSet("UserMan");

      // Declare and instantiate adapter
      SqlXmlAdapter dadUserMan = 
         new SqlXmlAdapter(strTemplate, SqlXmlCommandType.TemplateFile, 
         PR_STR_CONNECTION_STRING);

      // Fill DataSet
      dadUserMan.Fill(dstUserMan);
      // Update DataSet
      dstUserMan.Tables["tblUser"].Rows[0]["FirstName"] = "Johnny"; // Update
      dstUserMan.Tables["tblUser"].Rows[3].Delete();                // Delete
      dstUserMan.Tables["tblUser"].Rows.Add(new object[5] {null, 
         null, null, "NewLogin", "password"});                      // Insert
      // Save dataset as diffgram      
      dstUserMan.WriteXml("C:\\Users-DiffGram.xml", XmlWriteMode.DiffGram);

      // Declare, instantiate and initialize command
      SqlXmlCommand cmdUser = 
         new SqlXmlCommand(PR_STR_CONNECTION_STRING);
      cmdUser.CommandText = "C:\\Users-DiffGram.xml";
      cmdUser.CommandType = SqlXmlCommandType.TemplateFile;
      // Execute diffgram
      cmdUser.ExecuteNonQuery();
   }
}