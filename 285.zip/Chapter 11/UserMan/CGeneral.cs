using System;

namespace UserMan {
	/// <summary>
	/// Summary description for CGeneral
	/// </summary>
	public class CGeneral {
      // This is the admin User object for administrating other users
      public static CUser objAdminUser = new CUser();
      // This object holds the details for the user being "administrated"
      public static CUser objUser;
      // Is the user logged on?
      public static bool LoggedOn = false;
                        
      public CGeneral() {
			//
			// TODO: Add constructor logic here
			//
		}
	}
}