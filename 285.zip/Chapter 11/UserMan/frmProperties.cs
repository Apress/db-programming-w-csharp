using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace UserMan
{
	/// <summary>
	/// Summary description for frmProperties.
	/// </summary>
   public class frmProperties : System.Windows.Forms.Form {
      internal System.Windows.Forms.TextBox txtLastName;
      internal System.Windows.Forms.Label lblLastName;
      internal System.Windows.Forms.TextBox txtFirstName;
      internal System.Windows.Forms.Label lblFirstName;
      internal System.Windows.Forms.TextBox txtADName;
      internal System.Windows.Forms.Label lblADName;
      internal System.Windows.Forms.TextBox txtId;
      internal System.Windows.Forms.Label lblId;
      internal System.Windows.Forms.Label lblPassword;
      internal System.Windows.Forms.Label lblUserId;
      internal System.Windows.Forms.TextBox txtPassword;
      internal System.Windows.Forms.TextBox txtLoginName;
      internal System.Windows.Forms.ContextMenu mnuProperties;
      internal System.Windows.Forms.MenuItem mnuUpdate;
      internal System.Windows.Forms.TextBox txtADSID;
      internal System.Windows.Forms.Label lblADSID;
                
      private bool prblnAdmin;
      private CUser probjUser;
      private bool blnDirty = false;
      private System.Windows.Forms.MenuItem mnuAdmin;
      private System.Windows.Forms.MenuItem mnuAdminProperties;
      private System.Windows.Forms.MenuItem mnuAdminPropertiesUpdate;
      private System.Windows.Forms.MainMenu mnuMain;

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.Container components = null;

      public frmProperties(bool blnAdmin) {
         //
         // Required for Windows Form Designer support
         //
         InitializeComponent();

         prblnAdmin = blnAdmin;

         // Is this the admin user?
         if (prblnAdmin) {
            this.Text = "Admin Properties";
            probjUser = CGeneral.objAdminUser;
         }
         else {
            probjUser = new CUser();
         }

         prDisplayUserProperties();
      }

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      protected override void Dispose( bool disposing ) {
         if( disposing ) {
            if(components != null) {
               components.Dispose();
            }
         }
         base.Dispose( disposing );
      }

		#region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent() {
         this.txtLastName = new System.Windows.Forms.TextBox();
         this.lblLastName = new System.Windows.Forms.Label();
         this.txtFirstName = new System.Windows.Forms.TextBox();
         this.lblFirstName = new System.Windows.Forms.Label();
         this.txtADName = new System.Windows.Forms.TextBox();
         this.lblADName = new System.Windows.Forms.Label();
         this.txtId = new System.Windows.Forms.TextBox();
         this.lblId = new System.Windows.Forms.Label();
         this.lblPassword = new System.Windows.Forms.Label();
         this.lblUserId = new System.Windows.Forms.Label();
         this.txtPassword = new System.Windows.Forms.TextBox();
         this.txtLoginName = new System.Windows.Forms.TextBox();
         this.mnuProperties = new System.Windows.Forms.ContextMenu();
         this.mnuUpdate = new System.Windows.Forms.MenuItem();
         this.txtADSID = new System.Windows.Forms.TextBox();
         this.lblADSID = new System.Windows.Forms.Label();
         this.mnuMain = new System.Windows.Forms.MainMenu();
         this.mnuAdmin = new System.Windows.Forms.MenuItem();
         this.mnuAdminProperties = new System.Windows.Forms.MenuItem();
         this.mnuAdminPropertiesUpdate = new System.Windows.Forms.MenuItem();
         this.SuspendLayout();
         // 
         // txtLastName
         // 
         this.txtLastName.Location = new System.Drawing.Point(310, 72);
         this.txtLastName.MaxLength = 50;
         this.txtLastName.Name = "txtLastName";
         this.txtLastName.Size = new System.Drawing.Size(165, 20);
         this.txtLastName.TabIndex = 23;
         this.txtLastName.Text = "txtLastName";
         // 
         // lblLastName
         // 
         this.lblLastName.AutoSize = true;
         this.lblLastName.Location = new System.Drawing.Point(246, 76);
         this.lblLastName.Name = "lblLastName";
         this.lblLastName.Size = new System.Drawing.Size(62, 13);
         this.lblLastName.TabIndex = 22;
         this.lblLastName.Text = "&Last Name:";
         // 
         // txtFirstName
         // 
         this.txtFirstName.Location = new System.Drawing.Point(72, 72);
         this.txtFirstName.Name = "txtFirstName";
         this.txtFirstName.Size = new System.Drawing.Size(165, 20);
         this.txtFirstName.TabIndex = 21;
         this.txtFirstName.Text = "txtFirstName";
         // 
         // lblFirstName
         // 
         this.lblFirstName.AutoSize = true;
         this.lblFirstName.Location = new System.Drawing.Point(8, 76);
         this.lblFirstName.Name = "lblFirstName";
         this.lblFirstName.Size = new System.Drawing.Size(63, 13);
         this.lblFirstName.TabIndex = 20;
         this.lblFirstName.Text = "&First Name:";
         // 
         // txtADName
         // 
         this.txtADName.Location = new System.Drawing.Point(72, 28);
         this.txtADName.Name = "txtADName";
         this.txtADName.ReadOnly = true;
         this.txtADName.Size = new System.Drawing.Size(165, 20);
         this.txtADName.TabIndex = 15;
         this.txtADName.Text = "txtADName";
         // 
         // lblADName
         // 
         this.lblADName.AutoSize = true;
         this.lblADName.Location = new System.Drawing.Point(8, 32);
         this.lblADName.Name = "lblADName";
         this.lblADName.Size = new System.Drawing.Size(56, 13);
         this.lblADName.TabIndex = 14;
         this.lblADName.Text = "&AD Name:";
         // 
         // txtId
         // 
         this.txtId.Location = new System.Drawing.Point(72, 6);
         this.txtId.Name = "txtId";
         this.txtId.ReadOnly = true;
         this.txtId.Size = new System.Drawing.Size(165, 20);
         this.txtId.TabIndex = 13;
         this.txtId.Text = "txtId";
         // 
         // lblId
         // 
         this.lblId.AutoSize = true;
         this.lblId.Location = new System.Drawing.Point(8, 10);
         this.lblId.Name = "lblId";
         this.lblId.Size = new System.Drawing.Size(17, 13);
         this.lblId.TabIndex = 12;
         this.lblId.Text = "Id:";
         // 
         // lblPassword
         // 
         this.lblPassword.AutoSize = true;
         this.lblPassword.Location = new System.Drawing.Point(246, 54);
         this.lblPassword.Name = "lblPassword";
         this.lblPassword.Size = new System.Drawing.Size(57, 13);
         this.lblPassword.TabIndex = 18;
         this.lblPassword.Text = "&Password:";
         // 
         // lblUserId
         // 
         this.lblUserId.AutoSize = true;
         this.lblUserId.Location = new System.Drawing.Point(8, 54);
         this.lblUserId.Name = "lblUserId";
         this.lblUserId.Size = new System.Drawing.Size(44, 13);
         this.lblUserId.TabIndex = 16;
         this.lblUserId.Text = "&User Id:";
         // 
         // txtPassword
         // 
         this.txtPassword.Location = new System.Drawing.Point(310, 50);
         this.txtPassword.MaxLength = 50;
         this.txtPassword.Name = "txtPassword";
         this.txtPassword.Size = new System.Drawing.Size(165, 20);
         this.txtPassword.TabIndex = 19;
         this.txtPassword.Text = "txtPassword";
         // 
         // txtLoginName
         // 
         this.txtLoginName.Location = new System.Drawing.Point(72, 50);
         this.txtLoginName.Name = "txtLoginName";
         this.txtLoginName.Size = new System.Drawing.Size(165, 20);
         this.txtLoginName.TabIndex = 17;
         this.txtLoginName.Text = "txtLoginName";
         // 
         // mnuProperties
         // 
         this.mnuProperties.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                      this.mnuUpdate});
         // 
         // mnuUpdate
         // 
         this.mnuUpdate.Index = 0;
         this.mnuUpdate.Text = "&Update";
         this.mnuUpdate.Click += new System.EventHandler(this.mnuUpdate_Click);
         // 
         // txtADSID
         // 
         this.txtADSID.Location = new System.Drawing.Point(310, 28);
         this.txtADSID.Name = "txtADSID";
         this.txtADSID.ReadOnly = true;
         this.txtADSID.Size = new System.Drawing.Size(165, 20);
         this.txtADSID.TabIndex = 25;
         this.txtADSID.Text = "txtADSID";
         // 
         // lblADSID
         // 
         this.lblADSID.AutoSize = true;
         this.lblADSID.Location = new System.Drawing.Point(246, 32);
         this.lblADSID.Name = "lblADSID";
         this.lblADSID.Size = new System.Drawing.Size(45, 13);
         this.lblADSID.TabIndex = 24;
         this.lblADSID.Text = "AD &SID:";
         // 
         // mnuMain
         // 
         this.mnuMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                this.mnuAdmin});
         // 
         // mnuAdmin
         // 
         this.mnuAdmin.Index = 0;
         this.mnuAdmin.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                 this.mnuAdminProperties});
         this.mnuAdmin.MergeType = System.Windows.Forms.MenuMerge.MergeItems;
         this.mnuAdmin.Text = "&Admin";
         // 
         // mnuAdminProperties
         // 
         this.mnuAdminProperties.Index = 0;
         this.mnuAdminProperties.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                           this.mnuAdminPropertiesUpdate});
         this.mnuAdminProperties.MergeType = System.Windows.Forms.MenuMerge.MergeItems;
         this.mnuAdminProperties.Text = "&Properties...";
         // 
         // mnuAdminPropertiesUpdate
         // 
         this.mnuAdminPropertiesUpdate.Index = 0;
         this.mnuAdminPropertiesUpdate.MergeType = System.Windows.Forms.MenuMerge.MergeItems;
         this.mnuAdminPropertiesUpdate.Text = "&Update";
         // 
         // frmProperties
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(486, 100);
         this.ContextMenu = this.mnuProperties;
         this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                      this.txtADSID,
                                                                      this.lblADSID,
                                                                      this.lblLastName,
                                                                      this.lblFirstName,
                                                                      this.lblADName,
                                                                      this.lblId,
                                                                      this.lblPassword,
                                                                      this.lblUserId,
                                                                      this.txtLastName,
                                                                      this.txtFirstName,
                                                                      this.txtADName,
                                                                      this.txtId,
                                                                      this.txtPassword,
                                                                      this.txtLoginName});
         this.MaximizeBox = false;
         this.Menu = this.mnuMain;
         this.MinimizeBox = false;
         this.Name = "frmProperties";
         this.ShowInTaskbar = false;
         this.Text = "Properties";
         this.Disposed += new System.EventHandler(this.frmProperties_Disposed);
         this.Closing += new System.ComponentModel.CancelEventHandler(this.frmProperties_Closing);
         this.ResumeLayout(false);

      }
		#endregion

      private void frmProperties_Closing(object sender, System.ComponentModel.CancelEventArgs e) {
         if (blnDirty) {
            MessageBox.Show(this, "The properties has been changed. Do you want to save the changes?", 
               "Save Changes", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
         }
      }

      private void frmProperties_Disposed(object sender, System.EventArgs e) {
      }

      private void mnuUpdate_Click(object sender, System.EventArgs e) {
		   prUpdateUserProperties();
		   probjUser.UpdateDataSource();
      }

	   private void prDisplayUserProperties() {
		   txtId.Text = probjUser.Id.ToString();
		   txtADName.Text = probjUser.ADName;
         txtADSID.Text = probjUser.ADSID;
         txtLoginName.Text = probjUser.LoginName;
   	   txtFirstName.Text = probjUser.FirstName;
		   txtLastName.Text = probjUser.LastName;
		   txtPassword.Text = probjUser.Password;
	   }

	   private void prUpdateUserProperties() {
         probjUser.ADSID = txtADSID.Text;
         probjUser.ADName = txtADName.Text;
         probjUser.LoginName = txtLoginName.Text;
		   probjUser.FirstName = txtFirstName.Text;
		   probjUser.LastName = txtLastName.Text;
		   probjUser.Password = txtPassword.Text;
	   }
	}
}