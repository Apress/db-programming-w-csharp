// Listing 9-1-1
public interface IUserMan {
   string TestProperty {
      get;
      set;
   }

   void TestMethod();
}