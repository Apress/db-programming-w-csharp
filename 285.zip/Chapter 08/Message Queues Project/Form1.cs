using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Message_Queues_Project
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
      private System.Windows.Forms.Button btnMisc;
      private System.Windows.Forms.Button btnJournaling;
      private System.Windows.Forms.Button btnCreatePrivateQueue;
      private System.Windows.Forms.Button btnTransactions;
      private System.Windows.Forms.Button btnCreateTransactional;
      private System.Windows.Forms.Button btnRemove;
      private System.Windows.Forms.Button btnBrowse;
      private System.Windows.Forms.Button btnExists;
      private System.Windows.Forms.Button brnPurge;
      private System.Windows.Forms.Button btnRetrieve;
      private System.Windows.Forms.Button btnSend;

      private CGeneral objGeneral = new CGeneral();

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         this.btnMisc = new System.Windows.Forms.Button();
         this.btnJournaling = new System.Windows.Forms.Button();
         this.btnCreatePrivateQueue = new System.Windows.Forms.Button();
         this.btnTransactions = new System.Windows.Forms.Button();
         this.btnCreateTransactional = new System.Windows.Forms.Button();
         this.btnRemove = new System.Windows.Forms.Button();
         this.btnBrowse = new System.Windows.Forms.Button();
         this.btnExists = new System.Windows.Forms.Button();
         this.brnPurge = new System.Windows.Forms.Button();
         this.btnRetrieve = new System.Windows.Forms.Button();
         this.btnSend = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // btnMisc
         // 
         this.btnMisc.Location = new System.Drawing.Point(120, 28);
         this.btnMisc.Name = "btnMisc";
         this.btnMisc.TabIndex = 8;
         this.btnMisc.Text = "Misc.";
         this.btnMisc.Click += new System.EventHandler(this.btnMisc_Click);
         // 
         // btnJournaling
         // 
         this.btnJournaling.Location = new System.Drawing.Point(16, 76);
         this.btnJournaling.Name = "btnJournaling";
         this.btnJournaling.Size = new System.Drawing.Size(80, 23);
         this.btnJournaling.TabIndex = 7;
         this.btnJournaling.Text = "Journaling";
         this.btnJournaling.Click += new System.EventHandler(this.btnJournaling_Click);
         // 
         // btnCreatePrivateQueue
         // 
         this.btnCreatePrivateQueue.Location = new System.Drawing.Point(120, 76);
         this.btnCreatePrivateQueue.Name = "btnCreatePrivateQueue";
         this.btnCreatePrivateQueue.Size = new System.Drawing.Size(168, 23);
         this.btnCreatePrivateQueue.TabIndex = 9;
         this.btnCreatePrivateQueue.Text = "Create Private Queue";
         this.btnCreatePrivateQueue.Click += new System.EventHandler(this.btnCreatePrivateQueue_Click);
         // 
         // btnTransactions
         // 
         this.btnTransactions.Location = new System.Drawing.Point(16, 108);
         this.btnTransactions.Name = "btnTransactions";
         this.btnTransactions.Size = new System.Drawing.Size(80, 23);
         this.btnTransactions.TabIndex = 11;
         this.btnTransactions.Text = "Transactions";
         this.btnTransactions.Click += new System.EventHandler(this.btnTransactions_Click);
         // 
         // btnCreateTransactional
         // 
         this.btnCreateTransactional.Location = new System.Drawing.Point(120, 108);
         this.btnCreateTransactional.Name = "btnCreateTransactional";
         this.btnCreateTransactional.Size = new System.Drawing.Size(168, 23);
         this.btnCreateTransactional.TabIndex = 10;
         this.btnCreateTransactional.Text = "Create Transactional";
         this.btnCreateTransactional.Click += new System.EventHandler(this.btnCreateTransactional_Click);
         // 
         // btnRemove
         // 
         this.btnRemove.Location = new System.Drawing.Point(216, 180);
         this.btnRemove.Name = "btnRemove";
         this.btnRemove.TabIndex = 6;
         this.btnRemove.Text = "Remove";
         this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
         // 
         // btnBrowse
         // 
         this.btnBrowse.Location = new System.Drawing.Point(216, 148);
         this.btnBrowse.Name = "btnBrowse";
         this.btnBrowse.TabIndex = 2;
         this.btnBrowse.Text = "Browse";
         this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
         // 
         // btnExists
         // 
         this.btnExists.Location = new System.Drawing.Point(120, 180);
         this.btnExists.Name = "btnExists";
         this.btnExists.TabIndex = 1;
         this.btnExists.Text = "Exists";
         this.btnExists.Click += new System.EventHandler(this.btnExists_Click);
         // 
         // brnPurge
         // 
         this.brnPurge.Location = new System.Drawing.Point(120, 148);
         this.brnPurge.Name = "brnPurge";
         this.brnPurge.TabIndex = 3;
         this.brnPurge.Text = "Purge";
         this.brnPurge.Click += new System.EventHandler(this.brnPurge_Click);
         // 
         // btnRetrieve
         // 
         this.btnRetrieve.Location = new System.Drawing.Point(16, 180);
         this.btnRetrieve.Name = "btnRetrieve";
         this.btnRetrieve.TabIndex = 5;
         this.btnRetrieve.Text = "Retrieve";
         this.btnRetrieve.Click += new System.EventHandler(this.btnRetrieve_Click);
         // 
         // btnSend
         // 
         this.btnSend.Location = new System.Drawing.Point(16, 148);
         this.btnSend.Name = "btnSend";
         this.btnSend.TabIndex = 4;
         this.btnSend.Text = "Send";
         this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(311, 223);
         this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                      this.btnMisc,
                                                                      this.btnJournaling,
                                                                      this.btnCreatePrivateQueue,
                                                                      this.btnTransactions,
                                                                      this.btnCreateTransactional,
                                                                      this.btnRemove,
                                                                      this.btnBrowse,
                                                                      this.btnExists,
                                                                      this.brnPurge,
                                                                      this.btnRetrieve,
                                                                      this.btnSend});
         this.Name = "Form1";
         this.Text = "Message Queues Project";
         this.ResumeLayout(false);

      }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

      private void btnMisc_Click(object sender, System.EventArgs e) {
         //objGeneral.CreatePublicQueue();
         //objGeneral.ChangeQueueLabel();
         //objGeneral.RetrieveQueueId();
         //objGeneral.BindToExistingQueue();
         //objGeneral.BindToExistingQueueUsingFormat();
         //objGeneral.BindToExistingQueueUsingLabel();
         //objGeneral.PeekMessage();
         //objGeneral.PeekMessagesAsync();
         //objGeneral.SetJournalMaxSize();
         //objGeneral.EnableQueueAuthentication();
         //objGeneral.RejectNonAuthenticatedMessage();
         //objGeneral.SendDeadLetterMessage();
         //objGeneral.PlaceNonAuthenticatedMessageInAdminQueue();
         objGeneral.AcceptAuthenticatedMessage();
         //objGeneral.EnableRequireBodyEncryption();
         //objGeneral.SendAndReceiveEncryptedMessage();
         //objGeneral.SetUserPermissions();
      }

      private void btnJournaling_Click(object sender, System.EventArgs e) {
         //objGeneral.EnableMQJournaling();      
         objGeneral.ShowMessageJournaling();
      }

      private void btnTransactions_Click(object sender, System.EventArgs e) {
         objGeneral.UseMQTransactions();
      }

      private void btnSend_Click(object sender, System.EventArgs e) {
         //objGeneral.SendSimpleMessage();
         objGeneral.SendMessage();
         //objGeneral.SendDifferentMessages();
         //objGeneral.SendPriorityMessages();
      }

      private void btnRetrieve_Click(object sender, System.EventArgs e) {
         //objGeneral.RetrieveSimpleMessage();
         //objGeneral.RetrieveMessage();
         //objGeneral.RetrieveDifferentMessages();
         //objGeneral.RetrieveMessageById();
         //objGeneral.RetrieveMessageByIdSafe("jhjhgjh");
         //objGeneral.RetrieveMessagesAsync();
         //objGeneral.RetrievePriorityMessage();
         objGeneral.RetrieveAllMessages();
      }

      private void btnCreatePrivateQueue_Click(object sender, System.EventArgs e) {
         //objGeneral.CreatePrivateQueueWithName();
         objGeneral.CreatePrivateQueue();
      }

      private void btnCreateTransactional_Click(object sender, System.EventArgs e) {
         objGeneral.CreateTransactionalPrivateQueue();
      }

      private void brnPurge_Click(object sender, System.EventArgs e) {
         objGeneral.ClearMessageQueue();
      }

      private void btnExists_Click(object sender, System.EventArgs e) {
         MessageBox.Show(objGeneral.CheckQueueExists(".\\Private$\\UserMan").ToString());
      }

      private void btnBrowse_Click(object sender, System.EventArgs e) {
         //objGeneral.BrowsePrivateQueues();
         //objGeneral.BrowsePublicQueuesMachineWide();
         //objGeneral.BrowsePublicQueuesNetworkWide();
         //objGeneral.BrowsePublicQueuesByCategoryNetworkWide();
         objGeneral.BrowsePublicQueuesByLabelNetworkWide();
      }

      private void btnRemove_Click(object sender, System.EventArgs e) {
         //objGeneral.RemoveMessageQueue(".\\userman");
         objGeneral.RemoveMessageQueueSafely(".\\userman");
      }
	}
}
