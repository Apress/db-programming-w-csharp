using System;

namespace UserMan {
   /// <summary>
   /// Summary description for CErrorEvent.
   /// </summary>

   // Listing 9-14
   public class CErrorEventArgs : EventArgs {
      public enum ErrorStatusEnum : int {
         NoError = 0,
         ServerDown = 1,
         TimeOut = 2,
         InvalidLoginName = 3
      }

      private ErrorStatusEnum printErrorStatus = ErrorStatusEnum.NoError;
      private string prstrErrorMessage;

      // Class constructor
      public CErrorEventArgs(ErrorStatusEnum enuErrorStatus)	{
         // Save the error status
         printErrorStatus = enuErrorStatus;		
         // Set the error message
         switch (printErrorStatus) {
            case ErrorStatusEnum.NoError : 
               prstrErrorMessage = "No error";
               break;
            case ErrorStatusEnum.InvalidLoginName : 
               prstrErrorMessage = "There are invalid characters in the LoginName!";
               break;
            case ErrorStatusEnum.ServerDown : 
               prstrErrorMessage = "The database server is currently unavailable!";
               break;
            case ErrorStatusEnum.TimeOut : 
               prstrErrorMessage = "A timeout connecting to the server has occurred!";
               break;
            default : 
               prstrErrorMessage = "Unknown error!";
               break;
         }
      }

      // Returns the error status
      public ErrorStatusEnum Status {
         get {
            return printErrorStatus;
         }
      }

      // Returns the error message
      public string Message {
         get {
            return prstrErrorMessage;
         }
      }
   }
}