#define Oracle 
//#define SQLSERVER 

using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;

public class CGeneral {
#if SQLSERVER
	// This connection string os for connecting to SQL Server
   // You must change the Data Source value
	public const string STR_CONNECTION_STRING = 
		"Data Source=USERMANPC;User Id=UserMan;Password=userman;Initial Catalog=UserMan";
#elif Oracle
   // This connection string os for connecting to Oracle
   // You must change the Data Source value
   public const string STR_CONNECTION_STRING = 
      "Provider=MSDAORA;Password=userman;User ID=USERMAN;Data Source=USERMAN";
#endif

	// Listing 6-1
	public void ExecuteSimpleSP() {
#if SQLSERVER
		SqlConnection cnnUserMan;
		SqlCommand cmmUser;
		object objNumUsers;

		// Instantiate and open the connection
		cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();

		// Instantiate and initialize command
		cmmUser = new SqlCommand("SimpleStoredProcedure", cnnUserMan);
		cmmUser.CommandType = CommandType.StoredProcedure;

		objNumUsers = cmmUser.ExecuteScalar();
		MessageBox.Show(objNumUsers.ToString());
#endif
   }

	// Listing 6-2
	public void ExecuteSimpleRowReturningSP() {
		SqlConnection cnnUserMan;
		SqlCommand cmmUser;
		SqlDataReader drdUser;

		// Instantiate and open the connection
		cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();

		// Instantiate and initialize command
		cmmUser = new SqlCommand("uspGetUsers", cnnUserMan);
		cmmUser.CommandType = CommandType.StoredProcedure;

		// Retrieve all user rows
		drdUser = cmmUser.ExecuteReader();
	}

	// Listing 6-3
	public void GetUsersByLastName() {
		SqlConnection cnnUserMan;
		SqlCommand cmmUser;
		SqlDataReader drdUser;
		SqlParameter prmLastName;

		// Instantiate and open the connection
		cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();

		// Instantiate and initialize command
		cmmUser = new SqlCommand("uspGetUsersByLastName", cnnUserMan);
		cmmUser.CommandType = CommandType.StoredProcedure;
		// Instantiate, initialize and add parameter to command
		prmLastName = cmmUser.Parameters.Add("@strLastName", SqlDbType.VarChar, 50);
		// Indicate this is an input parameter
		prmLastName.Direction = ParameterDirection.Input;
		// Set the value of the parameter
		prmLastName.Value = "Doe";

		// Return all users with a last name of Doe
		drdUser = cmmUser.ExecuteReader();
	}

	// Listing 6-4
	public void GetUsersAndRights() {
		SqlConnection cnnUserMan;
		SqlCommand cmmUser;
		SqlDataReader drdUser;
		SqlParameter prmNumRows;

		// Instantiate and open the connection
		cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();

		// Instantiate and initialize command
		cmmUser = new SqlCommand("uspGetUsersAndRights", cnnUserMan);
		cmmUser.CommandType = CommandType.StoredProcedure;
		// Instantiate, initialize and add parameter to command
		prmNumRows = cmmUser.Parameters.Add("@lngNumRows", SqlDbType.Int);
		// Indicate this is an output parameter
		prmNumRows.Direction = ParameterDirection.Output;
		// Get first batch of rows (users)
		drdUser = cmmUser.ExecuteReader();

		// Display the last name of all user rows
		while (drdUser.Read()) {
			MessageBox.Show(drdUser["LastName"].ToString());
		}

		// Get next batch of rows (user rights)
		if (drdUser.NextResult()) {
			// Display the id of all rights
			while (drdUser.Read()) {
				MessageBox.Show(drdUser["RightsId"].ToString());
			}
		}
	}

	// Listing 6-5
	public void GetRETURN_VALUE() {
		SqlConnection cnnUserMan;
		SqlCommand cmmUser;
		SqlParameter prmNumRows;
		object objResult;

		// Instantiate and open the connection
		cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
		cnnUserMan.Open();

		// Instantiate and initialize command
		cmmUser = new SqlCommand("uspGetRETURN_VALUE", cnnUserMan);
		cmmUser.CommandType = CommandType.StoredProcedure;
		// Instantiate, initialize and add parameter to command
		prmNumRows = cmmUser.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
		// Indicate this is a return value parameter
		prmNumRows.Direction = ParameterDirection.ReturnValue;
		// Get RETURN_VALUE like this, ...
		objResult = cmmUser.ExecuteScalar();
      // or like this
      MessageBox.Show(prmNumRows.Value.ToString());
	}

   // Listing 6-7
   public void ExecuteSimpleOracleSF() {
      OleDbConnection cnnUserMan;
      OleDbCommand cmmUser;
      OleDbParameter prmNumRows;
      object objReturnValue;

      // Instantiate and open the connection
      cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();

      // Instantiate and initialize command
      cmmUser = new OleDbCommand("SimpleStoredFunction", cnnUserMan);
      cmmUser.CommandType = CommandType.StoredProcedure;
      // Instantiate output parameter and add to parameter 
      // collection of command object
      prmNumRows = cmmUser.CreateParameter();
      prmNumRows.Direction = ParameterDirection.ReturnValue;
      prmNumRows.DbType = DbType.Int64;
      prmNumRows.Precision = 38;
      prmNumRows.Size = 38;
      cmmUser.Parameters.Add(prmNumRows);

      // Retrieve and display value
      objReturnValue = cmmUser.ExecuteScalar();
      MessageBox.Show(cmmUser.Parameters[0].Value.ToString());
   }

   // Listing 6-9
   public void ExecuteSimpleOracleSP() {
      OleDbConnection cnnUserMan;
      OleDbCommand cmmUser;
      OleDbParameter prmNumRows;
      object objReturnValue;

      // Instantiate and open the connection
      cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();

      // Instantiate and initialize command
      cmmUser = new OleDbCommand("SimpleStoredProcedure", cnnUserMan);
      cmmUser.CommandType = CommandType.StoredProcedure;
      // Instantiate output parameter and add to parameter 
      // collection of command object
      prmNumRows = cmmUser.CreateParameter();
      prmNumRows.Direction = ParameterDirection.Output;
      prmNumRows.DbType = DbType.Int64;
      prmNumRows.Precision = 38;
      prmNumRows.Size = 38;
      cmmUser.Parameters.Add(prmNumRows);

      // Retrieve and display value
      objReturnValue = cmmUser.ExecuteScalar();
      MessageBox.Show(cmmUser.Parameters[0].Value.ToString());
   }

   // Listing 6-11
   public void OracleGetUsersByLastName() {
      OleDbConnection cnnUserMan;
      OleDbCommand cmmUser;
      OleDbParameter prmLastName;
      OleDbDataReader drdUser;

      // Instantiate and open the connection
      cnnUserMan = new OleDbConnection(STR_CONNECTION_STRING);
      cnnUserMan.Open();

      // Instantiate and initialize command
      cmmUser = new OleDbCommand("USPGETUSERSBYLASTNAME", cnnUserMan);
      cmmUser.CommandType = CommandType.StoredProcedure;
      // Instantiate, initialize and add parameter to command
      prmLastName = cmmUser.Parameters.Add("strLastName", OleDbType.VarChar, 50);
      // Indicate this is an input parameter
      prmLastName.Direction = ParameterDirection.Input;
      // Set the type and value of the parameter
      prmLastName.Value = "Doe";

      // Retrieve rows
      drdUser = cmmUser.ExecuteReader();
      // Loop through the returned rows
      while (drdUser.Read()) {
         // Display the last name of all user rows
         MessageBox.Show(drdUser["LastName"].ToString());
      }
   }
}