using System;

/// <summary>
/// Summary description for CAbstract.
/// </summary>
// Listing 9-3-1
public abstract class CAbstract {
   private string prstrTest;

   public string Test {
      get {
         return prstrTest;
      }

      set {
         prstrTest = value;
      }
   }
}