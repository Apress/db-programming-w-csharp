using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace UserMan {
	/// <summary>
	/// Summary description for frmMain.
	/// </summary>

   public class frmMain : System.Windows.Forms.Form {
      internal System.Windows.Forms.LinkLabel lblUserManWebSite;
      private System.Windows.Forms.MainMenu mnuMain;
      private System.Windows.Forms.MenuItem mnuAdmin;
      private System.Windows.Forms.MenuItem mnuAdminProperties;
      private System.Windows.Forms.MenuItem mnuUser;
      private System.Windows.Forms.MenuItem mnuWindow;
      private System.Windows.Forms.MenuItem mnuAdminLogOn;
      private System.Windows.Forms.MenuItem mnuAdminLogOff;
      private System.Windows.Forms.MenuItem mnuAdminExit;
      private System.Windows.Forms.MenuItem menuItem1;
      private System.Windows.Forms.MenuItem menuItem2;
      private System.Windows.Forms.MenuItem mnuUserViewAll;
      private System.Windows.Forms.MenuItem mnuWindowArrangeAll;
      private System.Windows.Forms.MenuItem mnuUserADInfo;


      frmProperties frmProp;
      /// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMain));
         this.lblUserManWebSite = new System.Windows.Forms.LinkLabel();
         this.mnuMain = new System.Windows.Forms.MainMenu();
         this.mnuAdmin = new System.Windows.Forms.MenuItem();
         this.mnuAdminProperties = new System.Windows.Forms.MenuItem();
         this.menuItem1 = new System.Windows.Forms.MenuItem();
         this.mnuAdminLogOn = new System.Windows.Forms.MenuItem();
         this.mnuAdminLogOff = new System.Windows.Forms.MenuItem();
         this.menuItem2 = new System.Windows.Forms.MenuItem();
         this.mnuAdminExit = new System.Windows.Forms.MenuItem();
         this.mnuUser = new System.Windows.Forms.MenuItem();
         this.mnuUserViewAll = new System.Windows.Forms.MenuItem();
         this.mnuUserADInfo = new System.Windows.Forms.MenuItem();
         this.mnuWindow = new System.Windows.Forms.MenuItem();
         this.mnuWindowArrangeAll = new System.Windows.Forms.MenuItem();
         this.SuspendLayout();
         // 
         // lblUserManWebSite
         // 
         this.lblUserManWebSite.AccessibleRole = System.Windows.Forms.AccessibleRole.Link;
         this.lblUserManWebSite.BackColor = System.Drawing.SystemColors.Control;
         this.lblUserManWebSite.CausesValidation = false;
         this.lblUserManWebSite.Image = ((System.Drawing.Bitmap)(resources.GetObject("lblUserManWebSite.Image")));
         this.lblUserManWebSite.Location = new System.Drawing.Point(206, 99);
         this.lblUserManWebSite.Name = "lblUserManWebSite";
         this.lblUserManWebSite.Size = new System.Drawing.Size(173, 75);
         this.lblUserManWebSite.TabIndex = 2;
         this.lblUserManWebSite.TabStop = true;
         this.lblUserManWebSite.Text = "http://www.userman.dk";
         this.lblUserManWebSite.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
         this.lblUserManWebSite.UseMnemonic = false;
         this.lblUserManWebSite.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblUserManWebSite_LinkClicked);
         // 
         // mnuMain
         // 
         this.mnuMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                this.mnuAdmin,
                                                                                this.mnuUser,
                                                                                this.mnuWindow});
         // 
         // mnuAdmin
         // 
         this.mnuAdmin.Index = 0;
         this.mnuAdmin.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                 this.mnuAdminProperties,
                                                                                 this.menuItem1,
                                                                                 this.mnuAdminLogOn,
                                                                                 this.mnuAdminLogOff,
                                                                                 this.menuItem2,
                                                                                 this.mnuAdminExit});
         this.mnuAdmin.MergeType = System.Windows.Forms.MenuMerge.MergeItems;
         this.mnuAdmin.Text = "&Admin";
         // 
         // mnuAdminProperties
         // 
         this.mnuAdminProperties.Enabled = false;
         this.mnuAdminProperties.Index = 0;
         this.mnuAdminProperties.MergeType = System.Windows.Forms.MenuMerge.MergeItems;
         this.mnuAdminProperties.Text = "&Properties...";
         this.mnuAdminProperties.Click += new System.EventHandler(this.mnuAdminProperties_Click);
         // 
         // menuItem1
         // 
         this.menuItem1.Index = 1;
         this.menuItem1.Text = "-";
         // 
         // mnuAdminLogOn
         // 
         this.mnuAdminLogOn.Index = 2;
         this.mnuAdminLogOn.Text = "Log &On...";
         this.mnuAdminLogOn.Click += new System.EventHandler(this.mnuAdminLogOn_Click);
         // 
         // mnuAdminLogOff
         // 
         this.mnuAdminLogOff.Enabled = false;
         this.mnuAdminLogOff.Index = 3;
         this.mnuAdminLogOff.Text = "Log O&ff";
         this.mnuAdminLogOff.Click += new System.EventHandler(this.mnuAdminLogOff_Click);
         // 
         // menuItem2
         // 
         this.menuItem2.Index = 4;
         this.menuItem2.Text = "-";
         // 
         // mnuAdminExit
         // 
         this.mnuAdminExit.Index = 5;
         this.mnuAdminExit.Text = "E&xit";
         this.mnuAdminExit.Click += new System.EventHandler(this.mnuAdminExit_Click);
         // 
         // mnuUser
         // 
         this.mnuUser.Enabled = false;
         this.mnuUser.Index = 1;
         this.mnuUser.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                this.mnuUserViewAll,
                                                                                this.mnuUserADInfo});
         this.mnuUser.Text = "&User";
         // 
         // mnuUserViewAll
         // 
         this.mnuUserViewAll.Index = 0;
         this.mnuUserViewAll.Text = "&View All";
         this.mnuUserViewAll.Click += new System.EventHandler(this.mnuUserViewAll_Click);
         // 
         // mnuUserADInfo
         // 
         this.mnuUserADInfo.Index = 1;
         this.mnuUserADInfo.Text = "Retrieve User Info from &Active Directory";
         this.mnuUserADInfo.Click += new System.EventHandler(this.mnuUserADInfo_Click);
         // 
         // mnuWindow
         // 
         this.mnuWindow.Index = 2;
         this.mnuWindow.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                  this.mnuWindowArrangeAll});
         this.mnuWindow.Text = "&Window";
         // 
         // mnuWindowArrangeAll
         // 
         this.mnuWindowArrangeAll.Index = 0;
         this.mnuWindowArrangeAll.Text = "&Arrange All";
         this.mnuWindowArrangeAll.Click += new System.EventHandler(this.mnuWindowArrangeAll_Click);
         // 
         // frmMain
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(569, 356);
         this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                      this.lblUserManWebSite});
         this.IsMdiContainer = true;
         this.Menu = this.mnuMain;
         this.Name = "frmMain";
         this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
         this.Text = "UserMan Example Application [Not Logged On]";
         this.Resize += new System.EventHandler(this.frmMain_Resize);
         this.Activated += new System.EventHandler(this.frmMain_Activated);
         this.ResumeLayout(false);

      }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() { 
         // Run main form
      	Application.Run(new frmMain());
		}

      private void lblUserManWebSite_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e) {
         // Change appearance of the link label
		   lblUserManWebSite.LinkVisited = true;
		   // Open the default browser 
   	   System.Diagnostics.Process.Start("http://www.userman.dk");
      }

   	private void frmMain_Resize(object sender, System.EventArgs e) {
		   // Center the link label
		   lblUserManWebSite.Top = (this.ClientSize.Height - lblUserManWebSite.Height) / 2;
		   lblUserManWebSite.Left = (this.ClientSize.Width - lblUserManWebSite.Width) / 2;
	   }

      private void frmMain_Activated(object sender, System.EventArgs e) {
         // Check if the user was logged on
         if (! (CGeneral.LoggedOn)) {
            // Display logon form
            mnuAdminLogOn.PerformClick();
         }
      }
      
      private void prEnableMenus(bool blnLoggedOn) {
		   mnuAdminLogOff.Enabled = blnLoggedOn;
		   mnuAdminProperties.Enabled = blnLoggedOn;
		   mnuUser.Enabled = blnLoggedOn;
      }

      private void mnuAdminProperties_Click(object sender, System.EventArgs e) {
         try {
            // This will fail if the form isn't already shown
            frmProp.Activate();
         }
         catch {
            frmProp = new frmProperties(true);

            // Make the properties form an MDI child of this form
            frmProp.MdiParent = this;
            frmProp.Show();
         }
      }

      private void mnuAdminLogOn_Click(object sender, System.EventArgs e) {
         frmLogOn frmLog = new frmLogOn();

         // Show logon form as modal dialog
         frmLog.ShowDialog();

         // Check if the user was logged on
         if (CGeneral.LoggedOn) {
            this.Text = "UserMan Example Application [" + CGeneral.objAdminUser.LoginName + "]";
            // Update the menus
            prEnableMenus(true);
         }
      }

      private void mnuAdminLogOff_Click(object sender, System.EventArgs e) {
		   CGeneral.LoggedOn = false;
		   CGeneral.objAdminUser = null;
		   CGeneral.objAdminUser = new CUser();
		   this.Text = "UserMan Example Application [Not Logged On]";
		   // Update the menus
		   prEnableMenus(false);
      }

      private void mnuAdminExit_Click(object sender, System.EventArgs e) {
		   // Unload application
         Application.Exit();
      }

      private void mnuWindowArrangeAll_Click(object sender, System.EventArgs e) {
   		this.LayoutMdi(System.Windows.Forms.MdiLayout.TileHorizontal);
      }

      private void mnuUserViewAll_Click(object sender, System.EventArgs e) {
		   frmUsers frmU = new frmUsers();

		   // Make the users form an MDI child of this form
		   frmU.MdiParent = this;
		   frmU.Show();
      }

      private void mnuUserADInfo_Click(object sender, System.EventArgs e) {
         try {
            CGeneral.objAdminUser.GetADUserInfo();             
         }
         catch (Exception objE) {
            MessageBox.Show(objE.Message + "\n" + objE.InnerException.Message);
         }
      }
	}
}