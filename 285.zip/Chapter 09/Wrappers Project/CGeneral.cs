using System;

/// <summary>
/// Summary description for CGeneral.
/// </summary>
public class CGeneral {
   // Listing 9-1-3
   public void CreateUserManObject() {
      CUserMan objUserMan = new CUserMan();
   }
   // Listing 9-3-2
   public void InstantiateAbstractClass() {
      //CAbstract objAbstract = new CAbstract();
   }

   // Listing 9-4-2
   public void InstantiateAbstractClassWrapper() {
      CWrapper objAbstract = new CWrapper();
   }

   // To be used with Listing 9-5
   public void OverridePropertyInOverridableClass() {
      CWrapper1 objOverridable = new CWrapper1();
   }
}