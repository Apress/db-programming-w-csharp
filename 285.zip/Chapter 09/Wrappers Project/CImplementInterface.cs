using System;

/// <summary>
/// Summary description for CUserMan.
/// </summary>

// Listing 9-1-2
public class CUserMan : IUserMan {

   private string prstrUserName;

   // This is where the TestProperty method
   // of the IUserMan interface is being 
   // defined as an explicit member
   // implementation (UserName)
   string IUserMan.TestProperty {
      get {
        return UserName;
      }
      set {
        UserName= value;
      }
   }

   // This is the explicit interface 
   // member implementation of TestProperty
   public string UserName {
      get {
         return prstrUserName;
      }
      set {
         prstrUserName = value;
      }
   }

   // This is where the TestMethod method
   // of the IUserMan interface is being 
   // defined as an explicit member
   // implementation (CalculateOnTime)
   void IUserMan.TestMethod() {
      CalculateOnTime();  
   }

   // This is the explicit interface 
   // member implementation of TestMethod
   public void CalculateOnTime() {
   }
}