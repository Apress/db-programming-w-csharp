using System;

/// <summary>
/// Summary description for CVirtual.
/// </summary>
// Listing 9-5-1
public class CVirtual {
   private string prstrTest;

   public virtual string Test {
      get {
         return prstrTest;
      }

      set {
         prstrTest = value;
      }
   }
}