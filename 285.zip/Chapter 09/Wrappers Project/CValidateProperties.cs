using System;

/// <summary>
/// Summary description for CValidateProperties.
/// </summary>
public class CValidateProperties
{
   private string prstrTest;

   public string Test {
      get {
         return prstrTest;
      }

      // Listing 9-2
      set {
         // Check if the string contains any invalid chars
         if ((value.IndexOf("@") == -1)) {
            prstrTest = value;
         }
      }
   }
}