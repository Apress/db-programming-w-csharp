using System;
using System.Data;
using System.Data.SqlClient;

namespace UserMan
{
	/// <summary>
	/// Summary description for CLog.
	/// </summary>
	public class CLog {
		public CLog() {
         // Open the connection to the database
         OpenDatabaseConnection();
         // Instantiate the command objects
         InstantiateCommands();
         // Instantiate the dataset
         InstantiateDataSet();
         // Instantiate and populate the data adapter
         InstantiateAndInitializeDataAdapter();
         // Add paramerts to the command objects
         AddCommandObjectParameters();
         // Populate the data set with data
         PopulateDataSet();
         // Get source table schema
         prSetColumnMaxLength();
         // Save the dataset valuies
         SaveDataSetValues();
		}

      ~CLog() {
          // Close the database connection
          CloseDatabaseConnection();
      }

      // Database constants
      private const string PR_STR_CONNECTION = "Data Source=USERMANPC;" +
         "User ID=UserMan;Password=userman;Initial Catalog=UserMan";

      private const string PR_STR_SQL_TABLE_NAME = "tblLog";
      private const string PR_STR_SQL_TABLE_LOG_FIELD_ID = "Id";

      private const string PR_STR_SQL_LOG_SELECT = "SELECT * FROM " + PR_STR_SQL_TABLE_NAME;
      private const string PR_STR_SQL_LOG_DELETE = "DELETE FROM " + PR_STR_SQL_TABLE_NAME + 
         " WHERE " + PR_STR_SQL_TABLE_LOG_FIELD_ID + "=@" + PR_STR_SQL_TABLE_LOG_FIELD_ID;
      private const string PR_STR_SQL_LOG_INSERT = "INSERT INTO " + PR_STR_SQL_TABLE_NAME + 
         "(Logged, Description, UserId) VALUES(@Logged, @Description, @UserId)";
      private const string PR_STR_SQL_LOG_UPDATE = "UPDATE " + PR_STR_SQL_TABLE_NAME + 
         " SET Logged=@Logged, Description=@Description, UserId=@UserId WHERE " + 
         PR_STR_SQL_TABLE_LOG_FIELD_ID + "=@" + PR_STR_SQL_TABLE_LOG_FIELD_ID;

      // Log table column values
      private long prlngId;
      private string prstrDescription;
      private DateTime prdtmLogged;
      private long prlngUserId;

      // Log table column max lengths
      private int printDescriptionMaxLen;

      // Database variables
      private static SqlConnection prshcnnUserMan;
      private SqlDataAdapter prdadUserMan;
      private DataSet prdstUserMan;

      // For direct log table manipulation
      private SqlCommand prcmmLog;
      // The command objects for the dataset manipulation
      private SqlCommand prcmmLogSelect;
      private SqlCommand prcmmLogDelete;
      private SqlCommand prcmmLogInsert;
      private SqlCommand prcmmLogUpdate;

      // Parameter objects for the data set manipulation
      private SqlParameter prprmSQLDelete, prprmSQLUpdate, prprmSQLInsert;

      private void OpenDatabaseConnection() {
         try {
            // Check if the connection has already been instantiated
            if (prshcnnUserMan == null) {
               // Instantiate the connection
               prshcnnUserMan = new SqlConnection(PR_STR_CONNECTION);
               // Check if the connection is closed
               if ((bool) (prshcnnUserMan.State == ConnectionState.Closed)) {
                  // Open the connection
                  prshcnnUserMan.Open();
               }
            }
         }
         catch (SqlException objSqlException) {
            // A Connection low-level exception was thrown. Add a description and re-throw
            // the exception to the caller of this class
            throw new Exception("The connection to the UserMan database could not be " + 
               "established, due to a connection low-level error", objSqlException);
         }
         catch (Exception objE) {
            // Any other exception thrown is handled here
            throw new Exception("The connection to the UserMan database could not be " + 
               "established.", objE);
         }
      }

      private void CloseDatabaseConnection() {
         try {
            // Close the connection
            prshcnnUserMan.Close();
         }
         catch (Exception objE) {
            throw new Exception("The connection to the UserMan database could not be closed properly.", objE);
         }
      }

      private void InstantiateCommands() {
         // Instantiate the data set command objects
         prcmmLogSelect = new SqlCommand(PR_STR_SQL_LOG_SELECT, prshcnnUserMan);
         prcmmLogDelete = new SqlCommand(PR_STR_SQL_LOG_DELETE, prshcnnUserMan);
         prcmmLogInsert = new SqlCommand(PR_STR_SQL_LOG_INSERT, prshcnnUserMan);
         prcmmLogUpdate = new SqlCommand(PR_STR_SQL_LOG_UPDATE, prshcnnUserMan);
         // Instantiate and initialize generic command object
         prcmmLog = new SqlCommand();
         prcmmLog.Connection = prshcnnUserMan;
      }

      private void InstantiateDataSet() {
         prdstUserMan = new DataSet();
      }

      private void InstantiateAndInitializeDataAdapter() {
         prdadUserMan = new SqlDataAdapter();
         prdadUserMan.SelectCommand = prcmmLogSelect;
         prdadUserMan.InsertCommand = prcmmLogInsert;
         prdadUserMan.DeleteCommand = prcmmLogDelete;
         prdadUserMan.UpdateCommand = prcmmLogUpdate;
      }

      private void AddCommandObjectParameters() {
         // Add delete command parameters
         prcmmLogDelete.Parameters.Add("@Logged", SqlDbType.SmallDateTime, 0, "Logged");
         prcmmLogDelete.Parameters.Add("@Description", SqlDbType.VarChar, 255, "Description");
         prcmmLogDelete.Parameters.Add("@UserId", SqlDbType.Int, 0, "UserId");

         prprmSQLDelete = prdadUserMan.DeleteCommand.Parameters.Add("@" + PR_STR_SQL_TABLE_LOG_FIELD_ID, 
            SqlDbType.Int, 0, PR_STR_SQL_TABLE_LOG_FIELD_ID);
         prprmSQLDelete.Direction = ParameterDirection.Input;
         prprmSQLDelete.SourceVersion = DataRowVersion.Original;

         // Add update command parameters
         prcmmLogUpdate.Parameters.Add("@Logged", SqlDbType.SmallDateTime, 0, "Logged");
         prcmmLogUpdate.Parameters.Add("@Description", SqlDbType.VarChar, 255, "Description");
         prcmmLogUpdate.Parameters.Add("@UserId", SqlDbType.Int, 0, "UserId");

         prprmSQLUpdate = prdadUserMan.UpdateCommand.Parameters.Add("@" + PR_STR_SQL_TABLE_LOG_FIELD_ID, 
            SqlDbType.Int, 0, PR_STR_SQL_TABLE_LOG_FIELD_ID);
         prprmSQLUpdate.Direction = ParameterDirection.Input;
         prprmSQLUpdate.SourceVersion = DataRowVersion.Original;

         // Add insert command parameters
         prcmmLogInsert.Parameters.Add("@Logged", SqlDbType.SmallDateTime, 0, "Logged");
         prcmmLogInsert.Parameters.Add("@Description", SqlDbType.VarChar, 255, "Description");
         prcmmLogInsert.Parameters.Add("@UserId", SqlDbType.Int, 0, "UserId");
      }

      private void PopulateDataSet() {
         try {
            prdadUserMan.Fill(prdstUserMan, "tblLog");
         }
         catch (SystemException objSystemException) {
            throw new Exception("The dataset could not be populated, " + 
               "because the source table was invalid.", objSystemException);
         }
         catch (Exception objE) {
            throw new Exception("The dataset could not be populated.", objE);
         }
      }

      private void SaveDataSetValues() {
         // Check if the dataset is empty
         if (prdstUserMan.Tables["tblLog"].Rows.Count > 0) {
            // Save log id
            prlngId = (long) prdstUserMan.Tables["tblLog"].Rows[0][PR_STR_SQL_TABLE_LOG_FIELD_ID];
            // Save description
            prstrDescription = prdstUserMan.Tables["tblLog"].Rows[0]["Description"].ToString();
            // Save log date and time
            prdtmLogged = (DateTime) prdstUserMan.Tables["tblLog"].Rows[0]["Logged"];
            // Save user id
            prlngUserId = (long) prdstUserMan.Tables["tblLog"].Rows[0]["UserId"];
         }
      }

      public void SetUserProperties(long lngLogId, string strDescription, DateTime dtmLogged, long lngUserId) {
         prlngId = lngLogId;
         prstrDescription = strDescription;
         prdtmLogged = dtmLogged;
         prlngUserId = lngUserId;
      }

      public bool IsDBOpen {
         get {
            return (bool) (prshcnnUserMan.State == ConnectionState.Open);
         }
      }

      public long Id {
         get {
            return prlngId;
         }
      }

      public string Description {
         get {
            return prstrDescription;
         }

         set {
            if (value.Length <= printDescriptionMaxLen) {
               prstrDescription = value;
            }
            else {
               prstrDescription = value.Substring(0,printDescriptionMaxLen);
            }
         }
      }

      public DateTime Logged {
         get {
            return prdtmLogged;
         }

         set {
            prdtmLogged = value;
         }
      }

      public long UserId {
         get {
             return prlngUserId;
         }

         set {
            prlngUserId = value;
         }
      }

      public bool AddLogEntry() {
         int intResult;

         prcmmLog.CommandType = CommandType.Text;
         prcmmLog.CommandText = "INSERT INTO " + PR_STR_SQL_TABLE_NAME + "(Description, Logged, UserId) VALUES('" + 
            prstrDescription + "','" +  prdtmLogged.ToString("M/d/yyyy H:mm") + "', " + prlngUserId.ToString() + ")";

         intResult = prcmmLog.ExecuteNonQuery();

         // Examine return result from query
         return (bool) (intResult == 1);
      }

      private void prSetColumnMaxLength() {
         SqlDataReader drdSchema;
         DataTable dtbSchema;

         prcmmLog.CommandType = CommandType.Text;
         prcmmLog.Connection = prshcnnUserMan;
         prcmmLog.CommandText = "SELECT * FROM " + PR_STR_SQL_TABLE_NAME;

         // Return data reader
         drdSchema = prcmmLog.ExecuteReader();

         // Read schema from source table
         dtbSchema = drdSchema.GetSchemaTable();

         // Save the maxlength values
         printDescriptionMaxLen = (int) dtbSchema.Rows[2]["ColumnSize"];

         // Close datareader
         drdSchema.Close();
      }
   }
}