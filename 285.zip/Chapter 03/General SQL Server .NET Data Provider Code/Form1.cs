using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace General_SQL_Server_.NET_Data_Provider_Code_Project
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label lblDescription;
		private System.Windows.Forms.Button btnMisc;
		private System.Windows.Forms.Button btnOpenConnection;
		private static CGeneral objGeneral = new CGeneral();
		private System.Windows.Forms.Button btnCheckConnectionPooling;
		private System.Windows.Forms.Button btnBeginTransaction;
		private System.Windows.Forms.Button btnUseTransactionSavePoints;
		private System.Windows.Forms.Button btnDetermineTransactionIsolationLevel;
		private System.Windows.Forms.Button btnInstantiateCommand;
		private System.Windows.Forms.Button btnExecuteNonQuery;
		private System.Windows.Forms.Button btnExecuteReader;
		private System.Windows.Forms.Button btnExecuteScalar;
		private System.Windows.Forms.Button btnExecuteXmlReader;
		private System.Windows.Forms.Button btnInstantiateDataReader;
		private System.Windows.Forms.Button btnReadRowsFromDataReader;
		private System.Windows.Forms.Button btnReadRowsFromXmlReader;
		private System.Windows.Forms.Button btnInstantiateXmlReader;
		private System.Windows.Forms.Button btnInstantiateDataAdapter;
		private System.Windows.Forms.Button btnSetDataAdapterCommands;
		private System.Windows.Forms.Button btnUpdateDataSet;
		private System.Windows.Forms.Button btnClearDataSet;
		private System.Windows.Forms.Button btnCloneDataSetStructure;
		private System.Windows.Forms.Button btnCopyDataSet;
		private System.Windows.Forms.Button btnMergeDataSetWithDataRows;
		private System.Windows.Forms.Button btnMergeDataSets;
		private System.Windows.Forms.Button btnMergeDataSetWithDataTable;
		private System.Windows.Forms.Button btnBuildDataTable;
		private System.Windows.Forms.Button btnClearDataTable;
		private System.Windows.Forms.Button btnCloneDataTable;
		private System.Windows.Forms.Button btnCopyDataTable;
		private System.Windows.Forms.Button btnSearchDataTable;
		private System.Windows.Forms.Button btnSearchDataView;
		private System.Windows.Forms.Button btnDetectAllDataSetChanges;
		private System.Windows.Forms.Button btnDetectDifferentDataSetChanges;
		private System.Windows.Forms.Button btnAcceptOrRejectDataSetChanges;
		private System.Windows.Forms.Button btnBuildUserManDatabase;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
         this.lblDescription = new System.Windows.Forms.Label();
         this.btnMisc = new System.Windows.Forms.Button();
         this.btnOpenConnection = new System.Windows.Forms.Button();
         this.btnCheckConnectionPooling = new System.Windows.Forms.Button();
         this.btnBeginTransaction = new System.Windows.Forms.Button();
         this.btnUseTransactionSavePoints = new System.Windows.Forms.Button();
         this.btnDetermineTransactionIsolationLevel = new System.Windows.Forms.Button();
         this.btnInstantiateCommand = new System.Windows.Forms.Button();
         this.btnExecuteNonQuery = new System.Windows.Forms.Button();
         this.btnExecuteReader = new System.Windows.Forms.Button();
         this.btnExecuteScalar = new System.Windows.Forms.Button();
         this.btnExecuteXmlReader = new System.Windows.Forms.Button();
         this.btnInstantiateDataReader = new System.Windows.Forms.Button();
         this.btnReadRowsFromDataReader = new System.Windows.Forms.Button();
         this.btnReadRowsFromXmlReader = new System.Windows.Forms.Button();
         this.btnInstantiateXmlReader = new System.Windows.Forms.Button();
         this.btnInstantiateDataAdapter = new System.Windows.Forms.Button();
         this.btnSetDataAdapterCommands = new System.Windows.Forms.Button();
         this.btnUpdateDataSet = new System.Windows.Forms.Button();
         this.btnClearDataSet = new System.Windows.Forms.Button();
         this.btnCloneDataSetStructure = new System.Windows.Forms.Button();
         this.btnCopyDataSet = new System.Windows.Forms.Button();
         this.btnMergeDataSetWithDataRows = new System.Windows.Forms.Button();
         this.btnMergeDataSets = new System.Windows.Forms.Button();
         this.btnMergeDataSetWithDataTable = new System.Windows.Forms.Button();
         this.btnBuildDataTable = new System.Windows.Forms.Button();
         this.btnClearDataTable = new System.Windows.Forms.Button();
         this.btnCloneDataTable = new System.Windows.Forms.Button();
         this.btnCopyDataTable = new System.Windows.Forms.Button();
         this.btnSearchDataTable = new System.Windows.Forms.Button();
         this.btnSearchDataView = new System.Windows.Forms.Button();
         this.btnDetectAllDataSetChanges = new System.Windows.Forms.Button();
         this.btnDetectDifferentDataSetChanges = new System.Windows.Forms.Button();
         this.btnAcceptOrRejectDataSetChanges = new System.Windows.Forms.Button();
         this.btnBuildUserManDatabase = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // lblDescription
         // 
         this.lblDescription.Location = new System.Drawing.Point(4, 4);
         this.lblDescription.Name = "lblDescription";
         this.lblDescription.Size = new System.Drawing.Size(710, 46);
         this.lblDescription.TabIndex = 0;
         this.lblDescription.Text = "Not all of the example code has a corresponding button, so please look in the Cod" +
            "eBehind file (.cs) for the code that doesn\'t have a button. You can attach the c" +
            "ode to the Misc. button if you want to run it.";
         // 
         // btnMisc
         // 
         this.btnMisc.Location = new System.Drawing.Point(4, 56);
         this.btnMisc.Name = "btnMisc";
         this.btnMisc.Size = new System.Drawing.Size(202, 23);
         this.btnMisc.TabIndex = 1;
         this.btnMisc.Text = "Misc.";
         this.btnMisc.Click += new System.EventHandler(this.btnMisc_Click);
         // 
         // btnOpenConnection
         // 
         this.btnOpenConnection.Location = new System.Drawing.Point(4, 94);
         this.btnOpenConnection.Name = "btnOpenConnection";
         this.btnOpenConnection.Size = new System.Drawing.Size(202, 23);
         this.btnOpenConnection.TabIndex = 2;
         this.btnOpenConnection.Text = "Open Connection";
         this.btnOpenConnection.Click += new System.EventHandler(this.btnOpenConnection_Click);
         // 
         // btnCheckConnectionPooling
         // 
         this.btnCheckConnectionPooling.Location = new System.Drawing.Point(4, 122);
         this.btnCheckConnectionPooling.Name = "btnCheckConnectionPooling";
         this.btnCheckConnectionPooling.Size = new System.Drawing.Size(202, 23);
         this.btnCheckConnectionPooling.TabIndex = 3;
         this.btnCheckConnectionPooling.Text = "Check Connection Pooling";
         this.btnCheckConnectionPooling.Click += new System.EventHandler(this.btnCheckConnectionPooling_Click);
         // 
         // btnBeginTransaction
         // 
         this.btnBeginTransaction.Location = new System.Drawing.Point(4, 178);
         this.btnBeginTransaction.Name = "btnBeginTransaction";
         this.btnBeginTransaction.Size = new System.Drawing.Size(202, 23);
         this.btnBeginTransaction.TabIndex = 4;
         this.btnBeginTransaction.Text = "Begin Transaction";
         this.btnBeginTransaction.Click += new System.EventHandler(this.btnBeginTransaction_Click);
         // 
         // btnUseTransactionSavePoints
         // 
         this.btnUseTransactionSavePoints.Location = new System.Drawing.Point(4, 206);
         this.btnUseTransactionSavePoints.Name = "btnUseTransactionSavePoints";
         this.btnUseTransactionSavePoints.Size = new System.Drawing.Size(202, 23);
         this.btnUseTransactionSavePoints.TabIndex = 5;
         this.btnUseTransactionSavePoints.Text = "Use Transaction Save Points";
         this.btnUseTransactionSavePoints.Click += new System.EventHandler(this.btnUseTransactionSavePoints_Click);
         // 
         // btnDetermineTransactionIsolationLevel
         // 
         this.btnDetermineTransactionIsolationLevel.Location = new System.Drawing.Point(4, 234);
         this.btnDetermineTransactionIsolationLevel.Name = "btnDetermineTransactionIsolationLevel";
         this.btnDetermineTransactionIsolationLevel.Size = new System.Drawing.Size(202, 23);
         this.btnDetermineTransactionIsolationLevel.TabIndex = 6;
         this.btnDetermineTransactionIsolationLevel.Text = "Determine Transaction Isolation Level";
         this.btnDetermineTransactionIsolationLevel.Click += new System.EventHandler(this.btnDetermineTransactionIsolationLevel_Click);
         // 
         // btnInstantiateCommand
         // 
         this.btnInstantiateCommand.Location = new System.Drawing.Point(212, 94);
         this.btnInstantiateCommand.Name = "btnInstantiateCommand";
         this.btnInstantiateCommand.Size = new System.Drawing.Size(149, 23);
         this.btnInstantiateCommand.TabIndex = 7;
         this.btnInstantiateCommand.Text = "Instantiate Command";
         this.btnInstantiateCommand.Click += new System.EventHandler(this.btnInstantiateCommand_Click);
         // 
         // btnExecuteNonQuery
         // 
         this.btnExecuteNonQuery.Location = new System.Drawing.Point(212, 122);
         this.btnExecuteNonQuery.Name = "btnExecuteNonQuery";
         this.btnExecuteNonQuery.Size = new System.Drawing.Size(149, 23);
         this.btnExecuteNonQuery.TabIndex = 8;
         this.btnExecuteNonQuery.Text = "Execute Non Query";
         this.btnExecuteNonQuery.Click += new System.EventHandler(this.btnExecuteNonQuery_Click);
         // 
         // btnExecuteReader
         // 
         this.btnExecuteReader.Location = new System.Drawing.Point(212, 150);
         this.btnExecuteReader.Name = "btnExecuteReader";
         this.btnExecuteReader.Size = new System.Drawing.Size(149, 23);
         this.btnExecuteReader.TabIndex = 9;
         this.btnExecuteReader.Text = "Execute Reader";
         this.btnExecuteReader.Click += new System.EventHandler(this.btnExecuteReader_Click);
         // 
         // btnExecuteScalar
         // 
         this.btnExecuteScalar.Location = new System.Drawing.Point(212, 178);
         this.btnExecuteScalar.Name = "btnExecuteScalar";
         this.btnExecuteScalar.Size = new System.Drawing.Size(149, 23);
         this.btnExecuteScalar.TabIndex = 10;
         this.btnExecuteScalar.Text = "Execute Scalar";
         this.btnExecuteScalar.Click += new System.EventHandler(this.btnExecuteScalar_Click);
         // 
         // btnExecuteXmlReader
         // 
         this.btnExecuteXmlReader.Location = new System.Drawing.Point(212, 206);
         this.btnExecuteXmlReader.Name = "btnExecuteXmlReader";
         this.btnExecuteXmlReader.Size = new System.Drawing.Size(149, 23);
         this.btnExecuteXmlReader.TabIndex = 11;
         this.btnExecuteXmlReader.Text = "Execute XmlReader";
         this.btnExecuteXmlReader.Click += new System.EventHandler(this.btnExecuteXmlReader_Click);
         // 
         // btnInstantiateDataReader
         // 
         this.btnInstantiateDataReader.Location = new System.Drawing.Point(366, 94);
         this.btnInstantiateDataReader.Name = "btnInstantiateDataReader";
         this.btnInstantiateDataReader.Size = new System.Drawing.Size(160, 23);
         this.btnInstantiateDataReader.TabIndex = 12;
         this.btnInstantiateDataReader.Text = "Instantiate DataReader";
         this.btnInstantiateDataReader.Click += new System.EventHandler(this.btnInstantiateDataReader_Click);
         // 
         // btnReadRowsFromDataReader
         // 
         this.btnReadRowsFromDataReader.Location = new System.Drawing.Point(366, 122);
         this.btnReadRowsFromDataReader.Name = "btnReadRowsFromDataReader";
         this.btnReadRowsFromDataReader.Size = new System.Drawing.Size(160, 23);
         this.btnReadRowsFromDataReader.TabIndex = 13;
         this.btnReadRowsFromDataReader.Text = "Read Rows from DataReader";
         this.btnReadRowsFromDataReader.Click += new System.EventHandler(this.btnReadRowsFromDataReader_Click);
         // 
         // btnReadRowsFromXmlReader
         // 
         this.btnReadRowsFromXmlReader.Location = new System.Drawing.Point(366, 178);
         this.btnReadRowsFromXmlReader.Name = "btnReadRowsFromXmlReader";
         this.btnReadRowsFromXmlReader.Size = new System.Drawing.Size(160, 23);
         this.btnReadRowsFromXmlReader.TabIndex = 15;
         this.btnReadRowsFromXmlReader.Text = "Read Rows from XmlReader";
         this.btnReadRowsFromXmlReader.Click += new System.EventHandler(this.btnReadRowsFromXmlReader_Click);
         // 
         // btnInstantiateXmlReader
         // 
         this.btnInstantiateXmlReader.Location = new System.Drawing.Point(366, 150);
         this.btnInstantiateXmlReader.Name = "btnInstantiateXmlReader";
         this.btnInstantiateXmlReader.Size = new System.Drawing.Size(160, 23);
         this.btnInstantiateXmlReader.TabIndex = 14;
         this.btnInstantiateXmlReader.Text = "Instantiate XmlReader";
         this.btnInstantiateXmlReader.Click += new System.EventHandler(this.btnInstantiateXmlReader_Click);
         // 
         // btnInstantiateDataAdapter
         // 
         this.btnInstantiateDataAdapter.Location = new System.Drawing.Point(532, 94);
         this.btnInstantiateDataAdapter.Name = "btnInstantiateDataAdapter";
         this.btnInstantiateDataAdapter.Size = new System.Drawing.Size(188, 23);
         this.btnInstantiateDataAdapter.TabIndex = 16;
         this.btnInstantiateDataAdapter.Text = "Instantiate DataAdapter";
         this.btnInstantiateDataAdapter.Click += new System.EventHandler(this.btnInstantiateDataAdapter_Click);
         // 
         // btnSetDataAdapterCommands
         // 
         this.btnSetDataAdapterCommands.Location = new System.Drawing.Point(532, 122);
         this.btnSetDataAdapterCommands.Name = "btnSetDataAdapterCommands";
         this.btnSetDataAdapterCommands.Size = new System.Drawing.Size(188, 23);
         this.btnSetDataAdapterCommands.TabIndex = 17;
         this.btnSetDataAdapterCommands.Text = "Set DataAdapter Commands";
         this.btnSetDataAdapterCommands.Click += new System.EventHandler(this.btnSetDataAdapterCommands_Click);
         // 
         // btnUpdateDataSet
         // 
         this.btnUpdateDataSet.Location = new System.Drawing.Point(532, 204);
         this.btnUpdateDataSet.Name = "btnUpdateDataSet";
         this.btnUpdateDataSet.Size = new System.Drawing.Size(188, 23);
         this.btnUpdateDataSet.TabIndex = 18;
         this.btnUpdateDataSet.Text = "Update DataSet";
         this.btnUpdateDataSet.Click += new System.EventHandler(this.btnUpdateDataSet_Click);
         // 
         // btnClearDataSet
         // 
         this.btnClearDataSet.Location = new System.Drawing.Point(532, 232);
         this.btnClearDataSet.Name = "btnClearDataSet";
         this.btnClearDataSet.Size = new System.Drawing.Size(188, 23);
         this.btnClearDataSet.TabIndex = 19;
         this.btnClearDataSet.Text = "Clear DataSet";
         this.btnClearDataSet.Click += new System.EventHandler(this.btnClearDataSet_Click);
         // 
         // btnCloneDataSetStructure
         // 
         this.btnCloneDataSetStructure.Location = new System.Drawing.Point(532, 260);
         this.btnCloneDataSetStructure.Name = "btnCloneDataSetStructure";
         this.btnCloneDataSetStructure.Size = new System.Drawing.Size(188, 23);
         this.btnCloneDataSetStructure.TabIndex = 20;
         this.btnCloneDataSetStructure.Text = "Clone DataSet Structure";
         this.btnCloneDataSetStructure.Click += new System.EventHandler(this.btnCloneDataSetStructure_Click);
         // 
         // btnCopyDataSet
         // 
         this.btnCopyDataSet.Location = new System.Drawing.Point(532, 288);
         this.btnCopyDataSet.Name = "btnCopyDataSet";
         this.btnCopyDataSet.Size = new System.Drawing.Size(188, 23);
         this.btnCopyDataSet.TabIndex = 21;
         this.btnCopyDataSet.Text = "Copy DataSet Structure && Data";
         this.btnCopyDataSet.Click += new System.EventHandler(this.btnCopyDataSet_Click);
         // 
         // btnMergeDataSetWithDataRows
         // 
         this.btnMergeDataSetWithDataRows.Location = new System.Drawing.Point(532, 316);
         this.btnMergeDataSetWithDataRows.Name = "btnMergeDataSetWithDataRows";
         this.btnMergeDataSetWithDataRows.Size = new System.Drawing.Size(188, 23);
         this.btnMergeDataSetWithDataRows.TabIndex = 22;
         this.btnMergeDataSetWithDataRows.Text = "Merge DataSet with DataRows";
         this.btnMergeDataSetWithDataRows.Click += new System.EventHandler(this.btnMergeDataSetWithDataRows_Click);
         // 
         // btnMergeDataSets
         // 
         this.btnMergeDataSets.Location = new System.Drawing.Point(532, 344);
         this.btnMergeDataSets.Name = "btnMergeDataSets";
         this.btnMergeDataSets.Size = new System.Drawing.Size(188, 23);
         this.btnMergeDataSets.TabIndex = 23;
         this.btnMergeDataSets.Text = "Merge DataSets";
         this.btnMergeDataSets.Click += new System.EventHandler(this.btnMergeDataSets_Click);
         // 
         // btnMergeDataSetWithDataTable
         // 
         this.btnMergeDataSetWithDataTable.Location = new System.Drawing.Point(532, 372);
         this.btnMergeDataSetWithDataTable.Name = "btnMergeDataSetWithDataTable";
         this.btnMergeDataSetWithDataTable.Size = new System.Drawing.Size(188, 23);
         this.btnMergeDataSetWithDataTable.TabIndex = 24;
         this.btnMergeDataSetWithDataTable.Text = "Merge DataSet with DataTable";
         this.btnMergeDataSetWithDataTable.Click += new System.EventHandler(this.btnMergeDataSetWithDataTable_Click);
         // 
         // btnBuildDataTable
         // 
         this.btnBuildDataTable.Location = new System.Drawing.Point(366, 232);
         this.btnBuildDataTable.Name = "btnBuildDataTable";
         this.btnBuildDataTable.Size = new System.Drawing.Size(160, 23);
         this.btnBuildDataTable.TabIndex = 25;
         this.btnBuildDataTable.Text = "Build DataTable";
         this.btnBuildDataTable.Click += new System.EventHandler(this.btnBuildDataTable_Click);
         // 
         // btnClearDataTable
         // 
         this.btnClearDataTable.Location = new System.Drawing.Point(366, 260);
         this.btnClearDataTable.Name = "btnClearDataTable";
         this.btnClearDataTable.Size = new System.Drawing.Size(160, 23);
         this.btnClearDataTable.TabIndex = 26;
         this.btnClearDataTable.Text = "Clear DataTable";
         this.btnClearDataTable.Click += new System.EventHandler(this.btnClearDataTable_Click);
         // 
         // btnCloneDataTable
         // 
         this.btnCloneDataTable.Location = new System.Drawing.Point(366, 288);
         this.btnCloneDataTable.Name = "btnCloneDataTable";
         this.btnCloneDataTable.Size = new System.Drawing.Size(160, 23);
         this.btnCloneDataTable.TabIndex = 27;
         this.btnCloneDataTable.Text = "Clone DataTable";
         this.btnCloneDataTable.Click += new System.EventHandler(this.btnCloneDataTable_Click);
         // 
         // btnCopyDataTable
         // 
         this.btnCopyDataTable.Location = new System.Drawing.Point(366, 316);
         this.btnCopyDataTable.Name = "btnCopyDataTable";
         this.btnCopyDataTable.Size = new System.Drawing.Size(160, 23);
         this.btnCopyDataTable.TabIndex = 28;
         this.btnCopyDataTable.Text = "Copy DataTable";
         this.btnCopyDataTable.Click += new System.EventHandler(this.btnCopyDataTable_Click);
         // 
         // btnSearchDataTable
         // 
         this.btnSearchDataTable.Location = new System.Drawing.Point(366, 344);
         this.btnSearchDataTable.Name = "btnSearchDataTable";
         this.btnSearchDataTable.Size = new System.Drawing.Size(160, 23);
         this.btnSearchDataTable.TabIndex = 29;
         this.btnSearchDataTable.Text = "Search DataTable";
         this.btnSearchDataTable.Click += new System.EventHandler(this.btnSearchDataTable_Click);
         // 
         // btnSearchDataView
         // 
         this.btnSearchDataView.Location = new System.Drawing.Point(366, 400);
         this.btnSearchDataView.Name = "btnSearchDataView";
         this.btnSearchDataView.Size = new System.Drawing.Size(160, 23);
         this.btnSearchDataView.TabIndex = 30;
         this.btnSearchDataView.Text = "Search DataView";
         this.btnSearchDataView.Click += new System.EventHandler(this.btnSearchDataView_Click);
         // 
         // btnDetectAllDataSetChanges
         // 
         this.btnDetectAllDataSetChanges.Location = new System.Drawing.Point(532, 400);
         this.btnDetectAllDataSetChanges.Name = "btnDetectAllDataSetChanges";
         this.btnDetectAllDataSetChanges.Size = new System.Drawing.Size(188, 23);
         this.btnDetectAllDataSetChanges.TabIndex = 31;
         this.btnDetectAllDataSetChanges.Text = "Detect all DataSet Changes";
         this.btnDetectAllDataSetChanges.Click += new System.EventHandler(this.btnDetectAllDataSetChanges_Click);
         // 
         // btnDetectDifferentDataSetChanges
         // 
         this.btnDetectDifferentDataSetChanges.Location = new System.Drawing.Point(532, 428);
         this.btnDetectDifferentDataSetChanges.Name = "btnDetectDifferentDataSetChanges";
         this.btnDetectDifferentDataSetChanges.Size = new System.Drawing.Size(188, 23);
         this.btnDetectDifferentDataSetChanges.TabIndex = 32;
         this.btnDetectDifferentDataSetChanges.Text = "Detect Different DataSet Changes";
         this.btnDetectDifferentDataSetChanges.Click += new System.EventHandler(this.btnDetectDifferentDataSetChanges_Click);
         // 
         // btnAcceptOrRejectDataSetChanges
         // 
         this.btnAcceptOrRejectDataSetChanges.Location = new System.Drawing.Point(532, 456);
         this.btnAcceptOrRejectDataSetChanges.Name = "btnAcceptOrRejectDataSetChanges";
         this.btnAcceptOrRejectDataSetChanges.Size = new System.Drawing.Size(188, 23);
         this.btnAcceptOrRejectDataSetChanges.TabIndex = 33;
         this.btnAcceptOrRejectDataSetChanges.Text = "Accept or Reject DataSet Changes";
         this.btnAcceptOrRejectDataSetChanges.Click += new System.EventHandler(this.btnAcceptOrRejectDataSetChanges_Click);
         // 
         // btnBuildUserManDatabase
         // 
         this.btnBuildUserManDatabase.Location = new System.Drawing.Point(212, 56);
         this.btnBuildUserManDatabase.Name = "btnBuildUserManDatabase";
         this.btnBuildUserManDatabase.Size = new System.Drawing.Size(149, 23);
         this.btnBuildUserManDatabase.TabIndex = 34;
         this.btnBuildUserManDatabase.Text = "Build UserMan Database";
         this.btnBuildUserManDatabase.Click += new System.EventHandler(this.btnBuildUserManDatabase_Click);
         // 
         // Form1
         // 
         this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
         this.ClientSize = new System.Drawing.Size(725, 484);
         this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                      this.btnBuildUserManDatabase,
                                                                      this.btnAcceptOrRejectDataSetChanges,
                                                                      this.btnDetectDifferentDataSetChanges,
                                                                      this.btnDetectAllDataSetChanges,
                                                                      this.btnSearchDataView,
                                                                      this.btnSearchDataTable,
                                                                      this.btnCopyDataTable,
                                                                      this.btnCloneDataTable,
                                                                      this.btnClearDataTable,
                                                                      this.btnBuildDataTable,
                                                                      this.btnMergeDataSetWithDataTable,
                                                                      this.btnMergeDataSets,
                                                                      this.btnMergeDataSetWithDataRows,
                                                                      this.btnCopyDataSet,
                                                                      this.btnCloneDataSetStructure,
                                                                      this.btnClearDataSet,
                                                                      this.btnUpdateDataSet,
                                                                      this.btnSetDataAdapterCommands,
                                                                      this.btnInstantiateDataAdapter,
                                                                      this.btnReadRowsFromXmlReader,
                                                                      this.btnInstantiateXmlReader,
                                                                      this.btnReadRowsFromDataReader,
                                                                      this.btnInstantiateDataReader,
                                                                      this.btnExecuteXmlReader,
                                                                      this.btnExecuteScalar,
                                                                      this.btnExecuteReader,
                                                                      this.btnExecuteNonQuery,
                                                                      this.btnInstantiateCommand,
                                                                      this.btnDetermineTransactionIsolationLevel,
                                                                      this.btnUseTransactionSavePoints,
                                                                      this.btnBeginTransaction,
                                                                      this.btnCheckConnectionPooling,
                                                                      this.btnOpenConnection,
                                                                      this.btnMisc,
                                                                      this.lblDescription});
         this.Name = "Form1";
         this.Text = "General SQL Server .NET Data Provider Code";
         this.ResumeLayout(false);

      }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void btnOpenConnection_Click(object sender, System.EventArgs e) {
			objGeneral.OpenConnection(CGeneral.STR_CONNECTION_STRING);
		}

		private void btnMisc_Click(object sender, System.EventArgs e) {
         //objGeneral.TriggerStateChangeEvent();
			//objGeneral.CheckConnectionStringWhiteSpace();
         //objGeneral.TriggerInfoMessageEvent();
         //objGeneral.CheckBeginTransactionMethodException();
			//objGeneral.CheckConnectionStringPropertyException();
			//objGeneral.CheckConnectionTimeoutPropertyException();
         //objGeneral.CheckChangeDatabaseMethodException();
			//objGeneral.CheckOpenMethodException();
			//objGeneral.TraversingAllSqlErrors();
			//objGeneral.CheckCommandTimeoutPropertyException();
			//objGeneral.CheckCommandTypePropertyException();
			//objGeneral.CheckPrepareMethodException();
			//objGeneral.CheckUpdateRowSourcePropertyException();
			//objGeneral.CheckForNullValueInColumn(1);
         //objGeneral.TriggerFillErrorEvent();
         //objGeneral.TriggerRowUpdateEvents();
         //objGeneral.TriggerMergeFailureEvent();
         //objGeneral.InstantiateDataSet();
         //objGeneral.InstantiateDataTable();
         //objGeneral.CopyRowsInDataTable();
         //objGeneral.TriggerColumnChangeEvents();
         //objGeneral.TriggerRowChangeEvents();
         //objGeneral.TriggerRowDeleteEvents();
         //objGeneral.TriggerListChangeEvent();
         //objGeneral.InstantiateDataView();
         //objGeneral.SortDataView();
         //objGeneral.InstantiateDataRow();
			//objGeneral.InstantiateDataColumn();
         //objGeneral.LockDataSourceRowsUsingTransactions();
         //objGeneral.TriggerConcurrencyViolation();
         //objGeneral.IgnoreConcurrencyViolations();
         objGeneral.HandleConcurrencyViolations();
		}

		private void btnCheckConnectionPooling_Click(object sender, System.EventArgs e) {
			objGeneral.CheckConnectionPooling();
		}

		private void btnBeginTransaction_Click(object sender, System.EventArgs e) {
			//objGeneral.BeginNonDefaultIsolationLevelTransaction();
			//objGeneral.BeginNamedTransaction();
			objGeneral.BeginNamedNonDefaultIsolationLevelTransaction();
		}

		private void btnUseTransactionSavePoints_Click(object sender, System.EventArgs e) {
			objGeneral.UseTransactionSavePoints();
		}

		private void btnDetermineTransactionIsolationLevel_Click(object sender, System.EventArgs e) {
			objGeneral.DetermineTransactionIsolationLevel();
		}

		private void btnInstantiateCommand_Click(object sender, System.EventArgs e) {
			objGeneral.InstantiateCommandObject();
		}

		private void btnExecuteNonQuery_Click(object sender, System.EventArgs e) {
			objGeneral.ExecuteNonQueryCommand();
		}

		private void btnExecuteReader_Click(object sender, System.EventArgs e) {
			objGeneral.ExecuteReaderCommand();
		}

		private void btnExecuteScalar_Click(object sender, System.EventArgs e) {
			objGeneral.ExecuteScalarCommand();
		}

		private void btnExecuteXmlReader_Click(object sender, System.EventArgs e) {
			objGeneral.ExecuteXmlReaderCommand();
		}

		private void btnInstantiateDataReader_Click(object sender, System.EventArgs e) {
			objGeneral.InstantiateDataReader();
		}

		private void btnReadRowsFromDataReader_Click(object sender, System.EventArgs e) {
			objGeneral.ReadRowsFromDataReader();
		}

		private void btnInstantiateXmlReader_Click(object sender, System.EventArgs e) {
			objGeneral.InstantiateXmlReader();
		}

		private void btnReadRowsFromXmlReader_Click(object sender, System.EventArgs e) {
			objGeneral.ReadRowsFromXmlReader();
		}

		private void btnInstantiateDataAdapter_Click(object sender, System.EventArgs e) {
			objGeneral.InstantiateAndInitializeDataAdapter();
		}

		private void btnSetDataAdapterCommands_Click(object sender, System.EventArgs e) {
			//objGeneral.SetDataAdapterCommandProperties();
			objGeneral.SetDataAdapterCommandPropertiesUsingCommandBuilder();
		}

		private void btnUpdateDataSet_Click(object sender, System.EventArgs e) {
			objGeneral.UpdateDataSet();
		}

		private void btnClearDataSet_Click(object sender, System.EventArgs e) {
			objGeneral.ClearDataSet();
		}

		private void btnCloneDataSetStructure_Click(object sender, System.EventArgs e) {
			objGeneral.CloneDataSetStructure();
		}

		private void btnCopyDataSet_Click(object sender, System.EventArgs e) {
			objGeneral.CopyDataSetStructureAndData();
		}

		private void btnMergeDataSetWithDataRows_Click(object sender, System.EventArgs e) {
			objGeneral.MergeDataSetWithDataRows();
		}

		private void btnMergeDataSets_Click(object sender, System.EventArgs e) {
			objGeneral.MergeDataSets();
		}

		private void btnMergeDataSetWithDataTable_Click(object sender, System.EventArgs e) {
			objGeneral.MergeDataSetWithDataTable();
		}

		private void btnBuildDataTable_Click(object sender, System.EventArgs e) {
			objGeneral.BuildDataTable();
		}

		private void btnClearDataTable_Click(object sender, System.EventArgs e) {
			objGeneral.ClearDataTable();
		}

		private void btnCloneDataTable_Click(object sender, System.EventArgs e) {
			objGeneral.CloneDataTableStructure();
		}

		private void btnCopyDataTable_Click(object sender, System.EventArgs e) {
			objGeneral.CopyDataTable();
		}

		private void btnSearchDataTable_Click(object sender, System.EventArgs e) {
			objGeneral.SearchDataTable();
		}

		private void btnDetectAllDataSetChanges_Click(object sender, System.EventArgs e) {
			objGeneral.DetectAllDataSetChanges();
		}

		private void btnDetectDifferentDataSetChanges_Click(object sender, System.EventArgs e) {
			objGeneral.DetectDifferentDataSetChanges();
		}

		private void btnAcceptOrRejectDataSetChanges_Click(object sender, System.EventArgs e) {
			objGeneral.AcceptOrRejectDataSetChanges();
		}

		private void btnSearchDataView_Click(object sender, System.EventArgs e) {
			objGeneral.SearchDataView();
		}

		private void btnBuildUserManDatabase_Click(object sender, System.EventArgs e) {
			objGeneral.BuildUserManDatabase();
		}
	}
}