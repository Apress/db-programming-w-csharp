/****** Drop existing UserMan database ******/
IF EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = N'UserMan')
	DROP DATABASE [UserMan]
GO
/****** Drop existing UserMan1 login ******/
IF EXISTS (SELECT name FROM master.dbo.sysxlogins WHERE name = N'UserMan1')
	EXEC sp_droplogin @loginame='UserMan1'
GO
/****** Drop existing UserMan2 login ******/
IF EXISTS (SELECT name FROM master.dbo.sysxlogins WHERE name = N'UserMan2')
	EXEC sp_droplogin @loginame='UserMan2'
GO
/****** Drop existing UserMan3 login ******/
IF EXISTS (SELECT name FROM master.dbo.sysxlogins WHERE name = N'UserMan3')
	EXEC sp_droplogin @loginame='UserMan3'
GO
/****** Drop existing UserMan login ******/
IF EXISTS (SELECT name FROM master.dbo.sysxlogins WHERE name = N'UserMan')
	EXEC sp_droplogin @loginame='UserMan'
GO