using System;

// Listing 5-11
public class UserManException : ApplicationException {
	private string prstrSource = "UserManException";

	public override string Message {
		get { return "This exception was thrown because you..."; }
	}

	public override string Source {
		get { return prstrSource; }

		set { prstrSource = value; }
	}
}