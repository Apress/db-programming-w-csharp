using System;
using System.Messaging;
using System.Windows.Forms;

/// <summary>
/// Summary description for CGeneral.
/// </summary>
public class CGeneral {
   // Listing 8-1
   public void CreatePrivateQueueWithName() {
      MessageQueue.Create("USERMANPC\\Private$\\UserMan");
   }

   // Listing 8-2
   public void CreatePrivateQueue() {
      MessageQueue.Create(".\\Private$\\UserMan");
   }

   // Listing 8-3
   public void CreatePublicQueue() {
      MessageQueue.Create(".\\UserMan");
   }

   // Listing 8-4
   public void CreateTransactionalPrivateQueue() {
      MessageQueue.Create(".\\Private$\\UserMan", true);
   }

   // Listing 8-5
   public void ChangeQueueLabel() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");

      queUserMan.Label = "USERMAN1";
   }

   // Listing 8-6
   public void RetrieveQueueId() {
      MessageQueue queUserMan = new MessageQueue(".\\UserMan");
      Guid uidMessageQueue;

      uidMessageQueue = queUserMan.Id;
   }

   // Listing 8-7
   public void BindToExistingQueue() {
      MessageQueue queUserManNoArguments = new MessageQueue();
      MessageQueue queUserManPath = new MessageQueue(".\\Private$\\UserMan");
      MessageQueue queUserManPathAndAccess = new MessageQueue(".\\Private$\\UserMan", true);

      // Initialize the queue
      queUserManNoArguments.Path = ".\\Private$\\UserMan";
   }

   // Listing 8-8
   public void BindToExistingQueueUsingFormat() {
      MessageQueue queUserManFormatTCP = new 
         MessageQueue("FormatName:DIRECT=TCP:10.8.1.15\\Private$\\UserMan");
      MessageQueue queUserManFormatOS = new 
         MessageQueue("FormatName:DIRECT=OS:USERMANPC\\UserMan");
      MessageQueue queUserManFormatPublic = 
         new MessageQueue("FormatName:Public=AB6B9EF6-B167-43A4-8116-5B72D5C1F81C");
   }

   // Listing 8-9
   public void BindToExistingQueueUsingLabel() {
      MessageQueue queUserManLabel = new MessageQueue("Label:Userman");
   }

   // Listing 8-10
   public void SendSimpleMessage() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");

      // Send simple message to queue
      queUserMan.Send("Test");
   }

   // Listing 8-11
   public void RetrieveSimpleMessage() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");
      System.Messaging.Message msgUserMan;

      // Retrieve first message from queue
      msgUserMan = queUserMan.Receive();
   }

   // Listing 8-12
   public void RetrieveMessage() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");
      System.Messaging.Message msgUserMan;
      string strBody;

      // Set up the formatter
      queUserMan.Formatter =  new 
         XmlMessageFormatter(new Type[1] {Type.GetType("System.String")}) ;

      // Retrieve first message from queue
      msgUserMan = queUserMan.Receive();
      // Save the message body
      strBody = msgUserMan.Body.ToString();
   } 

   public void SendMessage() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");
      System.Messaging.Message msgUserMan = new System.Messaging.Message();

      // Set up the formatter
      queUserMan.Formatter =  new 
         XmlMessageFormatter(new Type[1] {Type.GetType("System.String")}) ;

      // Create body as a text message
      msgUserMan.Body = "Test";
      // Send message to queue
      queUserMan.Send(msgUserMan);
   }

   // Listing 8-13-1
   public void SendDifferentMessages() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");
      System.Messaging.Message msgUserMan = new System.Messaging.Message();

      // Set up the formatter
      queUserMan.Formatter =  new 
         XmlMessageFormatter(new Type[] {Type.GetType("System.String"),
         Type.GetType("System.Int32")});
      // Create body as a text message
      msgUserMan.Body = "Test";
      // Send message to queue
      queUserMan.Send(msgUserMan);
      // Create body as an integer
      msgUserMan.Body = 12;
      // Send message to queue
      queUserMan.Send(msgUserMan);
   }

   // Listing 8-13-2
   public void RetrieveDifferentMessages() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");
      System.Messaging.Message msgUserMan;
      string strBody;
      Int32 intBody;

      // Set up the formatter
      queUserMan.Formatter =  new 
         XmlMessageFormatter(new Type[] {Type.GetType("System.String"),
         Type.GetType("System.Int32")});

      // Retrieve first message from queue
      msgUserMan = queUserMan.Receive();
      // Save the message body
      strBody = msgUserMan.Body.ToString();
      // Retrieve next message from queue
      msgUserMan = queUserMan.Receive();
      // Save the message body
      intBody = (Int32) msgUserMan.Body;
   }

   // Listing 8-14
   public void PeekMessage() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");
      System.Messaging.Message msgUserMan;
      string strBody;

      // Set up the formatter
      queUserMan.Formatter =  new 
         XmlMessageFormatter(new Type[] {Type.GetType("System.String")});

      // Peek first message from queue
      msgUserMan = queUserMan.Peek();
      // Save the message body
      strBody = msgUserMan.Body.ToString();
   }

   // Listing 8-15
   public void RetrieveMessageById() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");
      System.Messaging.Message msgUserMan = new System.Messaging.Message();
      string strId;

      // Set up the formatter
      queUserMan.Formatter = new 
         XmlMessageFormatter(new Type[] {Type.GetType("System.String")});

      // Create body as a text message
      msgUserMan.Body = "Test 1";
      // Send message to queue
      queUserMan.Send(msgUserMan);

      // Create body as a text message
      msgUserMan.Body = "Test 2";
      // Send message to queue
      queUserMan.Send(msgUserMan);
      strId = msgUserMan.Id;

      // Create body as a text message
      msgUserMan.Body = "Test 3";
      // Send message to queue
      queUserMan.Send(msgUserMan);

      msgUserMan = queUserMan.ReceiveById(strId);
      MessageBox.Show("Saved Id=" + strId + "\nRetrieved Id=" + msgUserMan.Id);
   }

   // Listing 8-16
   public System.Messaging.Message RetrieveMessageByIdSafe(string strId) {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");
      System.Messaging.Message msgUserMan = new System.Messaging.Message();

      // Set up the formatter
      queUserMan.Formatter = new 
         XmlMessageFormatter(new Type[] {Type.GetType("System.String")});

      try {
         msgUserMan = queUserMan.ReceiveById(strId);
      }
      catch {
         // Message not found, return a null value
         return null;
      }

      // Return message
      return msgUserMan;
   }

   public void RetrieveAllMessages() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");

      // Set up the formatter
      queUserMan.Formatter = new 
         XmlMessageFormatter(new Type[] {Type.GetType("System.String")});

      object[] arrstrMessages = queUserMan.GetAllMessages();
   }

   // Listing 8-17-1
   public void MessageReceiveCompleteEvent(Object objSource, 
      ReceiveCompletedEventArgs objEventArgs) {
      System.Messaging.Message msgUserMan = new System.Messaging.Message();
      MessageQueue queUserMan = new MessageQueue();

      // Make sure we bind to the right message queue
      queUserMan = (MessageQueue) objSource;

      // End async receive
      msgUserMan = queUserMan.EndReceive(objEventArgs.AsyncResult);
   }

   // Listing 8-17-2
   public void RetrieveMessagesAsync() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");
      System.Messaging.Message msgUserMan = new System.Messaging.Message();

      // Set up the formatter
      queUserMan.Formatter = new 
         XmlMessageFormatter(new Type[] {Type.GetType("System.String")});

      // Add an event handler
      queUserMan.ReceiveCompleted += 
         new ReceiveCompletedEventHandler(MessageReceiveCompleteEvent);

      queUserMan.BeginReceive(new TimeSpan(0, 0, 10));
   }

   // Listing 8-18-1
   public void MessagePeekCompleteEvent(object objSource, 
      PeekCompletedEventArgs objEventArgs) {
      System.Messaging.Message msgUserMan = new System.Messaging.Message();
      MessageQueue queUserMan = new MessageQueue();

      // Make sure we bind to the right message queue
      queUserMan = (MessageQueue) objSource;

      // End async peek
      msgUserMan = queUserMan.EndPeek(objEventArgs.AsyncResult);
   }

   // Listing 8-18-2
   public void PeekMessagesAsync() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");
      System.Messaging.Message msgUserMan = new System.Messaging.Message();

      // Set up the formatter
      queUserMan.Formatter = new 
         XmlMessageFormatter(new Type[] {Type.GetType("System.String")});

      // Add an event handler
      queUserMan.PeekCompleted += 
         new PeekCompletedEventHandler(MessagePeekCompleteEvent);

      queUserMan.BeginPeek(new TimeSpan(0, 0, 10));
   }

   // Listing 8-19
   public void ClearMessageQueue() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");

      // Clear all messages from queue
      queUserMan.Purge();
   }

   // Listing 8-20-1
   public void SendPriorityMessages() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");
      System.Messaging.Message msgFirst = new System.Messaging.Message();
      System.Messaging.Message msgSecond = new System.Messaging.Message();

      // Set up the formatter
      queUserMan.Formatter = new 
         XmlMessageFormatter(new Type[] {Type.GetType("System.String")});

      // Create first body 
      msgFirst.Body = "First Message";
      // Send message to queue
      queUserMan.Send(msgFirst);

      // Create second body 
      msgSecond.Body = "Second Message";
      // Set priority to highest
      msgSecond.Priority = MessagePriority.Highest;
      // Send message to queue
      queUserMan.Send(msgSecond);
   }

   // Listing 8-20-2
   public void RetrievePriorityMessage() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");
      System.Messaging.Message msgUserMan;

      // Set up the formatter
      queUserMan.Formatter = new 
         XmlMessageFormatter(new Type[] {Type.GetType("System.String")});

      // Retrieve first message from queue
      msgUserMan = queUserMan.Receive();
      // Display the message body
      MessageBox.Show(msgUserMan.Body.ToString());
   }

   // Listing 8-21
   public bool CheckQueueExists(string strPath) {
      return MessageQueue.Exists(strPath);
   }

   // Listing 8-22
   public void BrowsePrivateQueues() {
      MessageQueue[] arrquePrivate = 
         MessageQueue.GetPrivateQueuesByMachine("USERMANPC");

      // Display the name of all the private queues on the machine
      foreach(MessageQueue queUserMan in arrquePrivate) {
         MessageBox.Show(queUserMan.Label);
      }
   }

   public void BrowsePublicQueuesMachineWide() {
      MessageQueue[] arrquePublic = 
         MessageQueue.GetPublicQueuesByMachine("USERMANPC");

      // Display the name of all the public queues on the machine
      foreach(MessageQueue queUserMan in arrquePublic) {
         MessageBox.Show(queUserMan.Label);
      }
   }

   // Listing 8-23
   public void BrowsePublicQueuesNetworkWide() {
      MessageQueue[] arrquePublic = 
         MessageQueue.GetPublicQueues();

      // Display the name of all the public queues on the network
      foreach(MessageQueue queUserMan in arrquePublic) {
         MessageBox.Show(queUserMan.Label);
      }
   }

   // Listing 8-24
   public void BrowsePublicQueuesByCategoryNetworkWide() {
      MessageQueue[] arrquePublic = 
         MessageQueue.GetPublicQueuesByCategory(new Guid("00000000-0000-0000-0000-000000000001"));

      // Display the name of all the public queues 
      // on the network within a specific category
      foreach(MessageQueue queUserMan in arrquePublic) {
         MessageBox.Show(queUserMan.Label);
      }
   }

   // Listing 8-25
   public void BrowsePublicQueuesByLabelNetworkWide() {
      MessageQueue[] arrquePublic = 
         MessageQueue.GetPublicQueuesByLabel("userman");

      // Display the machine name for all the public queues 
      // on the network with a specific label
      foreach(MessageQueue queUserMan in arrquePublic) {
         MessageBox.Show(queUserMan.Label);
      }
   }

   // Listing 8-26
   public void RemoveMessageQueue(string strPath) {
      MessageQueue.Delete(strPath);
   }

   // Listing 8-27
   public void RemoveMessageQueueSafely(string strPath) {
      try {
         MessageQueue.Delete(strPath);
      }
      catch (Exception objE) {
         MessageBox.Show(objE.Message);
      }
   }

   public void SetQueueMaxSize() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");

      // Set max queue size
      queUserMan.MaximumQueueSize = 15;
   }

   // Listing 8-28
   public void UseMQTransactions() {
      MessageQueueTransaction qtrUserMan = new MessageQueueTransaction();
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");
      System.Messaging.Message msgUserMan = new System.Messaging.Message();

      // Set up the queue formatter
      queUserMan.Formatter = new 
         XmlMessageFormatter(new Type[] {Type.GetType("System.String")});

      // Clear the message queue
      queUserMan.Purge();
      // Start the transaction
      qtrUserMan.Begin();

      try {
         // Create message body
         msgUserMan.Body = "First Message";
         // Send message to queue
         queUserMan.Send(msgUserMan, qtrUserMan);

         // Create message body
         msgUserMan.Body = "Second Message";
         // Send message to queue
         queUserMan.Send(msgUserMan, qtrUserMan);

         // Retrieve message from queue
//         msgUserMan = queUserMan.Receive(qtrUserMan);
         // Display message body
//         MessageBox.Show(msgUserMan.Body.ToString());

         // Commit transaction
         qtrUserMan.Commit();

         // Retrieve message from queue
         msgUserMan = queUserMan.Receive(qtrUserMan);
         // Display message body
         MessageBox.Show(msgUserMan.Body.ToString());

         // Retrieve message from queue
         msgUserMan = queUserMan.Receive();
         // Display message body
         MessageBox.Show(msgUserMan.Body.ToString());
      }
      catch {
         // Abort the transaction
         qtrUserMan.Abort();
      }
   }

   public void EnableMQJournaling() {
      MessageQueue queUserMan = new MessageQueue("USERMANPC\\UserMan");

      queUserMan.UseJournalQueue = true;
   }

   // Listing 8-29
   public void ShowMessageJournaling() {
      MessageQueue queUserMan = new MessageQueue("USERMANPC\\UserMan");
      MessageQueue queUserManJournal = new MessageQueue("USERMANPC\\UserMan\\Journal$");
      MessageQueue queSystemJournal = new MessageQueue(".\\Journal$");
      System.Messaging.Message msgUserMan = new System.Messaging.Message();

      // Enable journaling on message queue
      queUserMan.UseJournalQueue = true;

      // Set up the formatter
      queUserMan.Formatter = new 
         XmlMessageFormatter(new Type[] {Type.GetType("System.String")});

      // Create message body 
      msgUserMan.Body = "Message";
      // Enable message journaling
      msgUserMan.UseJournalQueue = true;
      // Send message to remote UserMan queue
      queUserMan.Send(msgUserMan);
      // Retrieve message from remote UserMan queue
      msgUserMan = queUserMan.Receive();

      // Retrieve message from local system journal
      msgUserMan = queSystemJournal.Receive();
      // Retrieve message from remote UserMan journal
      msgUserMan = queUserManJournal.Receive();
   }

   public void SetJournalMaxSize() {
      MessageQueue queUserMan = new MessageQueue("USERMANPC\\UserMan");

      // Enable journaling
      queUserMan.UseJournalQueue = true;
      // Set max journal size
      queUserMan.MaximumJournalSize = 15;
   }

   // Listing 8-30
   public void EnableQueueAuthentication() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");
      System.Messaging.Message msgUserMan = new System.Messaging.Message();

      // Enable queue authentication
      queUserMan.Authenticate = true;
   }

   // Listing 8-31
   public void RejectNonAuthenticatedMessage() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");
      System.Messaging.Message msgUserMan = new System.Messaging.Message();

      // Enable queue authentication
      queUserMan.Authenticate = true;
      // Set up the queue formatter
      queUserMan.Formatter = new 
         XmlMessageFormatter(new Type[] {Type.GetType("System.String")});

      // Create message body
      msgUserMan.Body = "Message Body";
      // Make sure a rejected message is placed in the dead-letter queue
      msgUserMan.UseDeadLetterQueue = true;

      // Send message to queue
      queUserMan.Send(msgUserMan);
   }

   // Listing 8-32
   public void SendDeadLetterMessage() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");
      System.Messaging.Message msgUserMan = new System.Messaging.Message();

      // Set up the formatter
      queUserMan.Formatter = new 
         XmlMessageFormatter(new Type[] {Type.GetType("System.String")});

      // Create message body 
      msgUserMan.Body = "Message";
      // Set max time to be in queue
      msgUserMan.TimeToBeReceived = new TimeSpan(0, 1, 0);
      // Make sure that a dead-letter ends up in dead-letter queue
      msgUserMan.UseDeadLetterQueue = true;
      // Send message to queue
      queUserMan.Send(msgUserMan);
   }

   public void RetrieveMessageFromDeadLetterQueue() {
      MessageQueue queUserMan = new MessageQueue(".\\DeadLetter$");
      System.Messaging.Message msgUserMan = new System.Messaging.Message();

      // Set up the formatter
      queUserMan.Formatter = new 
         XmlMessageFormatter(new Type[] {Type.GetType("System.String")});

      try {
         // Retrieve message from journal
         msgUserMan = queUserMan.Receive();
      }
      catch (Exception objE) {
         MessageBox.Show(objE.Message);
      }
   }

   // Listing 8-33
   public void PlaceNonAuthenticatedMessageInAdminQueue() {
      MessageQueue queUserManAdmin = new MessageQueue(".\\Private$\\UserManAdmin");
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");
      System.Messaging.Message msgUserMan = new System.Messaging.Message();

      // Enable queue authentication
      queUserMan.Authenticate = true;
      // Set up the queue formatter
      queUserMan.Formatter = new 
         XmlMessageFormatter(new Type[] {Type.GetType("System.String")});

      // Create message body
      msgUserMan.Body = "Message Body";
      // Make sure a rejected message is placed in the admin queue
      msgUserMan.AdministrationQueue = queUserManAdmin;
      // These types of rejected messages
      msgUserMan.AcknowledgeType = AcknowledgeTypes.NotAcknowledgeReachQueue;

      // Send message to queue
      queUserMan.Send(msgUserMan);
   }

   // Listing 8-34
   public void AcceptAuthenticatedMessage() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");
      System.Messaging.Message msgUserMan = new System.Messaging.Message();

      // Enable queue authentication
      queUserMan.Authenticate = true;
      // Set up the queue formatter
      queUserMan.Formatter = new 
         XmlMessageFormatter(new Type[] {Type.GetType("System.String")});

      // Make sure a rejected message is placed in the dead-letter queue
      msgUserMan.UseDeadLetterQueue = true;
      // Make sure that message queuing attaches the sender id and
      // is digitally signed before it is sent
      msgUserMan.UseAuthentication = true;
      msgUserMan.AttachSenderId = true;
      // Create message body
      msgUserMan.Body = "Message Body";

      // Send message to queue
      queUserMan.Send(msgUserMan);
   }

   // Listing 8-35
   public void EnableRequireBodyEncryption() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");
      System.Messaging.Message msgUserMan = new System.Messaging.Message();

      // Enable body encryption requirement
      queUserMan.EncryptionRequired = EncryptionRequired.Body;
   }

   // Listing 8-36
   public void SendAndReceiveEncryptedMessage() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");
      System.Messaging.Message msgUserMan = new System.Messaging.Message();

      // Require message body encryption
      queUserMan.EncryptionRequired = EncryptionRequired.Body;
      // Set up the queue formatter
      queUserMan.Formatter = new 
         XmlMessageFormatter(new Type[] {Type.GetType("System.String")});

      // Make sure that message is encrypted before it is sent
      msgUserMan.UseEncryption = true;
      // Create message body
      msgUserMan.Body = "Message Body";

      // Send message to queue
      queUserMan.Send(msgUserMan);

      // Retrieve message from queue
      msgUserMan = queUserMan.Receive();
      // Show decrypted message body
      MessageBox.Show(msgUserMan.Body.ToString());
   }

   // Listing 8-37
   public void SetUserPermissions() {
      MessageQueue queUserMan = new MessageQueue(".\\Private$\\UserMan");
      System.Messaging.Message msgUserMan = new System.Messaging.Message();
      AccessControlList aclUserMan = new AccessControlList();

      // Give UserMan user full control over private UserMan queue
      queUserMan.SetPermissions("UserMan", MessageQueueAccessRights.FullControl);
      // Give UserMan user full control over private UserMan queue
      queUserMan.SetPermissions(new 
         MessageQueueAccessControlEntry(new Trustee("UserMan"),
         MessageQueueAccessRights.FullControl));
      // Deny UserMan deleting the private UserMan queue
      queUserMan.SetPermissions("UserMan", MessageQueueAccessRights.DeleteQueue, 
         AccessControlEntryType.Deny);
      // Deny UserMan all access rights on the private UserMan queue
      aclUserMan.Add(new AccessControlEntry(new Trustee("UserMan"), 
         GenericAccessRights.All, StandardAccessRights.All, 
         AccessControlEntryType.Deny));
      queUserMan.SetPermissions(aclUserMan);
   }
}