using System;
using System.DirectoryServices;
using System.Data.OleDb;
using System.DirectoryServices.Interop;
using System.Windows.Forms;
using System.Collections;

	/// <summary>
	/// Summary description for CGeneral.
	/// </summary>
public class CGeneral {
	// Listing 7-1
	public void BindToUserManObjectInAD() {
		DirectoryEntry objEntry;

		objEntry = new DirectoryEntry("LDAP://CN=UserMan,CN=Users,DC=userman,DC=dk", 
			"Administrator", "adminpwd");
	}

	// Listing 7-2
	public void SearchForSpecificObjectInAD() {
		DirectoryEntry objEntry;
		DirectorySearcher objSearcher;
		SearchResult objSearchResult;

		// Instantiate and bind to Users node in AD
		objEntry = new DirectoryEntry("LDAP://CN=Users,DC=userman,DC=dk", "UserMan", 
			"userman");

		// Set up to search for UserMan on the Users node
		objSearcher = new DirectorySearcher(objEntry, "(&(objectClass=user)" + 
			"(objectCategory=person)(userPrincipalName=userman@userman.dk))");

		// Find the user
		objSearchResult = objSearcher.FindOne();

		// Check if the user was found
		if (objSearchResult != null) {
			// Display path for user
			MessageBox.Show("Users Path: " + objSearchResult.Path);
		}
		else {
			MessageBox.Show("User not found!");
		}
	}

	// Listing 7-3
	public void SearchForAllUserObjectsInAD() {
		DirectoryEntry objEntry;
		DirectorySearcher objSearcher;
		SearchResultCollection objSearchResults;

		// Instantiate and bind to root node in AD
		objEntry = new DirectoryEntry("LDAP://DC=userman,DC=dk", "UserMan", "userman");

		// Set up to search for all users
		objSearcher = new DirectorySearcher(objEntry, 
			"(&(objectClass=user)(objectCategory=person))");

		// Find all objects of class user
		objSearchResults = objSearcher.FindAll();

		// Check if any users were found
		if (objSearchResults != null) {
			// Loop through all users returned
			foreach (SearchResult objSearchResult in objSearchResults) {
				// Display path for user
				MessageBox.Show("Users Path: " + objSearchResult.Path);
			}
		}
		else {
			MessageBox.Show("No users were found!");
		}
	}

	// Listing 7-4
	public void ReturnNonDefaultNodeProperties() {
		DirectoryEntry objEntry;
		DirectorySearcher objSearcher;
		SearchResult objSearchResult;

		// Instantiate and bind to Users node in AD
		objEntry = new DirectoryEntry("LDAP://CN=Users,DC=userman,DC=dk", 
			"UserMan", "userman");

		// Set up to search for UserMan on the Users node
		objSearcher = new DirectorySearcher(objEntry, "(&(objectClass=user)" +
			"(objectCategory=person)(userPrincipalName=userman@userman.dk))", 
			new string[3] {"sn", "telephoneNumber", "givenName"});

      try {
         // Find the user
         objSearchResult = objSearcher.FindOne();
      }
      catch (Exception objE) {
         // Catch any mistakes made when setting up 
         // the DirectoryEntry object, like wrong domain
         MessageBox.Show(objE.Message);
         return;
      }

		// Check if the user was found
		if (objSearchResult != null) {
			// Display all returned user properties
			// Loop through all the properties returned
			foreach (string strName in objSearchResult.Properties.PropertyNames)  {
				// Loop through all the values for each property
				foreach (object objValue in objSearchResult.Properties[strName]) {
					// Display the property and value
					MessageBox.Show("Property Name: " + strName.ToString() + " - Value: " + objValue.ToString());
				}
			}
		}
		else {
			MessageBox.Show("User not found!");
		}
	}

	// Listing 7-5
	public void EditUserProperty() {
		DirectoryEntry objEntry;

		// Bind to UserMan user object
		objEntry = new DirectoryEntry("LDAP://CN=UserMan,CN=Users,DC=userman,DC=dk", 
			"Administrator", "adminpwd");

		// Check if the user already had an e-mail address
		if (objEntry.Properties.Contains("mail")) {
			// Change the e-mail address for the user
			objEntry.Properties["mail"][0] = "userman@userman.dk";
			// Commit the changes to the AD database
			objEntry.CommitChanges();
		}
	}

	// Listing 7-6
	public void AddNewUserProperty() {
		DirectoryEntry objEntry;

		// Bind to UserMan user object
		objEntry = new DirectoryEntry("LDAP://CN=UserMan,CN=Users,DC=userman,DC=dk", 
			"Administrator", "adminpwd");

		// Check if the user already had an e-mail address
		if (!objEntry.Properties.Contains("mail")) {
			// Add new e-mail address
			objEntry.Properties["mail"].Add("userman@userman.dk");
			// Commit the changes to the AD database
			objEntry.CommitChanges();
		}
	}

	// Listing 7-7
	public void ManipulateUserProperty() {
		DirectoryEntry objEntry;

		// Bind to UserMan user object
		objEntry = new DirectoryEntry("LDAP://CN=UserMan,CN=Users,DC=userman,DC=dk", 
			"Administrator", "AdminPwd");

		// Check if the user already had an e-mail address
		if (objEntry.Properties.Contains("mail")) {
			// Change the e-mail address for the user
			objEntry.Properties["mail"][0] = "userman@userman.dk";
		}
		else {
			// Add new e-mail address
			objEntry.Properties["mail"].Add("userman@userman.dk");
		}

		// Commit the changes to the AD database
		objEntry.CommitChanges();
	}

	// Listing 7-8
	public void AccessADWithOleDb() {
		OleDbConnection cnnAD;
		OleDbCommand cmmAD; 
		OleDbDataReader drdAD;

		// Instantiate and open connection
		cnnAD = new OleDbConnection("Provider=ADsDSOObject;User Id=UserMan;" +
			"Password=userman");
		cnnAD.Open();
		// Instantiate command
		cmmAD = new OleDbCommand("SELECT cn, AdsPath FROM 'LDAP://userman.dk' " +
			"WHERE objectCategory='person' AND objectClass='user' AND cn='UserMan'", 
			cnnAD);

		// Retrieve rows in data reader
		drdAD = cmmAD.ExecuteReader();
	}

	// Listing 7-9
	public void GetSIDAndSAMAccountNameFromAD() {
		OleDbConnection cnnAD;
		OleDbCommand cmmAD;
		OleDbDataReader drdAD;
		string strSAMAccountName;
		string strSID;

		// Instantiate and open connection
		cnnAD = new OleDbConnection("Provider=ADsDSOObject;User Id=UserMan;" +
			"Password=userman");
		cnnAD.Open();
		// Instantiate command
		cmmAD = new OleDbCommand("SELECT objectSid, samAccountName FROM " +
			"'LDAP://userman.dk' WHERE objectCategory='person' AND objectClass='user' " + 
			"AND cn='UserMan'", cnnAD);

		// Retrieve rows in data reader
		drdAD = cmmAD.ExecuteReader();
		// Go to first row
		drdAD.Read();
		// Get SAM Account name
		strSAMAccountName = drdAD["samAccountName"].ToString();
		// Get SID
		strSID = drdAD["objectSid"].ToString();
	}
}