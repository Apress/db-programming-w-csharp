using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Stored_Procedures_Project
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnExecuteSimpleSP;
		private System.Windows.Forms.Button btnExecuteSimpleRowReturningSP;
		private System.Windows.Forms.Button btnGetUsersByLastName;
		private System.Windows.Forms.Button btnGetUsersAndRights;
		private System.Windows.Forms.Button btnGetRETURN_VALUE;

		private CGeneral objGeneral = new CGeneral();
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnExecuteSimpleSP = new System.Windows.Forms.Button();
			this.btnExecuteSimpleRowReturningSP = new System.Windows.Forms.Button();
			this.btnGetUsersByLastName = new System.Windows.Forms.Button();
			this.btnGetUsersAndRights = new System.Windows.Forms.Button();
			this.btnGetRETURN_VALUE = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnExecuteSimpleSP
			// 
			this.btnExecuteSimpleSP.Location = new System.Drawing.Point(6, 6);
			this.btnExecuteSimpleSP.Name = "btnExecuteSimpleSP";
			this.btnExecuteSimpleSP.Size = new System.Drawing.Size(109, 23);
			this.btnExecuteSimpleSP.TabIndex = 0;
			this.btnExecuteSimpleSP.Text = "Execute Simple SP";
			this.btnExecuteSimpleSP.Click += new System.EventHandler(this.btnExecuteSimpleSP_Click);
			// 
			// btnExecuteSimpleRowReturningSP
			// 
			this.btnExecuteSimpleRowReturningSP.Location = new System.Drawing.Point(120, 6);
			this.btnExecuteSimpleRowReturningSP.Name = "btnExecuteSimpleRowReturningSP";
			this.btnExecuteSimpleRowReturningSP.Size = new System.Drawing.Size(187, 23);
			this.btnExecuteSimpleRowReturningSP.TabIndex = 1;
			this.btnExecuteSimpleRowReturningSP.Text = "Execute Simple Row Returning SP";
			this.btnExecuteSimpleRowReturningSP.Click += new System.EventHandler(this.btnExecuteSimpleRowReturningSP_Click);
			// 
			// btnGetUsersByLastName
			// 
			this.btnGetUsersByLastName.Location = new System.Drawing.Point(312, 6);
			this.btnGetUsersByLastName.Name = "btnGetUsersByLastName";
			this.btnGetUsersByLastName.Size = new System.Drawing.Size(187, 23);
			this.btnGetUsersByLastName.TabIndex = 2;
			this.btnGetUsersByLastName.Text = "Get Users by Last Name";
			this.btnGetUsersByLastName.Click += new System.EventHandler(this.btnGetUsersByLastName_Click);
			// 
			// btnGetUsersAndRights
			// 
			this.btnGetUsersAndRights.Location = new System.Drawing.Point(312, 34);
			this.btnGetUsersAndRights.Name = "btnGetUsersAndRights";
			this.btnGetUsersAndRights.Size = new System.Drawing.Size(187, 23);
			this.btnGetUsersAndRights.TabIndex = 3;
			this.btnGetUsersAndRights.Text = "Get Users and Rights";
			this.btnGetUsersAndRights.Click += new System.EventHandler(this.btnGetUsersAndRights_Click);
			// 
			// btnGetRETURN_VALUE
			// 
			this.btnGetRETURN_VALUE.Location = new System.Drawing.Point(312, 62);
			this.btnGetRETURN_VALUE.Name = "btnGetRETURN_VALUE";
			this.btnGetRETURN_VALUE.Size = new System.Drawing.Size(187, 23);
			this.btnGetRETURN_VALUE.TabIndex = 4;
			this.btnGetRETURN_VALUE.Text = "Get RETURN_VALUE";
			this.btnGetRETURN_VALUE.Click += new System.EventHandler(this.btnGetRETURN_VALUE_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(504, 91);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																							 this.btnGetRETURN_VALUE,
																							 this.btnGetUsersAndRights,
																							 this.btnGetUsersByLastName,
																							 this.btnExecuteSimpleRowReturningSP,
																							 this.btnExecuteSimpleSP});
			this.Name = "Form1";
			this.Text = "Stored Procedures Project";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void btnExecuteSimpleSP_Click(object sender, System.EventArgs e) {
			//objGeneral.ExecuteSimpleSP();		
         //objGeneral.ExecuteSimpleOracleSF();
         objGeneral.ExecuteSimpleOracleSP();
		}

		private void btnExecuteSimpleRowReturningSP_Click(object sender, System.EventArgs e) {
			objGeneral.ExecuteSimpleRowReturningSP();
		}

		private void btnGetUsersByLastName_Click(object sender, System.EventArgs e) {
			//objGeneral.GetUsersByLastName();
         objGeneral.OracleGetUsersByLastName();
		}

		private void btnGetUsersAndRights_Click(object sender, System.EventArgs e) {
			objGeneral.GetUsersAndRights();
		}

		private void btnGetRETURN_VALUE_Click(object sender, System.EventArgs e) {
			objGeneral.GetRETURN_VALUE();
		}
	}
}
