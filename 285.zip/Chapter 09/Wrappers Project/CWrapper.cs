using System;

/// <summary>
/// Summary description for CWrapper.
/// </summary>

// Listing 9-4-1
public class CWrapper : CAbstract {
}

// Listing 9-5-2
public class CWrapper1 : CVirtual {

   private string prstrTest;

   public override string Test {
      get {
         return prstrTest + "Overridden";
      }

      set {
         prstrTest = value;
      }
   }
}