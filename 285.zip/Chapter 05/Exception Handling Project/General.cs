#define DEBUG 

using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Diagnostics;

public class CGeneral {
	public const string STR_CONNECTION_STRING = "Data Source=USERMANPC;" +
		"User ID=UserMan;Password=userman;Initial Catalog=UserMan";
	private const string STR_SQL_USER_SELECT = "SELECT * FROM tblUser";

	public void ExceptionHandler() {
		long lngResult;
		long lngValue = 0;

		try {
			lngResult = 8 / lngValue;
		}
		catch {
			MessageBox.Show("catch");
		}
		finally {
			MessageBox.Show("finally");
		}
	}

	// Listing 5-2
	public void TwoExceptionHandlers() {
		long lngResult;
		long lngValue = 0;

		try {		 // First exception handler
			lngResult = 8 / lngValue;
		}
		catch (Exception objFirst) {
			MessageBox.Show(objFirst.Message);
		}

		try {		 // Second exception handler
			lngResult = 8 / lngValue;
		}
		catch (Exception objSecond) {
			MessageBox.Show(objSecond.Source);
		}
	}

	// Listing 5-3
	public void SimpleCatchBlock() {
		long lngResult;
		long lngValue = 0;

		try {
			lngResult = 8 / lngValue;
		}
		catch {
			MessageBox.Show("catch");
		}
	}

	// Listing 5-4
	public void CatchBlockWithExceptionObject() {
		long lngResult;
		long lngValue = 0;

		try {
			lngResult = 8 / lngValue;
		}
		catch (Exception objE) {
			MessageBox.Show(objE.ToString());
		}
	}

	// Listing 5-5
	public void ThrowIndexOutOfRangeException() {
		long[] arrlngException = new long[2];

		try {
			arrlngException[2] = 5;
		}
		catch (Exception objE) {
			MessageBox.Show(objE.ToString());
		}
	}

	// Listing 5-6
	public void ThrowNullreferenceException() {
		Exception objException = new Exception();

		try {
			objException = null;
			MessageBox.Show(objException.Message);
		}
		catch (Exception objE) {
			MessageBox.Show(objE.ToString());
		}
	}

	// Listing 5-7
	public void ThrowInvalidOperationException() {
		SqlConnection cnnUserMan;
		SqlCommand cmmUser;
		SqlDataReader drdUser;

		try {
			// Instantiate and open the connection
			cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
			cnnUserMan.Open();
			// Instantiate command
			cmmUser = new SqlCommand(STR_SQL_USER_SELECT, cnnUserMan);
			// Instantiate and populate data reader
			drdUser = cmmUser.ExecuteReader();
			// Execute query while data reader is open
			cmmUser.ExecuteNonQuery();
		}
		catch (Exception objE) {
			MessageBox.Show(objE.ToString());
		}
	}

	// Listing 5-8
	public void ThrowArgumentNullException() {
		SqlConnection cnnUserMan;
		SqlCommand cmmUser;
		DataSet dstUser = new DataSet();
		SqlDataAdapter dadUser;

		try {
			// Instantiate and open the connection
			cnnUserMan = new SqlConnection(STR_CONNECTION_STRING);
			cnnUserMan.Open();
			// Instantiate command
			cmmUser = new SqlCommand();
			// Instatiate data adapter
			dadUser = new SqlDataAdapter(cmmUser);
			dstUser = null;
			// Update data source
			dadUser.Update(dstUser);
		}
		catch (Exception objE) {
			MessageBox.Show(objE.ToString());
		}
	}

	// Listing 5-9
	public void ThrowArgumentOutOfRangeException() {
		try {
			// Display the first 200 chars from the connection string
			MessageBox.Show(STR_CONNECTION_STRING.Substring(1, 200));
		}
		catch (Exception objE) {
			MessageBox.Show(objE.ToString());
		}
	}

	// Listing 5-10
	public void TypeFilterExceptions() {
		long[] arrlngException = new long[2];
		Exception objException = new Exception();
		long lngResult;
		long lngValue = 0;

		try {
			arrlngException[2] = 5;
			objException = null;
			MessageBox.Show(objException.Message);
			lngResult = 8 / lngValue;
		}
		catch (NullReferenceException) {
			MessageBox.Show("NullReferenceException");
		}
		catch (IndexOutOfRangeException) {
			MessageBox.Show("IndexOutOfRangeException");
		}
		catch (Exception) {
			MessageBox.Show("Exception");
		}
	}

	public void ThrowException() {
		UserManException objUM = new UserManException();

		objUM.Source = "Test";

		try {
			//throw objUM;
			throw new IndexOutOfRangeException();
		}
		catch (Exception objE) {
			MessageBox.Show(objE.Source);
		}
	}

	// Listing 5-12
	public void CatchSqlConnectionClassExceptions() {
		SqlConnection cnnUserMan;

		try {
			// Instantiate the connection
			cnnUserMan = new SqlConnection(STR_CONNECTION_STRING + ";Connection Timeout=-1");
		}
		catch (ArgumentException objException) {
			if (objException.TargetSite.Name == "SetConnectTimeout") {
				MessageBox.Show(objException.StackTrace);
			}
		}
	}

   // Listing 5-13
   public void TestDebugAssert() {
      DataSet dstUser = new DataSet();
      DataSet dstLog = new DataSet();

      try {
         // Do your stuff
         // ...
         // Destroy Log dataset
         dstLog.Dispose();
         dstLog = null;
         // This obviously throws the
         // NullReferenceException exception
         MessageBox.Show(dstLog.DataSetName);
      }
      catch (NullReferenceException objNullReference) {
         // Check if both our object instances are null
         Debug.Assert(((dstUser == null) & (dstLog == null)), 
            "Assert Message");
      }
      catch (Exception objE) {
         // Handle all other exceptions here
      }
   }

   // Listing 5-14
   public void TestDebugFail() {
      try {
         // Do your stuff here
         // ...
         throw new Exception("I'm not really expected!");
      }
      catch (NullReferenceException objNullReference) {
         // Handle the NullReferenceException here
      }
      catch (IndexOutOfRangeException objIndexOutOfRange) {
         // Handle the IndexOutOfRangeException here
      }
      catch (Exception objE) {
         Debug.Fail("Fail Message", 
            "An unexpected exception has been thrown.\n\n" + objE.Message);
      }
   }
}